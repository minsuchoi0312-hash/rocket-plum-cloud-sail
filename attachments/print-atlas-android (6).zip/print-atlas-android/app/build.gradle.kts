import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val webSource: File = rootProject.file("../print-atlas")

tasks.register<Copy>("syncWebAssets") {
    onlyIf { webSource.exists() }
    from(webSource)
    include(
        "index.html",
        "styles.css",
        "app.js",
        "engine.js",
        "i18n.js",
        "sw.js",
        "manifest.webmanifest",
        "icon.svg",
    )
    into(layout.projectDirectory.dir("src/main/assets/www"))
}

tasks.named("preBuild").configure { dependsOn("syncWebAssets") }

android {
    namespace = "app.printatlas"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.printatlas"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.appcompat:appcompat:1.7.0")
}
