const viewEl = () => document.querySelector("#view");
const titleEl = () => document.querySelector("#title");
const activeSlot = () => document.querySelector("#active-slot");

const TITLE_KEYS = {
  home: "title.home",
  find: "title.find",
  result: "title.result",
  print: "title.print",
  packs: "title.packs",
  mine: "title.mine",
};

const SOURCES = ["doc", "photo", "web", "contact", "sms", "test"];
const SOURCE_KO = { doc: "문서", photo: "사진", web: "웹", contact: "연락처", sms: "문자", test: "테스트" };
const QUALITY_KEYS = { "초안": "q.draft", "표준": "q.std", "사진": "q.photo" };

const IDENTITY_SAMPLES = [
  { key: "sample.ok", value: "MFG:EPSON;MDL:ET-2850;CMD:ESCPL2,URF;" },
  { key: "sample.cmd", value: "MFG:HP;MDL:LaserJet 1020;" },
  { key: "sample.fuzzy", value: "아무개 프린터 9000" },
];

const state = {
  view: "home",
  query: "",
  match: null,
  list: null,
  scanning: false,
  scanLog: [],
  scanHits: false,
  saved: [],
  jobs: [],
  activeUid: "",
  openPack: "driverless",
  unlocked: {},
  pinAsk: null,
  cluesOpen: false,
  clues: { brand: "", supply: "", screen: "", wifi: "" },
  handedOff: false,
  boundary: false,
  pass: null,
  trialNote: "",
  job: {
    source: "doc",
    copies: 1,
    color: true,
    duplex: false,
    paper: "A4",
    orient: "portrait",
    quality: "표준",
    borderless: false,
    pin: "",
    scale: "fit",
  },
  rehearsal: null,
  toast: "",
  scanTimer: 0,
};

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[ch]));
}

function t(key, vars) {
  return window.I18n ? I18n.t(key, vars) : key;
}

function tr(text) {
  return window.I18n ? I18n.line(text) : String(text ?? "");
}

function packLabel(nameOrId) {
  const pack = Atlas.PACKS[nameOrId];
  return tr(pack ? pack.name : nameOrId);
}

function genLabel(gen) {
  if (!gen) return t("trust.genFallback");
  if (typeof gen === "string") return tr((Atlas.GENERATIONS[gen] && Atlas.GENERATIONS[gen].label) || gen);
  return tr(gen.label || t("trust.genFallback"));
}

function qualityLabel(value) {
  return t(QUALITY_KEYS[value] || "q.std");
}

function orientLabel(value) {
  return value === "landscape" ? t("orient.l") : t("orient.p");
}

function sourceLabelOf(id) {
  return t("src." + (id || "doc"));
}

function reasonText(reason) {
  const hit = tr(reason);
  if (!window.I18n || I18n.lang === "ko" || hit !== reason) return hit;
  const catalog = /^(.*) 카탈로그와 맞았습니다\.$/.exec(reason || "");
  if (catalog) return t("reason.catalog", { name: catalog[1] });
  return reason;
}

function logDetail(detail) {
  const hit = tr(detail);
  if (!window.I18n || I18n.lang === "ko" || hit !== detail) return hit;
  let match;
  if ((match = /^CMD에서 (.+) 를 봤습니다\.$/.exec(detail))) return t("log.cmd", { cmd: match[1] });
  if ((match = /^(.+) 계열로 봤습니다\.$/.exec(detail))) return t("log.brand", { brand: match[1] });
  if ((match = /^(.+) 과 가장 가깝습니다\.$/.exec(detail))) return t("log.nearModel", { model: match[1] });
  if ((match = /^(.+) 을 조립합니다\.$/.exec(detail))) return t("log.assemble", { pack: tr(match[1]) });
  if ((match = /^(.+?) · (.+)$/.exec(detail))) {
    const label = tr(match[1]);
    if (label !== match[1]) return label + " · " + match[2];
  }
  return detail;
}

function pieceName(name) {
  const hit = tr(name);
  if (!window.I18n || I18n.lang === "ko" || hit !== name) return hit;
  const width = /^(.*) 폭$/.exec(name);
  if (width) return t("piece.width", { lang: width[1] });
  return name;
}

function pieceWhy(why) {
  const hit = tr(why);
  if (!window.I18n || I18n.lang === "ko" || hit !== why) return hit;
  const ink = /^(.*) 잉크가 기대하는 색 순서로 바꿉니다\.$/.exec(why);
  if (ink) return t("why.ink", { brand: ink[1] });
  return why;
}

function noteText(note) {
  return note && note.key ? t(note.key) : (note && note.text) || "";
}

function fixLabel(fix) {
  if (!fix) return "";
  if (fix.key === "paper" && fix.to === "4x6") return t("fix.to4x6", { paper: fix.from || "" });
  if (fix.key === "paper") return t("fix.photoA4");
  const map = { duplex: "fix.duplex", borderless: "fix.border", color: "fix.color", quality: "fix.quality" };
  return map[fix.key] ? t(map[fix.key]) : (fix.label || "");
}

function statusText(entry) {
  const map = {
    "티켓만 준비됨": "status.ready",
    "다른 프린터로 넘긴 티켓": "status.passed",
    "이 티켓만 하위 팩으로 시험": "status.trial",
  };
  const key = map[entry.status];
  return key ? t(key) : (entry.status || "");
}

function jobTitle(entry) {
  const id = entry.options && entry.options.source;
  return id ? sourceLabelOf(id) : (entry.title || "");
}

function jobDetail(entry) {
  const options = entry.options;
  if (!options) return entry.detail || "";
  const item = state.saved.find((row) => row.uid === entry.printerUid);
  const pack = item ? packLabel(item.packName) : ((entry.detail || "").split(" · ")[0] || "");
  return pack + " · " + options.paper + " · " + t("sheet.copy", { n: options.copies });
}

function trialText() {
  const note = state.trialNote;
  if (!note) return "";
  if (typeof note === "string") return note;
  if (note.key === "trial.stuck") return t("toast.stuck");
  if (note.key === "trial.ticket") {
    return t("toast.trialTicket", {
      pack: packLabel(note.packId),
      result: note.ok ? t("trial.pass") : t("trial.blocked"),
      base: packLabel(note.baseId),
    });
  }
  if (note.key === "trial.rehearse") return t("toast.trialOnly", { pack: packLabel(note.packId), base: packLabel(note.baseId) });
  if (note.key === "trial.locked") return t("toast.lockedPack", { pack: packLabel(note.packId) });
  return "";
}

function applyChrome() {
  if (!window.I18n) return;
  document.documentElement.lang = I18n.htmlLang();
  document.title = t("docTitle");
  const nav = document.querySelector(".nav");
  if (nav) nav.setAttribute("aria-label", t("nav.menu"));
  document.querySelectorAll(".nav-btn").forEach((button) => {
    const label = button.querySelector("span");
    if (label) label.textContent = t("nav." + button.dataset.view);
  });
  const kicker = document.querySelector(".top .kicker");
  if (kicker) kicker.textContent = t("kicker");
  const select = document.querySelector("#lang");
  if (select && !select.dataset.ready) {
    I18n.langs.forEach((item) => {
      const option = document.createElement("option");
      option.value = item.id;
      option.textContent = item.native;
      select.appendChild(option);
    });
    select.dataset.ready = "1";
    select.addEventListener("change", () => {
      I18n.use(select.value);
      try { localStorage.setItem("print-atlas-lang", I18n.lang); } catch (err) { /* keep the choice for this view */ }
      render();
    });
  }
  if (select) {
    select.value = I18n.lang;
    select.setAttribute("aria-label", t("lang.label"));
  }
}

function load() {
  try {
    const data = JSON.parse(localStorage.getItem("print-atlas-v1") || "{}");
    state.saved = Array.isArray(data.saved) ? data.saved : [];
    state.jobs = Array.isArray(data.jobs) ? data.jobs.map((job, index) => Object.assign({ id: job && job.id ? job.id : `legacy-${index}` }, job)) : [];
    state.activeUid = data.activeUid || (state.saved[0] && state.saved[0].uid) || "";
  } catch {
    state.saved = [];
    state.jobs = [];
  }
}

function persist() {
  try {
    localStorage.setItem("print-atlas-v1", JSON.stringify({
      saved: state.saved,
      jobs: state.jobs,
      activeUid: state.activeUid,
    }));
    return true;
  } catch {
    return false;
  }
}

function active() {
  return state.saved.find((item) => item.uid === state.activeUid) || null;
}

function inkOf(generation) {
  return (Atlas.GENERATIONS[generation] || Atlas.GENERATIONS.classic).ink;
}

function titleOf(match) {
  const brand = match.printer.brand || "";
  const model = match.printer.model || "";
  if (!brand || model.toLowerCase().includes(brand.toLowerCase())) return model;
  return `${brand} ${model}`;
}

function sourceLabel(source) {
  if (source === "catalog") return t("source.catalog");
  if (source === "heuristic") return t("source.heuristic");
  return t("source.weak");
}

function recipeKb(recipe) {
  return (recipe || []).reduce((sum, item) => sum + (Number(item.kb) || 0), 0);
}

function formatKb(kb) {
  const amount = Math.abs(kb);
  return amount >= 1024 ? `${(amount / 1024).toFixed(1)} MB` : `${amount} KB`;
}

function savingOf(recipe) {
  const kb = recipeKb(recipe);
  const full = 12 * 1024;
  return { kb, pct: Math.max(0, Math.round((1 - kb / full) * 100)) };
}

function identityHtml(value) {
  const info = Atlas.inspectIdentity(value);
  if (!info.fields.length) return `<p class="muted live-hint">${esc(t("identity.hint"))}</p>`;
  return `<div class="chips" aria-live="polite">${info.fields.map((field) => {
    const key = field.key === "모델명" ? t("identity.model") : field.key;
    const stateLabel = field.state === "missing" ? t("identity.missing") : t("identity.ambiguous");
    return `<span class="parse ${esc(field.state)}"><b>${esc(key)}</b> ${field.value ? esc(field.value) : esc(stateLabel)}</span>`;
  }).join("")}</div>`;
}

function searchBlock(submitLabel) {
  return `
    <form class="search" data-act="search">
      <input name="q" aria-label="${esc(t("search.aria"))}" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="${esc(t("search.placeholder"))}" value="${esc(state.query)}">
      <button class="primary" type="submit">${submitLabel}</button>
    </form>
    <div class="identity-live">${identityHtml(state.query)}</div>
    <div class="chips" aria-label="${esc(t("search.aria"))}">
      ${IDENTITY_SAMPLES.map((sample) => `<button class="chip" type="button" data-act="fill" data-q="${esc(sample.value)}">${esc(t(sample.key))}</button>`).join("")}
    </div>`;
}

function overrideNote(printer, packId, recommendedId) {
  if (packId === recommendedId) return "";
  if (recommendedId === "legacy-host" && packId !== "legacy-host") return t("override.legacy");
  if (packId === "driverless" && !printer.airprint) return t("override.air");
  if (packId === "mobile-label" && !["label", "zpl", "epl", "receipt", "zink"].includes(printer.family)) return t("override.label");
  if (recommendedId === "driverless" && packId !== "driverless") return t("override.heavy");
  return t("override.other");
}

function genbar(current) {
  return `<div class="genbar">${Object.values(Atlas.GENERATIONS).map((gen) => `
    <div class="gen-stop ${gen.id === current ? "on" : ""}">
      <i class="swatch ${gen.ink}"></i>
      <b>${esc(tr(gen.label))}</b>
      <small>${esc(gen.era)}</small>
    </div>`).join("")}</div>`;
}

function renderActive() {
  const item = active();
  activeSlot().innerHTML = item ? `
    <button class="active-pill" type="button" data-act="go" data-view="print">
      <i class="dot ${esc(inkOf(item.printer.generation))}">${esc(inkOf(item.printer.generation))}</i>
      <span><b>${esc(item.printer.brand)} ${esc(item.printer.model)}</b><span>${esc(packLabel(item.packName))} · ${esc(item.size)}</span></span>
    </button>` : `<span class="muted">${esc(t("noneSaved"))}</span>`;
}

function renderHome() {
  return `
    <section class="hero">
      <div>
        <h2>${esc(t("home.h1"))}<br>${esc(t("home.h2"))}</h2>
        <p class="lede">${esc(t("home.lede"))}</p>
        ${searchBlock(t("home.search"))}
        <div class="chips">
          ${["Epson ET-2850", "HP LaserJet 1020", "Canon PIXMA G2010", "Brother HL-L2350DW", "Samsung ML-2160", "캐논 셀피 CP1300"].map((q) =>
            `<button class="chip" type="button" data-act="example" data-q="${esc(q)}">${esc(q)}</button>`).join("")}
          <button class="chip" type="button" data-act="toggle-clues">${esc(t("home.unknown"))}</button>
        </div>
      </div>
      <aside class="panel">
        <p class="kicker-sm">${esc(t("home.gens"))}</p>
        <h3>${esc(t("home.gensTitle"))}</h3>
        <p class="muted">${esc(t("home.gensBody"))}</p>
      </aside>
    </section>
    ${genbar("")}
    <div class="grid-3">
      ${story(t("story.1k"), "HP LaserJet 1020", t("story.1b"), "HP LaserJet 1020")}
      ${story(t("story.2k"), "Canon PIXMA G2010", t("story.2b"), "Canon PIXMA G2010")}
      ${story(t("story.3k"), "Epson ET-2850", t("story.3b"), "Epson ET-2850")}
    </div>
    <div class="steps">
      ${step("1", t("step.1t"), t("step.1b"))}
      ${step("2", t("step.2t"), t("step.2b"))}
      ${step("3", t("step.3t"), t("step.3b"))}
      ${step("4", t("step.4t"), t("step.4b"))}
    </div>
    <p class="footer-note">${esc(t("home.foot"))}</p>`;
}

function story(kicker, title, body, query) {
  return `<button class="story" type="button" data-act="example" data-q="${esc(query)}">
    <p class="kicker-sm">${esc(kicker)}</p><h3>${esc(title)}</h3><p class="muted">${esc(body)}</p>
  </button>`;
}
function step(n, title, body) {
  return `<div class="step"><b>${n} ${esc(title)}</b><span class="muted">${esc(body)}</span></div>`;
}

function renderFind() {
  const list = state.list;
  return `
    <div class="finder-head">
      <div>
        <h2 style="font-size:34px">${esc(t("find.h"))}</h2>
        <p class="lede">${esc(t("find.lede"))}</p>
      </div>
      <button class="primary" type="button" data-act="scan" ${state.scanning ? "disabled" : ""}>${state.scanning ? esc(t("find.scanning")) : esc(t("find.scan"))}</button>
    </div>
    ${searchBlock(t("find.search"))}
    <button class="ghost" type="button" data-act="toggle-clues">${state.cluesOpen ? esc(t("find.cluesClose")) : esc(t("find.clues"))}</button>
    ${state.cluesOpen ? clueCard() : ""}
    ${state.scanLog.length ? `<ul class="log">${state.scanLog.map((line) => `<li><b>${esc(t("find.log"))}</b><span>${esc(line.indexOf("scan.") === 0 ? t(line) : line)}</span></li>`).join("")}</ul>` : ""}
    ${state.scanHits ? `<div class="device-grid" style="margin-top:14px">${Atlas.SAMPLE_NETWORK.map(renderSample).join("")}</div>` : ""}
    ${list && list.kind === "list" ? `
      <section style="margin-top:18px">
        <h3>${esc(t("find.near", { q: list.query }))}</h3>
        <p class="muted">${esc(t("find.nearHelp"))}</p>
        <div class="device-grid">${list.hits.map((printer) => renderChoice(printer)).join("")}</div>
      </section>` : ""}`;
}

function clueCard() {
  const brands = ["epson", "hp", "canon", "brother", "samsung", "xerox"];
  const supplies = ["tank", "cartridge", "toner", "thermal", "photo"];
  const hits = state.clues.brand ? Atlas.narrowByClues(state.clues.brand, state.clues) : [];
  const shown = hits.slice(0, 8);
  const sibling = hits.length > 1 && Atlas.hasWifiSibling(hits);
  const choice = (group, value, label) => `<button type="button" class="chip ${state.clues[group] === value ? "on" : ""}" data-act="clue" data-group="${group}" data-value="${esc(value)}">${esc(label)}</button>`;
  return `<section class="panel clue-card">
    <p class="kicker-sm">${esc(t("clue.k"))}</p>
    <h3>${esc(t("clue.h"))}</h3>
    <div class="field"><label>${esc(t("clue.brand"))}</label><div class="chips">${brands.map((id) => choice("brand", id, t("brand." + id))).join("")}</div></div>
    <div class="field"><label>${esc(t("clue.supply"))}</label><div class="chips">${supplies.map((id) => choice("supply", id, t("supply." + id))).join("")}<button type="button" class="chip ${state.clues.supply === "" ? "on" : ""}" data-act="clue" data-group="supply" data-value="">${esc(t("clue.unknown"))}</button></div></div>
    <div class="field"><label>${esc(t("clue.screen"))}</label><div class="chips">${choice("screen", "yes", t("yn.yes"))}${choice("screen", "no", t("yn.no"))}<button type="button" class="chip ${state.clues.screen === "" ? "on" : ""}" data-act="clue" data-group="screen" data-value="">${esc(t("clue.unknown"))}</button></div></div>
    <div class="field"><label>${esc(t("clue.wifi"))}</label><div class="chips">${choice("wifi", "yes", t("yn.yes"))}${choice("wifi", "no", t("yn.no"))}<button type="button" class="chip ${state.clues.wifi === "" ? "on" : ""}" data-act="clue" data-group="wifi" data-value="">${esc(t("clue.unknown"))}</button></div></div>
    ${sibling ? `<div class="note warn">${esc(t("clue.sibling"))}</div>` : ""}
    <p class="meta">${state.clues.brand ? (hits.length ? esc(t("clue.count", { n: hits.length })) : esc(t("clue.empty"))) : esc(t("clue.pick"))}</p>
    <div class="device-grid">${shown.map((printer) => renderChoice(printer)).join("")}</div>
  </section>`;
}

function renderSample(row) {
  const printer = Atlas.CATALOG.find((item) => item.id === row.id);
  const pack = Atlas.PACKS[printer.pack];
  return `<button class="device" type="button" data-act="example" data-q="${esc(printer.brand + " " + printer.model)}">
    <header><span class="tag">${esc(row.via)}</span><i class="swatch ${esc(inkOf(printer.generation))}"></i></header>
    <h3>${esc(printer.brand)} ${esc(printer.model)}</h3>
    <p class="meta">${esc(tr(Atlas.GENERATIONS[printer.generation].label))} · ${esc(tr(pack.name))} · ${esc(t("sample.signal"))} ${esc(row.rssi)}</p>
    <p class="muted">${esc(t("sample.device"))}</p>
  </button>`;
}

function renderChoice(printer) {
  return `<button class="device" type="button" data-act="example" data-q="${esc(printer.brand + " " + printer.model)}">
    <header><span class="tag">${esc(tr(Atlas.GENERATIONS[printer.generation].label))}</span></header>
    <h3>${esc(printer.brand)} ${esc(printer.model)}</h3>
    <p class="meta">${esc(tr(Atlas.PACKS[printer.pack].name))} · ${esc(printer.year)}</p>
  </button>`;
}

function renderResult() {
  const match = state.match;
  if (!match || match.kind !== "match") {
    return `<section class="panel gate"><h2 style="font-size:32px">${esc(t("result.emptyH"))}</h2><p>${esc(t("result.emptyP"))}</p><button class="primary" type="button" data-act="go" data-view="find">${esc(t("result.goFind"))}</button></section>`;
  }
  const printer = match.printer;
  const save = savingOf(match.recipe);
  const sib = peersOf(printer);
  return `
    <section class="split">
      <div class="stack">
        <div class="panel">
          <div class="head-row">
            <div>
              <p class="kicker-sm">${esc(sourceLabel(match.source))} · ${esc(t("result.conf", { n: match.confidence }))}</p>
              <h2 style="font-size:34px">${esc(titleOf(match))}</h2>
              <p class="meta">${esc(printer.year)} · ${esc(genLabel(match.generation))} · ${esc((printer.languages || []).join(" · ") || t("result.noLang"))}</p>
            </div>
            <div class="ring" style="--p:${Number(match.confidence) || 0}"><span>${esc(match.confidence)}</span></div>
          </div>
          <p>${esc(reasonText(match.reason))}</p>
          <div class="pills">${(printer.connections || []).map((link) => `<span class="tag">${esc({ wifi: "Wi-Fi", usb: "USB", bluetooth: t("link.bt") }[link] || link)}</span>`).join("")}
            ${printer.color ? `<span class="tag">${esc(t("tag.color"))}</span>` : `<span class="tag">${esc(t("tag.mono"))}</span>`}
            ${printer.duplex ? `<span class="tag">${esc(t("tag.duplex"))}</span>` : ""}
            ${printer.borderless ? `<span class="tag">${esc(t("tag.borderless"))}</span>` : ""}
            ${printer.airprint ? `<span class="tag">${esc(t("tag.air"))}</span>` : `<span class="tag">${esc(t("tag.noAir"))}</span>`}
          </div>
        </div>
        ${genbar(printer.generation)}
        <div class="banner">${esc(caution(printer, match.pack))}</div>
        ${match.confidence < 50 ? `<div class="chips" aria-label="${esc(t("clue.brand"))}">${["Epson", "HP", "Canon", "Brother", "Samsung"].map((brand) =>
          `<button class="chip" type="button" data-act="refine" data-brand="${esc(brand)}">${esc(t("result.refine", { brand }))}</button>`).join("")}</div>` : ""}
        ${match.alternatives.length ? `<div><p class="kicker-sm">${esc(t("result.other"))}</p><div class="chips">${match.alternatives.map((item) =>
          `<button class="chip" type="button" data-act="example" data-q="${esc(item.brand + " " + item.model)}">${esc(item.brand)} ${esc(item.model)}</button>`).join("")}</div></div>` : ""}
      </div>
      <div class="stack">
        <div class="panel">
          <div class="between"><h3>${esc(tr(match.pack.name))}</h3><b>${esc(match.size)}</b></div>
          <p class="muted">${esc(tr(match.pack.summary))}</p>
          <p>${esc(t("result.light", { pct: save.pct }))}</p>
          <div class="recipe">${match.recipe.map((item) => `
            <div class="slip"><div><b>${esc(pieceName(item.name))} <em class="badge">${esc(tr(item.badge || "조각"))}</em></b><span>${esc(pieceWhy(item.why))}</span></div><span class="kb">${esc(item.kb)} KB</span></div>`).join("")}</div>
          ${compareHtml(match)}
        </div>
        <div class="paths">
          ${pathCard(match, match.recommendedPack || match.pack.id, t("path.primary"), false)}
          ${match.fallback ? pathCard(match, match.fallback.id, t("path.fallback"), true) : `<div class="path"><b>${esc(t("path.only"))}</b><p class="muted">${esc(t("path.onlyBody"))}</p></div>`}
        </div>
        <div class="actions">
          <button class="primary" type="button" data-act="adopt" data-go="print">${esc(t("adopt.print"))}</button>
          <button class="ghost" type="button" data-act="adopt">${esc(t("adopt.keep"))}</button>
          ${match.overridden ? `<button class="mini" type="button" data-act="restore-auto">${esc(t("adopt.auto"))}</button>` : ""}
        </div>
      </div>
    </section>
    ${sib.length ? `<section style="margin-top:18px"><h3>${esc(t("result.peers"))}</h3><div class="sibs" style="margin-top:10px">${sib.map((item) => `
      <button class="sib ${item.model === printer.model ? "on" : ""}" type="button" data-act="example" data-q="${esc(item.brand + " " + item.model)}">
        <small>${esc(tr(Atlas.GENERATIONS[item.generation].label))}</small>
        <b>${esc(item.model)}</b>
        <small>${esc(tr(Atlas.PACKS[item.pack].name))}</small>
      </button>`).join("")}</div></section>` : ""}
    <section style="margin-top:18px"><h3>${esc(t("result.why"))}</h3><ul class="log">${match.log.map((line) => `<li><b>${esc(tr(line.step))}</b><span>${esc(logDetail(line.detail))}</span></li>`).join("")}</ul></section>`;
}

function compareHtml(match) {
  if (!match.overridden || !match.recommendedRecipe) return "";
  const now = recipeKb(match.recipe);
  const recommended = recipeKb(match.recommendedRecipe);
  const delta = now - recommended;
  const change = delta === 0 ? t("compare.same") : `${delta > 0 ? "+" : "−"}${formatKb(delta)}`;
  return `
    <div class="compare" aria-label="${esc(t("compare.auto"))}">
      <div class="cell"><span>${esc(t("compare.auto"))}</span><b>${esc(tr(match.recommendedName))}</b><span>${esc(match.recommendedSize)}</span></div>
      <div class="cell now"><span>${esc(t("compare.now"))}</span><b>${esc(tr(match.pack.name))}</b><span>${esc(match.size)} · ${esc(change)}</span></div>
    </div>
    <div class="note warn">${esc(overrideNote(match.printer, match.pack.id, match.recommendedPack))}</div>`;
}

function pathCard(match, packId, label, isFallback) {
  const pack = Atlas.PACKS[packId];
  if (!pack) return "";
  const on = match.pack.id === packId;
  return `<button class="path ${on ? "on" : ""}" type="button" data-act="pack" data-pack="${esc(packId)}">
    <small>${esc(label)}</small>
    <b>${esc(tr(pack.name))}</b>
    <small>${esc(tr(pack.tag))}${isFallback ? " · " + esc(t("path.fb")) : ""}</small>
  </button>`;
}

function peersOf(printer) {
  return ["legacy", "classic", "transitional", "modern"].map((generation) => {
    const group = Atlas.CATALOG.filter((item) => item.brandId === printer.brandId && item.generation === generation && !["receipt", "zink", "label"].includes(item.family));
    return group.find((item) => item.id === printer.id) || group[0];
  }).filter(Boolean);
}

function caution(printer, pack) {
  if (pack.id === "legacy-host") return t("caution.legacy");
  if (pack.id === "driverless") return t("caution.driverless");
  if (pack.id === "mobile-label") return t("caution.label");
  if (printer.family === "megatank") return t("caution.tank");
  if (!printer.airprint) return t("caution.weak");
  return t("caution.default");
}

function renderPrint() {
  const item = active();
  if (!item) {
    return `<section class="panel gate"><h2 style="font-size:32px">${esc(t("print.emptyH"))}</h2><p>${esc(t("print.emptyP"))}</p><button class="primary" type="button" data-act="go" data-view="find">${esc(t("print.find"))}</button></section>`;
  }
  const job = state.job;
  return `
    ${trustBand(item)}
    ${passPanel()}
    ${boundarySheet(item)}
    <div class="studio">
      <form class="controls panel" data-act="enqueue">
        <p class="kicker-sm">${esc(packLabel(item.packName))} · ${esc(item.size)}</p>
        <h3>${esc(item.printer.brand)} ${esc(item.printer.model)}</h3>
        ${osPrintOffer(item)}
        ${symptomBox(item)}
        <div class="field"><label>${esc(t("field.content"))}</label><div class="seg">${SOURCES.map((source) =>
          `<button type="button" class="${job.source === source ? "on" : ""}" data-act="source" data-source="${source}">${esc(sourceLabelOf(source))}</button>`).join("")}</div></div>
        <div class="field"><label>${esc(t("field.paper"))}</label><div class="seg">
          ${["A4", "Letter", "A5", "4x6"].map((paper) => `<button type="button" class="${job.paper === paper ? "on" : ""}" data-act="opt" data-key="paper" data-value="${paper}">${paper}</button>`).join("")}
        </div></div>
        <div class="field"><label>${esc(t("field.orient"))}</label><div class="seg">
          <button type="button" class="${job.orient === "portrait" ? "on" : ""}" data-act="opt" data-key="orient" data-value="portrait">${esc(t("orient.p"))}</button>
          <button type="button" class="${job.orient === "landscape" ? "on" : ""}" data-act="opt" data-key="orient" data-value="landscape">${esc(t("orient.l"))}</button>
          <button type="button" class="${job.scale === "fit" ? "on" : ""}" data-act="opt" data-key="scale" data-value="fit">${esc(t("scale.fit"))}</button>
          <button type="button" class="${job.scale === "actual" ? "on" : ""}" data-act="opt" data-key="scale" data-value="actual">${esc(t("scale.actual"))}</button>
        </div></div>
        <div class="field"><label>${esc(t("field.quality"))}</label><div class="seg">
          ${["초안", "표준", "사진"].map((quality) => `<button type="button" class="${job.quality === quality ? "on" : ""}" data-act="opt" data-key="quality" data-value="${quality}">${esc(qualityLabel(quality))}</button>`).join("")}
        </div></div>
        <div class="chips">
          <button type="button" class="opt ${job.color ? "on" : ""}" data-act="toggle" data-key="color">${esc(t("opt.color"))}</button>
          <button type="button" class="opt ${job.duplex ? "on" : ""}" data-act="toggle" data-key="duplex">${esc(t("opt.duplex"))}</button>
          <button type="button" class="opt ${job.borderless ? "on" : ""}" data-act="toggle" data-key="borderless">${esc(t("opt.bleed"))}</button>
        </div>
        <div class="between">
          <span>${esc(t("copies", { n: job.copies }))}</span>
          <span>
            <button class="mini" type="button" data-act="step" data-dir="-1">−</button>
            <button class="mini" type="button" data-act="step" data-dir="1">+</button>
          </span>
        </div>
        <div class="field"><label for="pin">${esc(t("pin.label"))}</label>
          <input id="pin" inputmode="numeric" maxlength="4" placeholder="${esc(t("pin.placeholder"))}" value="${esc(job.pin)}">
        </div>
        <button class="primary" type="submit">${esc(t("enqueue"))}</button>
        ${rehearsalBlock()}
      </form>
      <div class="paper-wrap">
        ${sheet(item, job)}
        <div class="queue">${state.jobs.slice(0, 4).map((entry) => renderJob(entry)).join("")}</div>
      </div>
    </div>`;
}

function canHandOff(item) {
  if (!item) return false;
  return item.packId === "driverless" || item.packId === "page-lang";
}

function osPrintOffer(item) {
  if (canHandOff(item)) {
    const note = item.packId === "page-lang" ? t("os.note.page") : t("os.note.modern");
    return `<button class="ghost" type="button" data-act="os-print">${esc(t("os.btn"))}</button><p class="os-note muted">${esc(note)}</p>`;
  }
  if (item.packId === "legacy-host" || item.packId === "mobile-label") {
    return `<p class="os-note muted">${esc(t("os.legacy"))}</p>`;
  }
  return `<p class="os-note muted">${esc(t("os.other", { pack: packLabel(item.packName) }))}</p>`;
}

function boundarySheet(item) {
  if (!state.boundary || !canHandOff(item)) return "";
  const job = state.job;
  const orient = orientLabel(job.orient);
  const margin = job.borderless ? t("margin.bleed") : t("margin.std");
  return `<section class="panel boundary" aria-label="${esc(t("boundary.aria"))}">
    <p class="kicker-sm">${esc(t("boundary.k"))}</p>
    <h3>${esc(t("boundary.h"))}</h3>
    <div class="compare">
      <div class="cell"><b>${esc(t("boundary.app"))}</b><span>${esc(t("boundary.preview"))}</span><span>${esc(t("boundary.paper", { paper: job.paper }))}</span><span>${esc(t("boundary.orient", { orient }))}</span><span>${esc(t("boundary.margin", { margin }))}</span></div>
      <div class="cell now"><b>${esc(t("boundary.phone"))}</b><span>${esc(t("boundary.copies", { n: job.copies }))}</span><span>${esc(t("boundary.device"))}</span></div>
    </div>
    ${item.packId === "page-lang" ? `<p class="os-note">${esc(t("boundary.pcl"))}</p>` : ""}
    <p class="boundary-warn">${esc(t("boundary.warn"))}</p>
    <div class="actions">
      <button class="neutral-btn" type="button" data-act="boundary-go">${esc(t("boundary.go"))}</button>
      <button class="ghost" type="button" data-act="boundary-close">${esc(t("boundary.back"))}</button>
    </div>
  </section>`;
}

function trustBand(item) {
  const rehearsal = state.rehearsal;
  const rehearsalCell = !rehearsal ? ["wait", t("trust.notYet")] : rehearsal.ok ? ["ok", t("trust.ok")] : ["wait", t("trust.blocked")];
  const outputCell = state.handedOff ? ["neutral", t("trust.handed")] : ["wait", t("trust.unsent")];
  return `<section class="trust" aria-label="${esc(t("trust.aria"))}">
    <article><small>${esc(t("trust.gen"))}</small><b>${esc(t("trust.est", { n: item.confidence || "—", gen: genLabel(item.generation) }))}</b></article>
    <article class="${rehearsalCell[0]}"><small>${esc(t("trust.rehearsal"))}</small><b>${esc(rehearsalCell[1])}</b></article>
    <article class="${outputCell[0]}"><small>${esc(t("trust.out"))}</small><b>${esc(outputCell[1])}</b></article>
  </section>`;
}

function symptomBox(item) {
  const pending = item.pendingPackFix;
  const symptoms = [["blank", "symptom.blank"], ["garbled", "symptom.garbled"], ["silent", "symptom.silent"]];
  return `<div class="symptom">
    <p class="kicker-sm">${esc(t("symptom.k"))}</p>
    <div class="chips">${symptoms.map(([id, key]) => `<button type="button" class="chip" data-act="symptom" data-uid="${esc(item.uid)}" data-symptom="${id}">${esc(t(key))}</button>`).join("")}</div>
    ${state.trialNote ? `<div class="note ok">${esc(trialText())}</div>` : ""}
    ${pending ? `<div class="note warn">${esc(t("symptom.pending", { pack: packLabel(pending.packId) }))}</div>
      <div class="actions">
        <button class="primary" type="button" data-act="lock-pack" data-uid="${esc(item.uid)}">${esc(t("symptom.lock"))}</button>
        <button class="ghost" type="button" data-act="keep-trial" data-uid="${esc(item.uid)}">${esc(t("symptom.keep"))}</button>
      </div>` : ""}
  </div>`;
}

function rehearsalBlock() {
  if (!state.rehearsal) return "";
  const fixes = state.rehearsal.fixes || [];
  return `<div class="stack">
    ${state.rehearsal.notes.map((note) => `<div class="note ${esc(note.level)}">${esc(noteText(note))}</div>`).join("")}
    ${fixes.length ? `<button class="primary" type="button" data-act="autofix">${esc(t("autofix"))}</button><p class="muted">${fixes.map((fix) => esc(fixLabel(fix))).join(" · ")}</p>` : ""}
  </div>`;
}

function sheet(item, job) {
  const mono = !job.color || !item.printer.color;
  const body = {
    doc: `<p class="doc-kicker">${esc(t("sheet.doc.k"))}</p><h3>${esc(t("sheet.doc.h"))}</h3><p>${esc(t("sheet.doc.p1", { pack: packLabel(item.packName) }))}</p><p>${esc(t("sheet.doc.p2", { paper: job.paper, orient: orientLabel(job.orient), quality: qualityLabel(job.quality), copies: job.copies }))}</p><p>${esc(t("sheet.doc.p3"))}</p>`,
    photo: `<p class="doc-kicker">${esc(t("sheet.photo.k"))}</p><div class="still"><i></i><b></b></div><p>${esc(t("sheet.photo.p"))}</p>`,
    web: `<p class="doc-kicker">${esc(t("sheet.web.k"))}</p><h3>${esc(t("sheet.web.h"))}</h3><p>${esc(t("sheet.web.p"))}</p><p>${esc(t("sheet.web.s"))}</p>`,
    contact: `<p class="doc-kicker">${esc(t("sheet.contact.k"))}</p><div class="person"><i class="avatar"></i><div><h3>${esc(t("sheet.contact.h"))}</h3><p>${esc(t("sheet.contact.p"))}<br>desk@printatlas.local</p></div></div><p>${esc(t("sheet.contact.a"))}</p>`,
    sms: `<p class="doc-kicker">${esc(t("sheet.sms.k"))}</p><div class="thread"><div class="bubble">${esc(t("sheet.sms.1"))}</div><div class="bubble me">${esc(t("sheet.sms.2"))}</div><div class="bubble">${esc(t("sheet.sms.3"))}</div></div>`,
    test: `<p class="doc-kicker">${esc(t("sheet.test.k"))}</p><h3>${esc(t("sheet.test.h"))}</h3><div class="nozzle"><i class="bars c"></i><i class="bars m"></i><i class="bars y"></i><i class="bars k"></i></div><p class="cross"><span>+</span><span>+</span><span>+</span></p><p>${esc(t("sheet.test.p"))}</p>`,
  }[job.source];
  const klass = ["paper", job.orient === "landscape" ? "landscape" : "portrait", job.borderless ? "bleed" : "", mono ? "mono" : "", job.scale === "actual" ? "actual" : "fit"].filter(Boolean).join(" ");
  return `<div class="sheet-stack ${job.copies > 1 ? "multi" : ""}">
    ${job.copies > 1 ? `<span class="copy-count">${esc(t("sheet.copy", { n: job.copies }))}</span>` : ""}
    <article class="${klass}">
      ${body}
      <footer class="ticket-foot"><span>${esc(item.printer.model)}</span><span>${esc(mono ? t("sheet.mono") : t("sheet.color"))} · ${esc(job.pin ? t("sheet.pin") : t("sheet.open"))} · ${esc(job.scale === "fit" ? t("sheet.fit") : t("sheet.actual"))}</span></footer>
    </article>
  </div>`;
}

function renderPacks() {
  const counts = {};
  Atlas.CATALOG.forEach((printer) => { counts[printer.pack] = (counts[printer.pack] || 0) + 1; });
  return `
    <h2 style="font-size:34px">${esc(t("packs.h"))}</h2>
    <p class="lede">${esc(t("packs.lede"))}</p>
    <div class="pack-grid" style="margin-top:14px">
      ${Object.values(Atlas.PACKS).map((pack) => `
        <article class="pack-card">
          <header><span class="tag">${esc(tr(pack.tag))}</span><i class="swatch ${esc(pack.ink)}"></i></header>
          <h3>${esc(tr(pack.name))}</h3>
          <p>${esc(tr(pack.summary))}</p>
          <p class="meta">${esc(t("packs.count", { n: counts[pack.id] || 0, kb: pack.core.kb }))}</p>
          <button class="mini" type="button" data-act="open-pack" data-pack="${esc(pack.id)}">${state.openPack === pack.id ? esc(t("packs.close")) : esc(t("packs.open"))}</button>
          ${state.openPack === pack.id ? `<div class="models">${Atlas.CATALOG.filter((printer) => printer.pack === pack.id).map((printer) =>
            `<button type="button" data-act="example" data-q="${esc(printer.brand + " " + printer.model)}">${esc(printer.model)}</button>`).join("")}</div>` : ""}
        </article>`).join("")}
    </div>`;
}

function jobLocked(entry) {
  return !!(entry && entry.pin && !state.unlocked[entry.id]);
}

function renderJob(entry) {
  const locked = jobLocked(entry);
  const asking = state.pinAsk && state.pinAsk.id === entry.id;
  return `<article class="job-row">
    <div>
      <b>${esc(jobTitle(entry))} · ${esc(entry.printer)}</b>
      ${locked ? `<div class="lock">${esc(t("job.locked"))}</div>` : `<div class="muted">${esc(jobDetail(entry))} · ${esc(statusText(entry))}</div>${entry.trialPackId || entry.trialPackName ? `<div class="meta">${esc(t("job.trial", { pack: packLabel(entry.trialPackId || entry.trialPackName) }))}</div>` : ""}`}
      ${asking ? `<div class="pin-ask">
        <input id="unlock-pin" inputmode="numeric" maxlength="4" aria-label="${esc(t("job.pinAria"))}" placeholder="${esc(t("job.pinPh"))}" value="">
        <button class="primary" type="button" data-act="confirm-pin">${esc(t("job.confirm"))}</button>
        ${state.pinAsk.error ? `<span class="lock">${esc(t(state.pinAsk.error))}</span>` : ""}
      </div>` : ""}
    </div>
    <div class="actions">
      ${locked ? `<button class="mini" type="button" data-act="ask-pin" data-id="${esc(entry.id)}" data-mode="open">${esc(t("job.open"))}</button>` : `<button class="mini" type="button" data-act="pass-open" data-id="${esc(entry.id)}">${esc(t("job.pass"))}</button>`}
      <button class="mini" type="button" data-act="ask-pin" data-id="${esc(entry.id)}" data-mode="reuse">${esc(t("job.reuse"))}</button>
    </div>
  </article>`;
}

function renderMine() {
  const empty = !state.saved.length && !state.jobs.length;
  return `
    <div class="between">
      <h2 style="font-size:34px">${esc(t("mine.h"))}</h2>
      <div class="actions">
        <button class="mini" type="button" data-act="export-json">${esc(t("mine.export"))}</button>
        <button class="mini" type="button" data-act="import-json">${esc(t("mine.import"))}</button>
        <button class="mini" type="button" data-act="clear-jobs" ${state.jobs.length ? "" : "disabled"}>${esc(t("mine.clear"))}</button>
      </div>
    </div>
    ${empty ? `<section class="panel gate"><h3>${esc(t("mine.emptyH"))}</h3><p>${esc(t("mine.emptyP"))}</p><button class="primary" type="button" data-act="go" data-view="find">${esc(t("mine.go"))}</button></section>` : `
    <div class="saved-grid" style="margin-top:12px">
      ${state.saved.map((item) => `
        <article class="saved">
          <header>
            <h3>${esc(item.printer.brand)} ${esc(item.printer.model)}</h3>
            ${item.uid === state.activeUid ? `<span class="tag">${esc(t("saved.using"))}</span>` : ""}
          </header>
          <p class="meta">${esc(t("saved.conf", { pack: packLabel(item.packName), size: item.size, n: item.confidence }))}</p>
          ${symptomBox(item)}
          <div class="actions">
            <button class="primary" type="button" data-act="use-saved" data-uid="${esc(item.uid)}">${esc(t("mine.use"))}</button>
            <button class="ghost" type="button" data-act="drop-saved" data-uid="${esc(item.uid)}">${esc(t("mine.drop"))}</button>
          </div>
        </article>`).join("")}
    </div>`}
    ${state.jobs.length ? `<section style="margin-top:18px"><h3>${esc(t("mine.tickets"))}</h3>${state.jobs.map((entry) => renderJob(entry)).join("")}</section>` : ""}
    <p class="footer-note">${esc(t("mine.foot"))}</p>`;
}

function render() {
  applyChrome();
  document.querySelectorAll(".nav-btn").forEach((button) => {
    const view = button.dataset.view;
    const on = view === state.view || (view === "find" && state.view === "result");
    button.classList.toggle("active", on);
  });
  titleEl().textContent = t(TITLE_KEYS[state.view] || "title.home");
  renderActive();
  const pages = { home: renderHome, find: renderFind, result: renderResult, print: renderPrint, packs: renderPacks, mine: renderMine };
  viewEl().innerHTML = (pages[state.view] || renderHome)();
  const toast = document.querySelector("#toast");
  toast.hidden = !state.toast;
  toast.textContent = state.toast || "";
}

function showToast(message) {
  state.toast = message;
  render();
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => {
    state.toast = "";
    render();
  }, 2600);
}

function runQuery(query) {
  const text = String(query || "").trim();
  state.query = text;
  if (!text) {
    showToast(t("toast.needModel"));
    return;
  }
  const result = Atlas.match(text);
  if (result.kind === "list") {
    state.list = result;
    state.view = "find";
    render();
    return;
  }
  state.list = null;
  state.match = result;
  state.match.recommendedPack = result.pack.id;
  state.match.recommendedName = result.pack.name;
  state.match.recommendedSize = result.size;
  state.match.recommendedRecipe = result.recipe.map((item) => Object.assign({}, item));
  state.match.overridden = false;
  state.match.printer = Object.assign({}, result.printer, { pack: result.pack.id });
  state.view = "result";
  state.rehearsal = null;
  render();
}

function applyPack(packId) {
  if (!state.match || !Atlas.PACKS[packId]) return;
  const printer = Object.assign({}, state.match.printer, { pack: packId });
  state.match.pack = Atlas.PACKS[packId];
  state.match.recipe = Atlas.buildRecipe(printer, packId);
  state.match.size = Atlas.recipeSize(state.match.recipe);
  state.match.overridden = packId !== state.match.recommendedPack;
  render();
}

function snapshot() {
  const match = state.match;
  const uid = `${match.printer.brand}-${match.printer.model}-${match.pack.id}`.replace(/\s+/g, "-");
  return {
    uid,
    printer: match.printer,
    generation: match.generation,
    packId: match.pack.id,
    packName: match.pack.name,
    size: match.size,
    confidence: match.confidence,
    source: match.source,
    recipe: match.recipe,
    fallbackId: match.fallback ? match.fallback.id : "",
    symptomCounts: {},
    pendingPackFix: null,
    savedAt: Date.now(),
  };
}

function adopt(goPrint) {
  if (!state.match || state.match.kind !== "match") return;
  const item = snapshot();
  const previous = state.saved.find((saved) => saved.uid === item.uid);
  if (previous) {
    item.symptomCounts = previous.symptomCounts || {};
    item.pendingPackFix = previous.pendingPackFix || null;
  }
  state.saved = [item, ...state.saved.filter((saved) => saved.uid !== item.uid)];
  state.activeUid = item.uid;
  persist();
  state.rehearsal = null;
  state.handedOff = false;
  state.boundary = false;
  state.trialNote = "";
  if (goPrint) state.view = "print";
  showToast(goPrint ? t("toast.adoptPrint") : t("toast.adoptKeep"));
}

function planFixes(item, job) {
  const printer = item.printer;
  const fixes = [];
  const labelish = ["label", "zpl", "epl", "receipt", "zink"].includes(printer.family);
  const smallPhoto = printer.photo || labelish || printer.family === "selphy";
  if (job.duplex && !printer.duplex) fixes.push({ key: "duplex", to: false, label: "양면 → 단면" });
  if (job.borderless && !printer.borderless) fixes.push({ key: "borderless", to: false, label: "여백 없음 → 표준 여백" });
  if (job.color && !printer.color) fixes.push({ key: "color", to: false, label: "컬러 → 먹색" });
  if (job.paper === "4x6" && !smallPhoto) fixes.push({ key: "paper", to: "A4", label: "4×6 → A4" });
  if (labelish && job.paper !== "4x6") fixes.push({ key: "paper", to: "4x6", from: job.paper, label: `${job.paper} → 4×6` });
  if (job.quality === "사진" && item.packId === "legacy-host") fixes.push({ key: "quality", to: "표준", label: "사진 품질 → 표준" });
  return fixes;
}

function rehearse(item, job) {
  const notes = [];
  const printer = item.printer;
  const labelish = ["label", "zpl", "epl", "receipt", "zink"].includes(printer.family);
  if (job.duplex && !printer.duplex) notes.push({ level: "bad", key: "note.duplex" });
  if (job.borderless && !printer.borderless) notes.push({ level: "bad", key: "note.border" });
  if (job.color && !printer.color) notes.push({ level: "warn", key: "note.color" });
  if (job.paper === "4x6" && !printer.photo && !labelish && printer.family !== "selphy") notes.push({ level: "warn", key: "note.photo" });
  if (labelish && job.paper !== "4x6") notes.push({ level: "warn", key: "note.label" });
  if (job.quality === "사진" && item.packId === "legacy-host") notes.push({ level: "warn", key: "note.quality" });
  if (job.pin && !/^\d{4}$/.test(job.pin)) notes.push({ level: "bad", key: "note.pin" });
  if (item.packId === "legacy-host" && !(printer.connections || []).includes("wifi")) notes.push({ level: "ok", key: "note.usb" });
  const blocked = notes.some((note) => note.level === "bad");
  if (!blocked) notes.push({ level: "ok", key: job.pin ? "note.passPin" : "note.pass" });
  return { ok: !blocked, notes, fixes: planFixes(item, job) };
}

function restoreAuto() {
  const match = state.match;
  if (!match || !match.recommendedPack) return;
  match.pack = Atlas.PACKS[match.recommendedPack];
  match.recipe = (match.recommendedRecipe || Atlas.buildRecipe(match.printer, match.recommendedPack)).map((item) => Object.assign({}, item));
  match.size = match.recommendedSize || Atlas.recipeSize(match.recipe);
  match.overridden = false;
  match.printer = Object.assign({}, match.printer, { pack: match.recommendedPack });
  render();
}

function applyRecommendedFixes() {
  const item = active();
  if (!item) return;
  const pinInput = document.querySelector("#pin");
  if (pinInput) state.job.pin = pinInput.value.replace(/\D/g, "").slice(0, 4);
  const plan = rehearse(item, state.job);
  plan.fixes.forEach((fix) => { state.job[fix.key] = fix.to; });
  state.rehearsal = rehearse(item, state.job);
  showToast(state.rehearsal.ok ? t("toast.autofixOk") : t("toast.autofixPartial"));
}

function demotionOf(item) {
  const next = item.fallbackId;
  if (!next || next === item.packId || !Atlas.PACKS[next]) return "";
  const rank = { driverless: 0, "raster-ink": 1, "page-lang": 1, "legacy-host": 2, "mobile-label": 3 };
  if ((rank[next] ?? 1) < (rank[item.packId] ?? 1)) return "";
  return next;
}

function reportSymptom(uid, symptom) {
  const item = state.saved.find((row) => row.uid === uid);
  if (!item) return;
  const next = demotionOf(item);
  if (!next) {
    state.trialNote = { key: "trial.stuck" };
    showToast(trialText());
    return;
  }
  item.symptomCounts = item.symptomCounts || {};
  item.symptomCounts[symptom] = (item.symptomCounts[symptom] || 0) + 1;
  const pack = Atlas.PACKS[next];
  let touched = 0;
  state.jobs.forEach((job) => {
    if (job.printerUid === uid && !jobLocked(job)) {
      job.trialPackId = next;
      job.trialPackName = pack.name;
      job.status = "이 티켓만 하위 팩으로 시험";
      touched += 1;
    }
  });
  const trial = Object.assign({}, item, { packId: next, packName: pack.name });
  state.rehearsal = rehearse(trial, state.job);
  state.trialNote = touched
    ? { key: "trial.ticket", packId: next, ok: state.rehearsal.ok, baseId: item.packId }
    : { key: "trial.rehearse", packId: next, baseId: item.packId };
  item.pendingPackFix = item.symptomCounts[symptom] >= 2 ? { symptom, packId: next } : null;
  persist();
  showToast(item.pendingPackFix ? t("toast.symptomAgain") : t("toast.symptomOnce"));
}

function lockSavedPack(uid) {
  const item = state.saved.find((row) => row.uid === uid);
  if (!item || !item.pendingPackFix) return;
  const packId = item.pendingPackFix.packId;
  const pack = Atlas.PACKS[packId];
  if (!pack) return;
  const printer = Object.assign({}, item.printer, { pack: packId });
  item.packId = packId;
  item.packName = pack.name;
  item.recipe = Atlas.buildRecipe(printer, packId);
  item.size = Atlas.recipeSize(item.recipe);
  item.printer = printer;
  item.fallbackId = "";
  item.pendingPackFix = null;
  state.handedOff = false;
  state.trialNote = { key: "trial.locked", packId };
  persist();
  showToast(t("toast.lockedPack", { pack: packLabel(packId) }));
}

function keepTrial(uid) {
  const item = state.saved.find((row) => row.uid === uid);
  if (!item) return;
  item.pendingPackFix = null;
  persist();
  showToast(t("toast.keepTrial"));
}

function handoffToOs() {
  const item = active();
  if (!canHandOff(item)) return;
  const pinInput = document.querySelector("#pin");
  if (pinInput) state.job.pin = pinInput.value.replace(/\D/g, "").slice(0, 4);
  const result = rehearse(item, state.job);
  state.rehearsal = result;
  if (!result.ok) {
    state.boundary = false;
    state.handedOff = false;
    showToast(t("toast.needRehearsal"));
    return;
  }
  state.boundary = true;
  render();
}

function confirmBoundary() {
  const item = active();
  if (!canHandOff(item) || !state.boundary) return;
  const pinInput = document.querySelector("#pin");
  if (pinInput) state.job.pin = pinInput.value.replace(/\D/g, "").slice(0, 4);
  const result = rehearse(item, state.job);
  state.rehearsal = result;
  if (!result.ok) {
    state.boundary = false;
    showToast(t("toast.needRehearsal"));
    return;
  }
  const style = document.getElementById("print-page") || document.createElement("style");
  style.id = "print-page";
  const size = { A4: "A4", Letter: "letter", A5: "A5", "4x6": "4in 6in" }[state.job.paper] || "A4";
  const orient = state.job.orient === "landscape" ? "landscape" : "portrait";
  const margin = state.job.borderless ? "0" : "12mm";
  style.textContent = `@media print { @page { size: ${size} ${orient}; margin: ${margin}; } }`;
  document.head.appendChild(style);
  state.boundary = false;
  render();
  const mark = () => {
    window.removeEventListener("afterprint", mark);
    state.handedOff = true;
    render();
  };
  window.addEventListener("afterprint", mark);
  window.print();
}

function copyOptions(options) {
  const source = options || {};
  return {
    source: source.source || "doc",
    copies: source.copies || 1,
    color: source.color !== false,
    duplex: !!source.duplex,
    paper: source.paper || "A4",
    orient: source.orient || "portrait",
    quality: source.quality || "표준",
    borderless: !!source.borderless,
    pin: "",
    scale: source.scale || "fit",
  };
}

function passTargets() {
  if (!state.pass) return [];
  return state.saved.filter((item) => item.uid !== state.pass.sourcePrinterUid);
}

function passTarget() {
  return state.saved.find((item) => item.uid === (state.pass && state.pass.targetUid)) || null;
}

function droppedFixes(item, options) {
  const keys = new Set(["duplex", "borderless", "color", "paper", "quality"]);
  return planFixes(item, options).filter((fix) => keys.has(fix.key));
}

function beginPass(jobId) {
  const entry = state.jobs.find((job) => job.id === jobId);
  if (!entry) return;
  if (jobLocked(entry)) {
    showToast(t("toast.pinLocked"));
    return;
  }
  const sourcePrinterUid = entry.printerUid || "";
  const others = state.saved.filter((item) => item.uid !== sourcePrinterUid);
  if (!others.length) {
    showToast(t("toast.noTarget"));
    return;
  }
  state.pass = {
    sourceId: entry.id,
    sourcePrinterUid,
    options: copyOptions(entry.options),
    targetUid: "",
  };
  state.boundary = false;
  state.view = "print";
  render();
}

function passPanel() {
  if (!state.pass) return "";
  const others = passTargets();
  const target = passTarget();
  const result = target ? rehearse(target, state.pass.options) : null;
  const dropped = target ? droppedFixes(target, state.pass.options) : [];
  return `<section class="panel pass-panel">
    <p class="kicker-sm">${esc(t("pass.k"))}</p>
    <h3>${esc(t("pass.h"))}</h3>
    <p class="muted">${esc(t("pass.note"))}</p>
    <div class="chips">${others.map((item) => `<button type="button" class="chip ${state.pass.targetUid === item.uid ? "on" : ""}" data-act="pass-target" data-uid="${esc(item.uid)}">${esc(item.printer.brand)} ${esc(item.printer.model)}</button>`).join("")}</div>
    ${target ? `
      <p class="meta">${esc(packLabel(target.packName))}</p>
      <div class="note ${dropped.length ? "warn" : "ok"}">${dropped.length ? dropped.map((fix) => esc(fixLabel(fix))).join(" · ") : esc(t("pass.none"))}</div>
      ${result && !result.ok ? `<div class="note bad">${esc(t("pass.blocked"))}</div>` : ""}
      ${result && (dropped.length || !result.ok) ? `<button class="primary" type="button" data-act="pass-fix">${esc(t("autofix"))}</button>` : ""}
      ${result && result.ok && !dropped.length ? `<button class="primary" type="button" data-act="pass-confirm">${esc(t("pass.confirm"))}</button>` : ""}
    ` : `<p class="muted">${esc(t("pass.pick"))}</p>`}
    <div class="actions"><button class="ghost" type="button" data-act="pass-cancel">${esc(t("pass.close"))}</button></div>
  </section>`;
}

function applyPassFixes() {
  const item = passTarget();
  if (!state.pass || !item) return;
  rehearse(item, state.pass.options).fixes.forEach((fix) => { state.pass.options[fix.key] = fix.to; });
  render();
}

function confirmPass() {
  const item = passTarget();
  if (!state.pass || !item) return;
  const result = rehearse(item, state.pass.options);
  if (!result.ok || droppedFixes(item, state.pass.options).length) {
    showToast(t("toast.dropsRemain"));
    return;
  }
  const options = copyOptions(state.pass.options);
  const sourceId = state.pass.sourceId;
  state.jobs.unshift({
    id: `job-${Date.now()}`,
    title: SOURCE_KO[options.source] || "문서",
    printer: `${item.printer.brand} ${item.printer.model}`,
    detail: `${item.packName} · ${options.paper} · ${options.copies}매`,
    status: "다른 프린터로 넘긴 티켓",
    at: Date.now(),
    pin: "",
    printerUid: item.uid,
    passedFrom: sourceId,
    options,
  });
  state.jobs = state.jobs.slice(0, 12);
  state.job = options;
  state.activeUid = item.uid;
  state.rehearsal = rehearse(item, state.job);
  state.handedOff = false;
  state.boundary = false;
  state.pass = null;
  state.view = "print";
  persist();
  showToast(t("toast.passed"));
}

function enqueue(event) {
  const item = active();
  if (!item) return;
  const pinInput = event && event.target && event.target.querySelector("#pin");
  if (pinInput) state.job.pin = pinInput.value.replace(/\D/g, "").slice(0, 4);
  const result = rehearse(item, state.job);
  state.rehearsal = result;
  if (!result.ok) {
    render();
    return;
  }
  const pin = /^\d{4}$/.test(state.job.pin) ? state.job.pin : "";
  state.jobs.unshift({
    id: `job-${Date.now()}`,
    title: SOURCE_KO[state.job.source] || "문서",
    printer: `${item.printer.brand} ${item.printer.model}`,
    detail: `${item.packName} · ${state.job.paper} · ${state.job.copies}매`,
    status: "티켓만 준비됨",
    at: Date.now(),
    pin,
    printerUid: item.uid,
    options: {
      source: state.job.source,
      copies: state.job.copies,
      color: state.job.color,
      duplex: state.job.duplex,
      paper: state.job.paper,
      orient: state.job.orient,
      quality: state.job.quality,
      borderless: state.job.borderless,
      scale: state.job.scale,
    },
  });
  state.jobs = state.jobs.slice(0, 12);
  persist();
  showToast(t("toast.ticket"));
}

function onClick(event) {
  const el = event.target.closest("[data-act]");
  if (!el || el.closest("form[data-act='search']") && el.dataset.act === "search") return;
  const act = el.dataset.act;
  if (act === "go") {
    state.view = el.dataset.view;
    render();
    return;
  }
  if (act === "example") {
    runQuery(el.dataset.q);
    return;
  }
  if (act === "scan") {
    startScan();
    return;
  }
  if (act === "pack") {
    applyPack(el.dataset.pack);
    return;
  }
  if (act === "adopt") {
    adopt(el.dataset.go === "print");
    return;
  }
  if (act === "rematch" || act === "restore-auto") {
    restoreAuto();
    return;
  }
  if (act === "fill") {
    state.query = el.dataset.q || "";
    const input = document.querySelector("#view input[name=q]");
    if (input) input.value = state.query;
    const live = document.querySelector("#view .identity-live");
    if (live) live.innerHTML = identityHtml(state.query);
    return;
  }
  if (act === "autofix") {
    applyRecommendedFixes();
    return;
  }
  if (act === "export-json") {
    exportBackup();
    return;
  }
  if (act === "import-json") {
    const picker = document.querySelector("#backup-file");
    if (picker) picker.click();
    return;
  }
  if (act === "ask-pin") {
    askPin(el.dataset.id, el.dataset.mode);
    return;
  }
  if (act === "confirm-pin") {
    confirmPin();
    return;
  }
  if (act === "toggle-clues") {
    state.cluesOpen = !state.cluesOpen;
    state.view = "find";
    render();
    return;
  }
  if (act === "clue") {
    state.clues[el.dataset.group] = el.dataset.value || "";
    state.cluesOpen = true;
    state.view = "find";
    render();
    return;
  }
  if (act === "symptom") {
    reportSymptom(el.dataset.uid, el.dataset.symptom);
    return;
  }
  if (act === "lock-pack") {
    lockSavedPack(el.dataset.uid);
    return;
  }
  if (act === "keep-trial") {
    keepTrial(el.dataset.uid);
    return;
  }
  if (act === "os-print") {
    handoffToOs();
    return;
  }
  if (act === "boundary-go") {
    confirmBoundary();
    return;
  }
  if (act === "boundary-close") {
    state.boundary = false;
    render();
    return;
  }
  if (act === "pass-open") {
    beginPass(el.dataset.id);
    return;
  }
  if (act === "pass-target") {
    if (state.pass) state.pass.targetUid = el.dataset.uid || "";
    render();
    return;
  }
  if (act === "pass-fix") {
    applyPassFixes();
    return;
  }
  if (act === "pass-confirm") {
    confirmPass();
    return;
  }
  if (act === "pass-cancel") {
    state.pass = null;
    render();
    return;
  }
  if (act === "refine") {
    runQuery(`${el.dataset.brand} ${state.query}`);
    return;
  }
  if (act === "source") {
    state.job.source = el.dataset.source;
    state.rehearsal = null;
    render();
    return;
  }
  if (act === "opt") {
    state.job[el.dataset.key] = el.dataset.value;
    state.rehearsal = null;
    render();
    return;
  }
  if (act === "toggle") {
    state.job[el.dataset.key] = !state.job[el.dataset.key];
    state.rehearsal = null;
    render();
    return;
  }
  if (act === "step") {
    state.job.copies = Math.min(20, Math.max(1, state.job.copies + Number(el.dataset.dir)));
    render();
    return;
  }
  if (act === "open-pack") {
    state.openPack = state.openPack === el.dataset.pack ? "" : el.dataset.pack;
    render();
    return;
  }
  if (act === "use-saved") {
    state.activeUid = el.dataset.uid;
    state.view = "print";
    state.rehearsal = null;
    persist();
    render();
    return;
  }
  if (act === "drop-saved") {
    state.saved = state.saved.filter((item) => item.uid !== el.dataset.uid);
    if (state.activeUid === el.dataset.uid) state.activeUid = (state.saved[0] && state.saved[0].uid) || "";
    persist();
    render();
    return;
  }
  if (act === "clear-jobs") {
    state.jobs = [];
    persist();
    render();
  }
}

function onSubmit(event) {
  const form = event.target.closest("form[data-act]");
  if (!form) return;
  event.preventDefault();
  if (form.dataset.act === "search") {
    runQuery(new FormData(form).get("q"));
    return;
  }
  if (form.dataset.act === "enqueue") enqueue(event);
}

function startScan() {
  clearInterval(state.scanTimer);
  state.view = "find";
  state.scanning = true;
  state.scanHits = false;
  state.scanLog = [];
  const lines = ["scan.1", "scan.2", "scan.3", "scan.4"];
  render();
  let index = 0;
  state.scanTimer = setInterval(() => {
    if (index < lines.length) state.scanLog.push(lines[index]);
    index += 1;
    if (index > lines.length) {
      clearInterval(state.scanTimer);
      state.scanning = false;
      state.scanHits = true;
    }
    if (state.view === "find") render();
  }, 450);
}

function askPin(id, mode) {
  const entry = state.jobs.find((job) => job.id === id);
  if (!entry) return;
  if (!entry.pin || state.unlocked[entry.id]) {
    state.pinAsk = null;
    if (mode === "reuse") reuseJob(entry);
    else {
      state.unlocked[entry.id] = true;
      render();
    }
    return;
  }
  state.pinAsk = { id, mode, error: "" };
  render();
}

function confirmPin() {
  const ask = state.pinAsk;
  if (!ask) return;
  const input = document.querySelector("#unlock-pin");
  const typed = (input ? input.value : "").replace(/\D/g, "").slice(0, 4);
  const entry = state.jobs.find((job) => job.id === ask.id);
  if (!entry || typed !== entry.pin) {
    state.pinAsk = { id: ask.id, mode: ask.mode, error: "toast.pinBad" };
    render();
    return;
  }
  state.unlocked[entry.id] = true;
  state.pinAsk = null;
  if (ask.mode === "reuse") reuseJob(entry);
  else showToast(t("toast.pinOk"));
}

function reuseJob(entry) {
  if (entry.options) state.job = Object.assign({}, state.job, entry.options, { pin: "" });
  if (entry.printerUid && state.saved.some((item) => item.uid === entry.printerUid)) state.activeUid = entry.printerUid;
  state.view = "print";
  state.rehearsal = null;
  persist();
  showToast(t("toast.reuse"));
}

function backupError(key, vars) {
  const err = new Error(t(key, vars));
  err.atlas = true;
  return err;
}

function readBackup(data) {
  if (!data || typeof data !== "object" || Array.isArray(data)) throw backupError("backup.notObject");
  if (!Array.isArray(data.saved) || !Array.isArray(data.jobs)) throw backupError("backup.notAtlas");
  data.saved.forEach((item, index) => {
    if (!item || !item.printer || !item.printer.model || !item.packId || !item.uid) {
      throw backupError("backup.printer", { n: index + 1 });
    }
  });
  data.jobs.forEach((job, index) => {
    if (!job || typeof job.title !== "string" || typeof job.printer !== "string") {
      throw backupError("backup.job", { n: index + 1 });
    }
  });
  state.saved = data.saved.slice(0, 40);
  state.jobs = data.jobs.slice(0, 40).map((job, index) => Object.assign({ id: job.id || `import-${index}` }, job));
  state.activeUid = state.saved.some((item) => item.uid === data.activeUid) ? data.activeUid : ((state.saved[0] && state.saved[0].uid) || "");
  state.unlocked = {};
  state.pinAsk = null;
  if (!persist()) throw backupError("backup.space");
}

async function exportBackup() {
  const payload = {
    format: "print-atlas-backup",
    version: 1,
    exportedAt: new Date().toISOString(),
    saved: state.saved,
    jobs: state.jobs,
    activeUid: state.activeUid,
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const file = new File([blob], "print-atlas-backup.json", { type: "application/json" });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    try {
      await navigator.share({ files: [file], title: t("share.title") });
      showToast(t("toast.share"));
      return;
    } catch (err) {
      if (err && err.name === "AbortError") return;
    }
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "print-atlas-backup.json";
  link.rel = "noopener";
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2500);
  showToast(t("toast.saved"));
}

document.body.addEventListener("click", onClick);
document.body.addEventListener("submit", onSubmit);
document.body.addEventListener("input", (event) => {
  if (event.target.id === "pin") state.job.pin = event.target.value.replace(/\D/g, "").slice(0, 4);
  if (event.target.name === "q") {
    state.query = event.target.value;
    const live = event.target.closest(".main") && event.target.closest(".main").querySelector(".identity-live");
    if (live) live.innerHTML = identityHtml(state.query);
  }
});
document.querySelector("#backup-file").addEventListener("change", (event) => {
  const file = event.target.files && event.target.files[0];
  event.target.value = "";
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      readBackup(JSON.parse(String(reader.result || "")));
      state.view = "mine";
      showToast(t("toast.imported", { saved: state.saved.length, jobs: state.jobs.length }));
    } catch (err) {
      showToast(err && err.atlas && err.message ? err.message : t("toast.badJson"));
    }
  };
  reader.onerror = () => showToast(t("toast.readFail"));
  reader.readAsText(file);
});

if (window.I18n) {
  let stored = "ko";
  try { stored = localStorage.getItem("print-atlas-lang") || "ko"; } catch (err) { stored = "ko"; }
  I18n.use(stored);
}
load();
render();
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  navigator.serviceWorker.register("./sw.js").catch(() => {});
}
