import assert from "node:assert/strict";
import net from "node:net";
import { describe, it, before, after } from "node:test";
import { createHelper, isPrivateHost, loadCode } from "../public/raw-print-helper.mjs";

describe("raw print helper", () => {
  let printer;
  let helper;
  let received = Buffer.alloc(0);
  let printerPort;
  let helperPort;

  before(async () => {
    printer = net.createServer((s) => s.on("data", (c) => (received = Buffer.concat([received, c]))));
    await new Promise((r) => printer.listen(0, "127.0.0.1", r));
    printerPort = printer.address().port;
    helper = createHelper({ allowLoopback: true, allowedPorts: new Set([printerPort]) });
    await new Promise((r) => helper.listen(0, "127.0.0.1", r));
    helperPort = helper.address().port;
  });
  after(() => {
    helper.close();
    printer.close();
  });

  it("forwards bytes untouched — no HTTP text", async () => {
    const body = Buffer.from([0x1b, 0x45, 1, 2, 3, 0x1b, 0x45]);
    const r = await fetch(`http://127.0.0.1:${helperPort}/print?host=127.0.0.1&port=${printerPort}`, { method: "POST", body });
    assert.equal(r.status, 200);
    await new Promise((r2) => setTimeout(r2, 50));
    assert.deepEqual(received, body);
  });

  it("probes open and refuses other targets", async () => {
    const ok = await (await fetch(`http://127.0.0.1:${helperPort}/probe?host=127.0.0.1&port=${printerPort}`)).json();
    assert.equal(ok.open, true);
    const bad = await fetch(`http://127.0.0.1:${helperPort}/print?host=8.8.8.8&port=9100`, { method: "POST", body: "x" });
    assert.equal(bad.status, 400);
  });

  it("answers CORS preflight for private network access", async () => {
    const r = await fetch(`http://127.0.0.1:${helperPort}/print`, { method: "OPTIONS", headers: { Origin: "https://example.app" } });
    assert.equal(r.headers.get("access-control-allow-private-network"), "true");
  });

  it("only allows private hosts", () => {
    assert.equal(isPrivateHost("192.168.0.20"), true);
    assert.equal(isPrivateHost("hp.local"), true);
    assert.equal(isPrivateHost("1.1.1.1"), false);
    assert.equal(isPrivateHost("127.0.0.1"), false);
  });
});

describe("raw print helper connection code", () => {
  let printer;
  let helper;
  let received = Buffer.alloc(0);
  let printerPort;
  let helperPort;
  const base = () => `http://127.0.0.1:${helperPort}`;

  before(async () => {
    printer = net.createServer((s) => s.on("data", (c) => (received = Buffer.concat([received, c]))));
    await new Promise((r) => printer.listen(0, "127.0.0.1", r));
    printerPort = printer.address().port;
    helper = createHelper({ allowLoopback: true, allowedPorts: new Set([printerPort]), code: "123456" });
    await new Promise((r) => helper.listen(0, "127.0.0.1", r));
    helperPort = helper.address().port;
  });
  after(() => {
    helper.close();
    printer.close();
  });

  it("ping works without a code and says a code is needed", async () => {
    const body = await (await fetch(`${base()}/ping`)).json();
    assert.equal(body.ok, true);
    assert.equal(body.needsCode, true);
  });

  it("refuses printing without the right code", async () => {
    const url = `${base()}/print?host=127.0.0.1&port=${printerPort}`;
    const none = await fetch(url, { method: "POST", body: "x" });
    assert.equal(none.status, 401);
    const wrong = await fetch(url, { method: "POST", body: "x", headers: { "X-Helper-Code": "000000" } });
    assert.equal(wrong.status, 401);
    assert.equal(received.length, 0);
  });

  it("accepts the right code", async () => {
    const r = await fetch(`${base()}/print?host=127.0.0.1&port=${printerPort}`, {
      method: "POST",
      body: Buffer.from([1, 2, 3]),
      headers: { "X-Helper-Code": "123456" },
    });
    assert.equal(r.status, 200);
    assert.equal((await fetch(`${base()}/check`, { headers: { "X-Helper-Code": "123456" } })).status, 200);
  });

  it("locks out after repeated wrong codes", async () => {
    let last = 0;
    for (let i = 0; i < 12; i++) last = (await fetch(`${base()}/check`, { headers: { "X-Helper-Code": "999999" } })).status;
    assert.equal(last, 429);
  });

  it("creates a 6-digit code once and reuses it", async () => {
    const { mkdtempSync, rmSync } = await import("node:fs");
    const { tmpdir } = await import("node:os");
    const dir = mkdtempSync(`${tmpdir()}/nuguna-`);
    const file = `${dir}/code`;
    const a = loadCode(file);
    assert.match(a, /^\d{6}$/);
    assert.equal(loadCode(file), a);
    rmSync(dir, { recursive: true });
  });
});
