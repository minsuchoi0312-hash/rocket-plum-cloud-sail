import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  DEFAULT_SETTINGS,
  LOCAL_PRINTER_ID,
  type JobRecord,
  type PrintMethod,
  type Printer,
  type PrintSettings,
  type RememberedSettings,
} from "../domain/model";
import { localPrinter } from "../discovery/discover";
import { applyRemembered } from "../domain/remember";

export type Screen =
  | "onboarding"
  | "home"
  | "printers"
  | "add-printer"
  | "preview"
  | "progress"
  | "result"
  | "settings"
  | "licenses";

export type DocumentKind = "image" | "pdf" | "test";

export interface SessionImage {
  name: string;
  url: string;
  blob: Blob;
}

export interface PrintSession {
  kind: DocumentKind;
  name: string;
  images: SessionImage[];
  pdfBytes: Uint8Array | null;
  previewUrl: string | null;
  pageCount: number;
  settings: PrintSettings;
}

export interface ResultState {
  status: "SUCCESS" | "PARTIAL" | "FAILURE";
  error?: JobRecord["error"];
  printerName: string;
  usedLocalDialog?: boolean;
  usedHelper?: boolean;
  directRaw?: boolean;
  jobState?: "completed" | "processing" | "unknown";
  sentPages?: number;
  totalPages?: number;
  convertedFormat?: string;
  downloadUrl?: string;
  downloadName?: string;
  packetBytes?: number;
}

interface AppState {
  hydrated: boolean;
  onboardingDone: boolean;
  screen: Screen;
  printers: Printer[];
  selectedPrinterId: string | null;
  jobs: JobRecord[];
  session: PrintSession | null;
  result: ResultState | null;
  searching: boolean;
  lan: { localIp: string | null; subnet: string | null };
  setHydrated: () => void;
  completeOnboarding: () => void;
  go: (screen: Screen) => void;
  upsertPrinter: (printer: Printer) => void;
  removePrinter: (id: string) => void;
  selectPrinter: (id: string | null) => void;
  markSuccess: (id: string, info?: { method?: PrintMethod; settings?: RememberedSettings }) => void;
  setSearching: (v: boolean) => void;
  setLan: (lan: { localIp: string | null; subnet: string | null }) => void;
  setSession: (session: PrintSession | null) => void;
  updateSettings: (patch: Partial<PrintSettings>) => void;
  setPdfBytes: (bytes: Uint8Array, pageCount: number) => void;
  setResult: (result: ResultState | null) => void;
  addJob: (job: JobRecord) => void;
  clearJobs: () => void;
  selectedPrinter: () => Printer | undefined;
}

const emptySession = (): PrintSession => ({
  kind: "image",
  name: "",
  images: [],
  pdfBytes: null,
  previewUrl: null,
  pageCount: 1,
  settings: { ...DEFAULT_SETTINGS },
});

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      hydrated: true,
      onboardingDone: true,
      screen: "home",
      printers: [localPrinter()],
      selectedPrinterId: LOCAL_PRINTER_ID,
      jobs: [],
      session: null,
      result: null,
      searching: false,
      lan: { localIp: null, subnet: null },
      setHydrated: () => set({ hydrated: true }),
      completeOnboarding: () => set({ onboardingDone: true, screen: "home" }),
      go: (screen) => set({ screen }),
      upsertPrinter: (printer) =>
        set((s) => {
          const idx = s.printers.findIndex((p) => p.id === printer.id);
          const printers =
            idx >= 0
              ? s.printers.map((p, i) => (i === idx ? { ...p, ...printer, id: p.id } : p))
              : [...s.printers, printer];
          const selectedPrinterId = s.selectedPrinterId ?? printer.id;
          return { printers, selectedPrinterId };
        }),
      removePrinter: (id) =>
        set((s) => ({
          printers: s.printers.filter((p) => p.id !== id),
          selectedPrinterId: s.selectedPrinterId === id ? (s.printers.find((p) => p.id !== id)?.id ?? null) : s.selectedPrinterId,
        })),
      selectPrinter: (id) => set({ selectedPrinterId: id }),
      markSuccess: (id, info) =>
        set((s) => ({
          printers: s.printers.map((p) =>
            p.id === id
              ? {
                  ...p,
                  lastSuccessAt: Date.now(),
                  ...(info?.method ? { lastMethod: info.method } : {}),
                  ...(info?.settings ? { lastSettings: info.settings } : {}),
                }
              : p,
          ),
        })),
      setSearching: (searching) => set({ searching }),
      setLan: (lan) => set({ lan }),
      setSession: (session) =>
        set((s) => {
          if (s.session?.previewUrl) URL.revokeObjectURL(s.session.previewUrl);
          for (const img of s.session?.images ?? []) {
            try {
              URL.revokeObjectURL(img.url);
            } catch {
              /* already revoked */
            }
          }
          if (!session) return { session: null };
          const merged = { ...emptySession(), ...session };
          if (merged.kind !== "test") {
            const printer = s.printers.find((p) => p.id === s.selectedPrinterId);
            merged.settings = applyRemembered(merged.settings, printer);
          }
          return { session: merged };
        }),
      updateSettings: (patch) =>
        set((s) =>
          s.session ? { session: { ...s.session, settings: { ...s.session.settings, ...patch } } } : s,
        ),
      setPdfBytes: (bytes, pageCount) =>
        set((s) => (s.session ? { session: { ...s.session, pdfBytes: bytes, pageCount } } : s)),
      setResult: (result) => set({ result }),
      addJob: (job) => set((s) => ({ jobs: [job, ...s.jobs].slice(0, 30) })),
      clearJobs: () => set({ jobs: [] }),
      selectedPrinter: () => {
        const s = get();
        return s.printers.find((p) => p.id === s.selectedPrinterId);
      },
    }),
    {
      name: "publicprint.v2",
      skipHydration: true,
      partialize: (s) => ({
        onboardingDone: s.onboardingDone,
        printers: s.printers,
        selectedPrinterId: s.selectedPrinterId,
        jobs: s.jobs,
        lan: s.lan,
      }),
    },
  ),
);

export function sortedPrinters(printers: Printer[]): Printer[] {
  return [...printers].sort((a, b) => {
    if (a.source === "LOCAL" && b.source !== "LOCAL") return -1;
    if (b.source === "LOCAL" && a.source !== "LOCAL") return 1;
    const as = a.lastSuccessAt ?? 0;
    const bs = b.lastSuccessAt ?? 0;
    if (as !== bs) return bs - as;
    return a.displayName.localeCompare(b.displayName, "ko");
  });
}
