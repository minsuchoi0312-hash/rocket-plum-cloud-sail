import {
  dpiForQuality,
  usesInAppEngine,
  type ColorMode,
  type Duplex,
  type JobErrorCode,
  type PaperSize,
  type Printer,
  type PrintSettings,
} from "../domain/model";
import { JobError } from "./ipp/client";
import { applyAttributes, getJobSnapshot, getPrinterAttributes, printJob } from "./ipp/client";
import { watchJob } from "./ipp/job-status";
import { buildPrintJob, printerUri } from "./ipp/codec";
import { pageSizePoints, resolvePaper } from "../render/paper";
import { convertBatches, formatExtension, formatLabel, formatMime, pickEngineFormat, type ConvertedJob } from "./engine";
import { rasterPages, type RasterPage } from "../render/rasterize";
import { blobDownloadUrl, printRasterViaOs } from "./os-helper";
import { wakePrinter } from "../discovery/wake";
import { helperSend } from "./helper";

export interface SubmitProgress {
  percent: number;
  label: string;
}

export interface SubmitResult {
  status: "SUCCESS" | "PARTIAL" | "FAILURE";
  packetBytes?: number;
  printer: Printer;
  usedLocalDialog?: boolean;
  usedHelper?: boolean;
  directRaw?: boolean;
  convertedFormat?: string;
  downloadUrl?: string;
  downloadName?: string;
  /** 프린터가 알려준 작업 상태. 알 수 없으면 unknown(성공으로 취급). */
  jobState?: "completed" | "processing" | "unknown";
  /** 일부만 보냈을 때(PARTIAL): 보낸 쪽수와 전체 쪽수, 멈춘 이유. */
  sentPages?: number;
  totalPages?: number;
  error?: JobErrorCode;
}

function colorKeyword(color: ColorMode, printer: Printer): "color" | "monochrome" | "auto" {
  if (color === "MONO") return "monochrome";
  if (color === "COLOR") return "color";
  if (printer.supportsColor === false) return "monochrome";
  return "auto";
}

function sidesKeyword(duplex: Duplex): "one-sided" | "two-sided-long-edge" | "two-sided-short-edge" {
  if (duplex === "LONG_EDGE") return "two-sided-long-edge";
  if (duplex === "SHORT_EDGE") return "two-sided-short-edge";
  return "one-sided";
}

function mediaKeyword(paper: PaperSize, printer: Printer): string | undefined {
  const resolved = resolvePaper(paper);
  const want = pageSizePoints(resolved, "PORTRAIT").mediaKeyword;
  const supported = printer.mediaSupported;
  if (!supported || supported.length === 0) return want;
  return supported.includes(want) ? want : undefined;
}

function userName() {
  if (typeof navigator === "undefined") return "web";
  return (navigator.platform || "web").slice(0, 40);
}

export async function printViaBrowser(pdf: Uint8Array, copies = 1): Promise<{ url: string }> {
  let bytes = pdf;
  if (copies > 1) {
    const { repeatPdfCopies } = await import("../render/image-to-pdf");
    bytes = await repeatPdfCopies(pdf, copies);
  }
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  const blob = new Blob([copy.buffer], { type: "application/pdf" });
  const url = URL.createObjectURL(blob);
  const iframe = document.createElement("iframe");
  iframe.setAttribute("aria-hidden", "true");
  iframe.style.position = "fixed";
  iframe.style.inset = "0";
  iframe.style.width = "100%";
  iframe.style.height = "100%";
  iframe.style.border = "0";
  iframe.style.opacity = "0";
  iframe.style.pointerEvents = "none";
  iframe.src = url;
  document.body.appendChild(iframe);
  iframe.addEventListener("load", () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch {
      window.open(url, "_blank");
    }
  });
  return { url };
}

async function simulateSend(
  printer: Printer,
  document: Uint8Array,
  mime: string,
  settings: PrintSettings,
  jobName: string,
  onProgress: (p: SubmitProgress) => void,
  signal?: AbortSignal,
): Promise<SubmitResult> {
  onProgress({ percent: 70, label: "변환된 작업을 전송 중…" });
  const packet = buildPrintJob({
    printerUri: printerUri(printer.host, printer.port, printer.resourcePath, printer.secure),
    requestId: 2,
    jobName,
    userName: userName(),
    copies: settings.copies,
    documentFormat: mime,
    colorMode: colorKeyword(settings.color, printer),
    sides: settings.duplex === "NONE" ? undefined : sidesKeyword(settings.duplex),
    media: mediaKeyword(settings.paper, printer),
    document,
  });
  onProgress({ percent: 92, label: "응답 확인 중…" });
  return { status: "SUCCESS", packetBytes: packet.byteLength, printer };
}

type Source = { pdf: Uint8Array | null; images?: { blob: Blob }[] };

async function collectRasterPages(source: Source, settings: PrintSettings, signal?: AbortSignal): Promise<RasterPage[]> {
  const pages: RasterPage[] = [];
  for await (const { page } of rasterPages(source, settings, dpiForQuality(settings.quality), signal)) pages.push(page);
  return pages;
}

async function sendIpp(
  printer: Printer,
  bytes: Uint8Array,
  mime: string,
  settings: PrintSettings,
  jobName: string,
  signal?: AbortSignal,
) {
  const options = {
    copies: settings.copies,
    jobName,
    userName: userName(),
    documentFormat: mime,
    colorMode: colorKeyword(settings.color, printer),
    sides: settings.duplex === "NONE" ? undefined : sidesKeyword(settings.duplex),
    media: mediaKeyword(settings.paper, printer),
    signal,
  };
  try {
    return await printJob(printer, bytes, options);
  } catch (err) {
    if (err instanceof JobError && err.code === "TIMEOUT" && !err.direct) {
      await wakePrinter(printer, { signal, force: true }).catch(() => undefined);
      try {
        return await printJob(printer, bytes, options);
      } catch {
        throw err;
      }
    }
    throw err;
  }
}

/** 보낸 작업이 끝났는지 잠시 지켜본다. 확실한 프린터 문제(용지·토너·덮개·걸림)만 오류로 올린다. */
async function watchSentJob(
  printer: Printer,
  jobId: number | undefined,
  onProgress: (p: SubmitProgress) => void,
  signal?: AbortSignal,
): Promise<"completed" | "processing" | "unknown"> {
  if (jobId === undefined) return "unknown";
  onProgress({ percent: 94, label: "프린터 상태 확인 중…" });
  const watch = await watchJob(() => getJobSnapshot(printer, jobId, signal), {
    signal,
    timeoutMs: 20_000,
    onTick: (w) => {
      if (w.kind === "working") onProgress({ percent: 96, label: "프린터가 인쇄하는 중…" });
    },
  });
  if (watch.kind === "failed") throw new JobError(watch.code, watch.code);
  if (watch.kind === "done") return "completed";
  return watch.kind === "working" ? "processing" : "unknown";
}

export async function submitPrintJob(opts: {
  printer: Printer;
  pdf: Uint8Array | null;
  images?: { blob: Blob }[];
  settings: PrintSettings;
  jobName: string;
  onProgress: (p: SubmitProgress) => void;
  signal?: AbortSignal;
}): Promise<SubmitResult> {
  const { printer, pdf, images, settings, jobName, onProgress, signal } = opts;
  const source: Source = { pdf, images };

  if (typeof navigator !== "undefined" && navigator.onLine === false && printer.source !== "LOCAL") {
    throw new JobError("NO_NETWORK", "NO_NETWORK");
  }

  onProgress({ percent: 8, label: printer.source === "LOCAL" ? "문서 준비 중…" : "절전 깨우기 · 문서 준비" });

  const engine = usesInAppEngine(printer);
  const wakeP =
    printer.source === "LOCAL"
      ? Promise.resolve({ woke: false, skipped: true })
      : wakePrinter(printer, { signal }).catch(() => ({ woke: false, skipped: false }));
  const onPage = (done: number, total: number) =>
    onProgress({ percent: 20 + Math.round((35 * done) / Math.max(1, total)), label: `페이지 변환 중 (${done}/${total}쪽)` });
  const formatName = formatLabel(pickEngineFormat(printer));

  if (!engine && (!pdf || pdf.byteLength === 0)) throw new JobError("REJECTED", "REJECTED");

  if (printer.source === "LOCAL") {
    onProgress({ percent: 72, label: engine ? "이 컴퓨터 드라이버로 넘기는 중…" : "이 컴퓨터 인쇄 대화상자 여는 중…" });
    if (engine) {
      const pages = await collectRasterPages(source, settings, signal);
      const helper = await printRasterViaOs(pages, settings);
      onProgress({ percent: 100, label: "인쇄 대화상자를 열었습니다." });
      return {
        status: "SUCCESS",
        printer,
        usedLocalDialog: true,
        usedHelper: true,
        convertedFormat: formatName,
        downloadUrl: helper.url,
        downloadName: "print.html",
      };
    }
    const { url } = await printViaBrowser(pdf as Uint8Array, settings.copies);
    onProgress({ percent: 100, label: "인쇄 대화상자를 열었습니다." });
    return { status: "SUCCESS", printer, usedLocalDialog: true, downloadUrl: url, downloadName: "print.pdf" };
  }

  const wake = await wakeP;
  if (!wake.skipped) onProgress({ percent: 48, label: "절전에서 깨웠습니다" });

  if (printer.source === "DEMO") {
    if (!engine) return simulateSend(printer, pdf as Uint8Array, "application/pdf", settings, jobName, onProgress, signal);
    const chunks: Uint8Array[] = [];
    let packetBytes = 0;
    let mime = formatMime(pickEngineFormat(printer));
    for await (const batch of convertBatches(source, printer, settings, { signal, onPage, embedCopies: false })) {
      const sent = await simulateSend(printer, batch.bytes, batch.mime, settings, jobName, onProgress, signal);
      packetBytes += sent.packetBytes ?? 0;
      chunks.push(batch.bytes);
      mime = batch.mime;
    }
    const all = new Uint8Array(chunks.reduce((n, c) => n + c.length, 0));
    let o = 0;
    for (const c of chunks) {
      all.set(c, o);
      o += c.length;
    }
    return {
      status: "SUCCESS",
      printer,
      packetBytes,
      convertedFormat: formatName,
      downloadUrl: blobDownloadUrl(all, mime),
      downloadName: `print.${formatExtension(pickEngineFormat(printer))}`,
    };
  }

  if (printer.protocol === "RAW9100") {
    // 브라우저는 9100 포트로 순수 데이터를 보낼 수 없다(HTTP 문구가 그대로 인쇄됨).
    // PC 도우미가 켜져 있으면 도우미가 그대로 전달하고, 없으면 이 컴퓨터 드라이버로 넘긴다.
    let sentPages = 0;
    let totalPages = 0;
    let onlyBatch: ConvertedJob | null = null;
    let batches = 0;
    let stopped = false;
    for await (const batch of convertBatches(source, printer, settings, { signal, onPage })) {
      totalPages = batch.pagesTotal;
      onProgress({ percent: 68, label: `PC 도우미로 구형 프린터에 전송 중 (${batch.pagesDone}/${totalPages}쪽)` });
      if (!(await helperSend(printer.host, printer.port || 9100, batch.bytes, signal))) {
        stopped = true;
        break;
      }
      sentPages = batch.pagesDone;
      batches++;
      onlyBatch = batches === 1 ? batch : null;
    }
    if (!stopped && batches > 0) {
      onProgress({ percent: 100, label: "전송했습니다" });
      return {
        status: "SUCCESS",
        printer,
        directRaw: true,
        convertedFormat: formatName,
        packetBytes: onlyBatch?.bytes.byteLength,
        downloadUrl: onlyBatch ? blobDownloadUrl(onlyBatch.bytes, onlyBatch.mime) : undefined,
        downloadName: onlyBatch ? `print.${formatExtension(onlyBatch.format)}` : undefined,
      };
    }
    if (stopped && sentPages > 0) {
      return { status: "PARTIAL", printer, directRaw: true, convertedFormat: formatName, sentPages, totalPages, error: "TIMEOUT" };
    }
    onProgress({ percent: 84, label: "앱 도우미 · 이 컴퓨터 드라이버" });
    const pages = await collectRasterPages(source, settings, signal);
    await printRasterViaOs(pages, settings);
    onProgress({ percent: 100, label: "드라이버로 넘겼습니다" });
    return { status: "SUCCESS", printer, usedHelper: true, convertedFormat: formatName };
  }

  onProgress({ percent: 58, label: "프린터 속성 확인 중…" });
  let resolved = printer;
  try {
    const attrs = await getPrinterAttributes(printer, signal);
    resolved = applyAttributes(printer, attrs);
  } catch (err) {
    if (err instanceof JobError && err.code === "NO_NETWORK") throw err;
    if (!engine) {
      onProgress({ percent: 64, label: "IPP 응답이 없습니다. 직접 보내는 중…" });
      try {
        const sent = await sendIpp(printer, pdf as Uint8Array, "application/pdf", settings, jobName, signal);
        if (sent.opaque) {
          onProgress({ percent: 100, label: "프린터로 직접 보냈습니다" });
          return { status: "SUCCESS", printer, packetBytes: sent.byteLength, jobState: "unknown" };
        }
        const jobState = await watchSentJob(printer, sent.jobId, onProgress, signal);
        onProgress({ percent: 100, label: "전송 완료" });
        return { status: "SUCCESS", printer, packetBytes: sent.byteLength, jobState };
      } catch {
        onProgress({ percent: 86, label: "브라우저가 포트를 막았습니다. 인쇄 창을 엽니다…" });
        const { url } = await printViaBrowser(pdf as Uint8Array, settings.copies);
        onProgress({ percent: 100, label: "인쇄 창을 열었습니다" });
        return { status: "SUCCESS", printer, usedLocalDialog: true, downloadUrl: url, downloadName: "print.pdf" };
      }
    }
  }

  async function viaEngine(target: Printer): Promise<SubmitResult> {
    const name = formatLabel(pickEngineFormat(target));
    let sentPages = 0;
    let totalPages = 0;
    let packetBytes = 0;
    let lastJobId: number | undefined;
    for await (const batch of convertBatches(source, target, settings, { signal, onPage, embedCopies: false })) {
      totalPages = batch.pagesTotal;
      onProgress({ percent: 60 + Math.round((30 * batch.pagesDone) / Math.max(1, totalPages)), label: `${name} 전송 중 (${batch.pagesDone}/${totalPages}쪽)` });
      try {
        const sent = await sendIpp(target, batch.bytes, batch.mime, settings, jobName, signal);
        packetBytes += sent.byteLength;
        lastJobId = sent.jobId;
        sentPages = batch.pagesDone;
      } catch (err) {
        if (err instanceof JobError && (err.code === "UNSUPPORTED_FORMAT" || err.code === "TIMEOUT") && batch.batchIndex === 0) {
          onProgress({ percent: 86, label: "앱 도우미 · 이 컴퓨터 드라이버" });
          const pages = await collectRasterPages(source, settings, signal);
          await printRasterViaOs(pages, settings);
          return { status: "SUCCESS", printer: target, usedHelper: true, convertedFormat: name };
        }
        if (sentPages > 0 && err instanceof JobError) {
          return { status: "PARTIAL", printer: target, convertedFormat: name, sentPages, totalPages, error: err.code };
        }
        throw err;
      }
    }
    const jobState = await watchSentJob(target, lastJobId, onProgress, signal);
    onProgress({ percent: 100, label: "전송 완료" });
    return { status: "SUCCESS", printer: target, convertedFormat: name, packetBytes, jobState };
  }

  if (usesInAppEngine(resolved)) return viaEngine(resolved);

  onProgress({ percent: 78, label: "Print-Job 전송 중…" });
  try {
    const sent = await sendIpp(resolved, pdf as Uint8Array, "application/pdf", settings, jobName, signal);
    if (sent.opaque) {
      onProgress({ percent: 100, label: "프린터로 직접 보냈습니다" });
      return { status: "SUCCESS", printer: resolved, packetBytes: sent.byteLength, jobState: "unknown" };
    }
    const jobState = await watchSentJob(resolved, sent.jobId, onProgress, signal);
    onProgress({ percent: 100, label: "전송 완료" });
    return { status: "SUCCESS", printer: resolved, packetBytes: sent.byteLength, jobState };
  } catch (err) {
    // PDF를 거절하면 앱 변환 엔진(PCL/PostScript/PWG)으로 바꿔 다시 보낸다.
    if (err instanceof JobError && err.code === "UNSUPPORTED_FORMAT") {
      onProgress({ percent: 64, label: "PDF 미지원 · 앱 변환 엔진 작동" });
      return viaEngine({ ...resolved, supportsPdf: false });
    }
    if (err instanceof JobError && (err.code === "TIMEOUT" || err.code === "BAD_ADDRESS")) {
      onProgress({ percent: 86, label: "브라우저가 포트를 막았습니다. 인쇄 창을 엽니다…" });
      const { url } = await printViaBrowser(pdf as Uint8Array, settings.copies);
      onProgress({ percent: 100, label: "인쇄 창을 열었습니다" });
      return { status: "SUCCESS", printer: resolved, usedLocalDialog: true, downloadUrl: url, downloadName: "print.pdf" };
    }
    if (err instanceof JobError) throw err;
    throw new JobError("TIMEOUT", "TIMEOUT");
  }
}
