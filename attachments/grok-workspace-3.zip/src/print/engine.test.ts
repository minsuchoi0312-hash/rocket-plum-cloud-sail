import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { encodePclJob, PCL_MIME } from "./pcl.ts";
import { encodePwgRaster, PWG_HEADER_SIZE, PWG_MIME } from "./pwg.ts";
import { pickEngineFormat, formatLabel, batchPageLimit } from "./engine.ts";
import { DEFAULT_SETTINGS, usesInAppEngine, type Printer } from "../domain/model.ts";
import type { RasterPage } from "../render/rasterize.ts";

function fakePage(w = 16, h = 8): RasterPage {
  const data = new Uint8ClampedArray(w * h * 4);
  for (let i = 0; i < data.length; i += 4) {
    data[i] = 20;
    data[i + 1] = 20;
    data[i + 2] = 20;
    data[i + 3] = 255;
  }
  return { width: w, height: h, data };
}

function printer(partial: Partial<Printer> & Pick<Printer, "id" | "displayName" | "protocol">): Printer {
  return {
    host: "127.0.0.1",
    port: 631,
    resourcePath: "/ipp/print",
    secure: false,
    supportsPdf: true,
    supportsDuplex: true,
    supportsColor: true,
    lastSuccessAt: null,
    source: "DEMO",
    ...partial,
  };
}

describe("in-app conversion engine", () => {
  it("sends PDF printers through without raster", () => {
    const ipp = printer({
      id: "ipp",
      displayName: "IPP",
      protocol: "IPP",
      pdl: ["application/pdf"],
    });
    assert.equal(pickEngineFormat(ipp), "pdf");
    assert.equal(usesInAppEngine(ipp), false);
  });

  it("routes legacy office printers to PCL inside the app", () => {
    const legacy = printer({
      id: "legacy",
      displayName: "구형",
      protocol: "RAW9100",
      port: 9100,
      supportsPdf: false,
      supportsColor: false,
      experimental: false,
      pdl: ["application/vnd.hp-PCL", "image/pwg-raster"],
    });
    assert.equal(legacy.experimental, false);
    assert.equal(usesInAppEngine(legacy), true);
    assert.equal(pickEngineFormat(legacy), "pcl");
    assert.equal(formatLabel("pcl"), "PCL");
  });

  it("encodes a PCL job with reset, duplex and raster commands", () => {
    const bytes = encodePclJob([fakePage()], { ...DEFAULT_SETTINGS, duplex: "LONG_EDGE" }, { mono: true, dpi: 110 });
    const text = new TextDecoder().decode(bytes);
    assert.ok(bytes.length > 32);
    assert.equal(bytes[0], 0x1b);
    assert.equal(bytes[1], 0x45);
    assert.ok(text.includes("*t110R"));
    assert.ok(text.includes("*r1A"));
    assert.ok(text.includes("&l1S"));
    assert.equal(PCL_MIME, "application/vnd.hp-PCL");
  });

  it("encodes PWG raster: RaS2 sync word, then a 1796-byte page header", () => {
    const bytes = encodePwgRaster([fakePage()], DEFAULT_SETTINGS, { mono: true, dpi: 110 });
    assert.ok(bytes.byteLength > 4 + PWG_HEADER_SIZE);
    assert.equal(new TextDecoder().decode(bytes.slice(0, 4)), "RaS2");
    assert.equal(new TextDecoder().decode(bytes.slice(4, 13)), "PwgRaster");
    assert.equal(PWG_MIME, "image/pwg-raster");
  });
});

describe("engine language and batching", () => {
  const base = printer({ id: "x", displayName: "x", protocol: "IPP", supportsPdf: false });

  it("honours an explicit language and PostScript-only printers", () => {
    assert.equal(pickEngineFormat({ ...base, language: "ps" }), "ps");
    assert.equal(usesInAppEngine({ ...base, supportsPdf: true, language: "pcl" }), true);
    assert.equal(pickEngineFormat({ ...base, pdl: ["application/postscript"] }), "ps");
    assert.equal(pickEngineFormat({ ...base, protocol: "RAW9100", language: "ps" }), "ps");
    assert.equal(formatLabel("ps"), "PostScript");
  });

  it("does not treat a PostScript-only printer as PDF capable", () => {
    const ps = { ...base, supportsPdf: null, pdl: ["application/postscript"] } as Printer;
    assert.equal(usesInAppEngine(ps), true);
  });

  it("splits big colour jobs into even batches but keeps multi-copy jobs whole", () => {
    assert.equal(batchPageLimit({ ...DEFAULT_SETTINGS, copies: 1 }, false, 100), 8);
    assert.equal(batchPageLimit({ ...DEFAULT_SETTINGS, copies: 1 }, false, 150), 4);
    assert.equal(batchPageLimit({ ...DEFAULT_SETTINGS, copies: 1 }, true, 150), 16);
    assert.equal(batchPageLimit({ ...DEFAULT_SETTINGS, copies: 3 }, false, 100), Number.POSITIVE_INFINITY);
  });

  it("sets landscape and copies in PCL", () => {
    const text = new TextDecoder().decode(
      encodePclJob([fakePage()], { ...DEFAULT_SETTINGS, orientation: "LANDSCAPE", copies: 3 }, { mono: true, dpi: 100 }),
    );
    assert.ok(text.includes("&l1O"));
    assert.ok(text.includes("&l3X"));
  });
});
