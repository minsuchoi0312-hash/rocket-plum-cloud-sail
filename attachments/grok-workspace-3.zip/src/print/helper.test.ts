import assert from "node:assert/strict";
import { afterEach, describe, it } from "node:test";
import { HELPER_BASE, helperProbe, helperSend } from "./helper.ts";

const realFetch = globalThis.fetch;
type Call = { url: string; init?: RequestInit };
const calls: Call[] = [];

function mockFetch(handler: (url: string, init?: RequestInit) => Response | null) {
  calls.length = 0;
  globalThis.fetch = (async (input: unknown, init?: RequestInit) => {
    const url = String(input);
    calls.push({ url, init });
    const res = handler(url, init);
    if (!res) throw new Error("refused");
    return res;
  }) as typeof fetch;
}

const ok = (body: unknown = { ok: true }) => new Response(JSON.stringify(body), { status: 200 });

describe("pc helper client", () => {
  afterEach(() => {
    globalThis.fetch = realFetch;
  });

  it("returns false quietly when the helper is not running", async () => {
    mockFetch(() => null);
    assert.equal(await helperSend("192.168.0.20", 9100, Uint8Array.of(1, 2, 3)), false);
  });

  it("returns false when the code is wrong (401)", async () => {
    mockFetch(() => new Response("{}", { status: 401 }));
    assert.equal(await helperSend("192.168.0.20", 9100, Uint8Array.of(1)), false);
    assert.equal(await helperProbe("192.168.0.20", 9100), false);
  });

  it("sends raw bytes only to the local helper", async () => {
    mockFetch(() => ok());
    const bytes = Uint8Array.of(0x1b, 0x45, 9);
    assert.equal(await helperSend("192.168.0.20", 9100, bytes), true);
    const post = calls.find((c) => c.init?.method === "POST");
    assert.ok(post?.url.startsWith(`${HELPER_BASE}/print?host=192.168.0.20&port=9100`));
    assert.ok(calls.every((c) => c.url.startsWith(HELPER_BASE)));
  });
});
