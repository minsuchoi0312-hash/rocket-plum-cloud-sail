import type { JobErrorCode } from "../../domain/model.ts";

/** IPP job-state: 3 pending, 4 held, 5 processing, 6 stopped, 7 canceled, 8 aborted, 9 completed. */
export interface JobSnapshot {
  state?: number;
  jobReasons: string[];
  printerReasons: string[];
}

export type JobWatch =
  | { kind: "done" }
  | { kind: "working" }
  | { kind: "failed"; code: JobErrorCode; reasons: string[] }
  | { kind: "unknown" };

function strip(reason: string) {
  return reason.replace(/-(error|warning|report)$/, "");
}

/** 프린터가 알려준 이유 키워드를 사람이 고칠 수 있는 문제로 바꾼다. 경고(-warning)는 옵션으로만 포함. */
export function classifyReasons(reasons: string[], includeWarnings: boolean): JobErrorCode | null {
  for (const raw of reasons) {
    if (!includeWarnings && raw.endsWith("-warning")) continue;
    switch (strip(raw)) {
      case "media-jam":
        return "PAPER_JAM";
      case "media-empty":
      case "media-needed":
      case "input-tray-missing":
        return "PAPER_OUT";
      case "toner-empty":
      case "marker-supply-empty":
      case "ink-empty":
        return "TONER_EMPTY";
      case "cover-open":
      case "door-open":
      case "interlock-open":
        return "COVER_OPEN";
      default:
        break;
    }
  }
  return null;
}

export function interpretJob(s: JobSnapshot): JobWatch {
  const all = [...s.jobReasons, ...s.printerReasons].filter((r) => r !== "none");
  switch (s.state) {
    case 9:
      return { kind: "done" };
    case 7:
    case 8:
    case 6:
      return { kind: "failed", code: classifyReasons(all, true) ?? "JOB_FAILED", reasons: all };
    case 3:
    case 4:
    case 5: {
      const code = classifyReasons(all, false);
      return code ? { kind: "failed", code, reasons: all } : { kind: "working" };
    }
    default:
      return { kind: "unknown" };
  }
}

function sleep(ms: number, signal?: AbortSignal) {
  return new Promise<void>((resolve) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener(
      "abort",
      () => {
        clearTimeout(t);
        resolve();
      },
      { once: true },
    );
  });
}

/**
 * 작업이 끝나거나 멈출 때까지 상태를 묻는다. 확실한 실패만 failed로 알리고,
 * 상태를 못 읽거나 시간이 다 되면 working/unknown으로 돌려 성공 처리를 막지 않는다.
 */
export async function watchJob(
  poll: () => Promise<JobSnapshot>,
  opts: { timeoutMs?: number; intervalMs?: number; signal?: AbortSignal; onTick?: (w: JobWatch) => void } = {},
): Promise<JobWatch> {
  const deadline = Date.now() + (opts.timeoutMs ?? 20_000);
  const interval = opts.intervalMs ?? 1500;
  let last: JobWatch = { kind: "working" };
  while (Date.now() < deadline) {
    if (opts.signal?.aborted) return { kind: "unknown" };
    try {
      last = interpretJob(await poll());
    } catch {
      return { kind: "unknown" };
    }
    opts.onTick?.(last);
    if (last.kind !== "working") return last;
    await sleep(interval, opts.signal);
  }
  return last;
}
