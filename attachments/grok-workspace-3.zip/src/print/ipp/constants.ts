/** IPP/1.1 tags and operations (RFC 8010 / 8011). */

export const IPP_VERSION_MAJOR = 1;
export const IPP_VERSION_MINOR = 1;

export const Tag = {
  OperationAttributes: 0x01,
  JobAttributes: 0x02,
  EndOfAttributes: 0x03,
  PrinterAttributes: 0x04,
  UnsupportedAttributes: 0x05,
  Integer: 0x21,
  Boolean: 0x22,
  Enum: 0x23,
  TextWithoutLanguage: 0x41,
  NameWithoutLanguage: 0x42,
  Keyword: 0x44,
  Uri: 0x45,
  Charset: 0x47,
  NaturalLanguage: 0x48,
  MimeMediaType: 0x49,
} as const;

export const Operation = {
  PrintJob: 0x0002,
  GetJobAttributes: 0x0009,
  GetPrinterAttributes: 0x000b,
} as const;

export const StatusCode = {
  SuccessfulOk: 0x0000,
  SuccessfulOkIgnoredOrSubstituted: 0x0001,
} as const;

export type AttributeValue =
  | { type: "integer"; value: number }
  | { type: "enum"; value: number }
  | { type: "boolean"; value: boolean }
  | { type: "charset"; value: string }
  | { type: "naturalLanguage"; value: string }
  | { type: "uri"; value: string }
  | { type: "keyword"; value: string }
  | { type: "name"; value: string }
  | { type: "text"; value: string }
  | { type: "mime"; value: string }
  | { type: "unknown"; tag: number; value: Uint8Array };

export interface IppAttribute {
  name: string;
  values: AttributeValue[];
}

export interface IppGroup {
  tag: number;
  attributes: IppAttribute[];
}

export interface IppMessage {
  versionMajor: number;
  versionMinor: number;
  code: number;
  requestId: number;
  groups: IppGroup[];
  document: Uint8Array | null;
}
