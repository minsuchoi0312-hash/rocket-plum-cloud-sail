import type { Printer } from "../../domain/model";
import { mapFailure, type IppStatusMapInput } from "../../domain/errors";
import {
  boolValue,
  buildGetJobAttributes,
  buildGetPrinterAttributes,
  buildPrintJob,
  decodeIpp,
  findAttr,
  intValue,
  printerUri,
  stringValues,
} from "./codec";
import type { JobSnapshot } from "./job-status";
import { StatusCode } from "./constants";
import { ensureLocalNetwork, withLocalTarget } from "../local-fetch";

export class JobError extends Error {
  /** no-cors 직접 전송까지 해 봤으면 true. 같은 요청을 한 번 더 하지 않는다. */
  direct = false;
  readonly code: ReturnType<typeof mapFailure>;
  constructor(code: ReturnType<typeof mapFailure>, message: string) {
    super(message);
    this.name = "JobError";
    this.code = code;
  }
}

function fail(input: IppStatusMapInput): never {
  const code = mapFailure(input);
  throw new JobError(code, code);
}

const IPP_PATHS = ["/ipp/print", "/ipp/printer", "/ipp/port1"];

/** PrinterShare가 순서대로 두드려 보는 IPP 경로. */
export function ippTargets(printer: Printer): Printer[] {
  const paths: string[] = [];
  const add = (raw: string) => {
    const path = raw.startsWith("/") ? raw : `/${raw}`;
    if (path === "/" || paths.includes(path)) return;
    paths.push(path);
  };
  if (printer.resourcePath) add(printer.resourcePath);
  for (const path of IPP_PATHS) add(path);
  return paths.map((resourcePath) => ({ ...printer, resourcePath }));
}

export function httpUrlFor(printer: Printer): string {
  const scheme = printer.secure || printer.protocol === "IPPS" ? "https" : "http";
  const path = printer.resourcePath.startsWith("/") ? printer.resourcePath : `/${printer.resourcePath}`;
  return `${scheme}://${printer.host}:${printer.port}${path}`;
}

const ATTRIBUTES_TIMEOUT_MS = 4000;
const PRINT_TIMEOUT_MS = 5000;

async function postIpp(printer: Printer, body: Uint8Array, timeoutMs: number, signal?: AbortSignal): Promise<Uint8Array> {
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    fail({ kind: "network", network: "offline" });
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const onOuter = () => controller.abort();
  signal?.addEventListener("abort", onOuter);
  try {
    const res = await fetch(
      httpUrlFor(printer),
      withLocalTarget(printer.host, {
        method: "POST",
        headers: { "Content-Type": "application/ipp" },
        body: body.slice(),
        signal: controller.signal,
      }),
    );
    const buf = new Uint8Array(await res.arrayBuffer());
    if (res.status === 404) throw new JobError("NOT_FOUND", "NOT_FOUND");
    if (!res.ok && buf.length < 8) {
      if (res.status === 401 || res.status === 403) fail({ kind: "ipp-status", status: 0x0402 });
      fail({ kind: "network", network: "refused" });
    }
    return buf;
  } catch (err) {
    if (err instanceof JobError) throw err;
    const name = err instanceof Error ? err.name : "";
    const message = err instanceof Error ? err.message : String(err);
    if (name === "AbortError") {
      if (signal?.aborted) throw err;
      fail({ kind: "network", network: "timeout" });
    }
    if (/Failed to fetch|NetworkError|CORS|Load failed/i.test(message)) {
      fail({ kind: "network", network: "cors" });
    }
    fail({ kind: "network", network: "timeout" });
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onOuter);
  }
  return new Uint8Array();
}

/**
 * application/ipp 는 확인 요청을 만들고, 프린터는 그 확인에 답하지 않아 본문이 버려진다.
 * PrinterShare는 그 검사를 거치지 않고 소켓에 같은 바이트를 쓴다.
 */
async function postIppOpaque(printer: Printer, body: Uint8Array, timeoutMs: number, signal?: AbortSignal): Promise<boolean> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const onOuter = () => controller.abort();
  signal?.addEventListener("abort", onOuter);
  try {
    // application/ipp 는 프리플라이트를 만들고, 프린터는 그 확인에 답하지 않아 본문이 버려진다.
    // 허용된 text/plain 은 확인 없이 같은 IPP 바이트를 보낸다. 응답은 읽을 수 없다.
    await fetch(
      httpUrlFor(printer),
      withLocalTarget(printer.host, {
        method: "POST",
        mode: "no-cors",
        cache: "no-store",
        headers: { "Content-Type": "text/plain" },
        body: new Blob([body.slice()], { type: "text/plain" }),
        signal: controller.signal,
      }),
    );
    return true;
  } catch (err) {
    if (signal?.aborted) throw err instanceof Error ? err : new DOMException("aborted", "AbortError");
    return false;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onOuter);
  }
}

function opaqueBudget(bytes: number): number {
  return Math.min(45_000, 6_000 + Math.floor(bytes / 12_000));
}

export interface PrinterAttributes {
  name?: string;
  makeAndModel?: string;
  formats: string[];
  media: string[];
  sides: string[];
  color?: boolean;
  state?: number;
  reasons: string[];
  resourcePath?: string;
}

export function applyAttributes(printer: Printer, attrs: PrinterAttributes): Printer {
  const formats = attrs.formats.map((f) => f.toLowerCase());
  const supportsPdf = formats.some((f) => f.includes("pdf"));
  return {
    ...printer,
    displayName: attrs.name || printer.displayName,
    makeAndModel: attrs.makeAndModel || printer.makeAndModel,
    pdl: attrs.formats.length ? attrs.formats : printer.pdl,
    mediaSupported: attrs.media,
    sidesSupported: attrs.sides,
    supportsColor: attrs.color ?? printer.supportsColor,
    supportsDuplex: attrs.sides.some((s) => s.includes("two-sided")) || printer.supportsDuplex,
    supportsPdf: formats.length ? supportsPdf : printer.supportsPdf,
    resourcePath: attrs.resourcePath || printer.resourcePath,
  };
}

function readAttributes(raw: Uint8Array): PrinterAttributes {
  const msg = decodeIpp(raw);
  if (msg.code >= 0x0400) fail({ kind: "ipp-status", status: msg.code });
  return {
    name: stringValues(findAttr(msg, "printer-name"))[0],
    makeAndModel: stringValues(findAttr(msg, "printer-make-and-model"))[0],
    formats: stringValues(findAttr(msg, "document-format-supported")),
    media: stringValues(findAttr(msg, "media-supported")),
    sides: stringValues(findAttr(msg, "sides-supported")),
    color: boolValue(findAttr(msg, "color-supported")),
    state: (() => {
      const v = findAttr(msg, "printer-state")?.values[0];
      return v && v.type === "enum" ? v.value : undefined;
    })(),
    reasons: stringValues(findAttr(msg, "printer-state-reasons")),
  };
}

export async function getPrinterAttributes(printer: Printer, signal?: AbortSignal): Promise<PrinterAttributes> {
  await ensureLocalNetwork(printer.host, signal);
  let last: unknown;
  for (const target of ippTargets(printer)) {
    const uri = printerUri(target.host, target.port, target.resourcePath, target.secure);
    try {
      const raw = await postIpp(target, buildGetPrinterAttributes(uri, 1), ATTRIBUTES_TIMEOUT_MS, signal);
      return { ...readAttributes(raw), resourcePath: target.resourcePath };
    } catch (err) {
      last = err;
      if (err instanceof JobError && err.code === "NOT_FOUND") continue;
      break;
    }
  }
  throw last instanceof Error ? last : new JobError("TIMEOUT", "TIMEOUT");
}

export async function printJob(
  printer: Printer,
  document: Uint8Array,
  options: {
    copies: number;
    jobName: string;
    userName: string;
    documentFormat?: string;
    colorMode: "color" | "monochrome" | "auto";
    sides?: "one-sided" | "two-sided-long-edge" | "two-sided-short-edge";
    media?: string;
    signal?: AbortSignal;
    /** 속성 조회가 이미 막혔으면 application/ipp 확인 요청을 다시 기다리지 않는다. */
    directOnly?: boolean;
  },
): Promise<{ status: number; byteLength: number; jobId?: number; opaque?: boolean }> {
  await ensureLocalNetwork(printer.host, options.signal);
  let last: unknown;
  const targets = options.directOnly ? ippTargets(printer).slice(0, 1) : ippTargets(printer);
  for (const target of targets) {
    const uri = printerUri(target.host, target.port, target.resourcePath, target.secure);
    const body = buildPrintJob({
      printerUri: uri,
      requestId: 2,
      jobName: options.jobName,
      userName: options.userName,
      copies: options.copies,
      documentFormat: options.documentFormat ?? "application/pdf",
      colorMode: options.colorMode,
      sides: options.sides,
      media: options.media,
      document,
    });
    if (!options.directOnly) {
      try {
        const raw = await postIpp(target, body, PRINT_TIMEOUT_MS, options.signal);
        const msg = decodeIpp(raw);
        if (msg.code === 0x0406) continue;
        if (msg.code >= 0x0400) fail({ kind: "ipp-status", status: msg.code });
        if (msg.code > StatusCode.SuccessfulOkIgnoredOrSubstituted) {
          fail({ kind: "ipp-status", status: msg.code });
        }
        return { status: msg.code, byteLength: body.byteLength, jobId: intValue(findAttr(msg, "job-id")) };
      } catch (err) {
        last = err;
        if (err instanceof JobError && err.code === "NOT_FOUND") continue;
        if (signalAborted(options.signal, err)) throw err;
        const blocked = err instanceof JobError && (err.code === "TIMEOUT" || err.code === "BAD_ADDRESS");
        if (!blocked) throw err;
      }
    }
    if (await postIppOpaque(target, body, opaqueBudget(body.byteLength), options.signal)) {
      return { status: 0, byteLength: body.byteLength, opaque: true };
    }
    if (last instanceof JobError) last.direct = true;
    else {
      const err = new JobError("TIMEOUT", "TIMEOUT");
      err.direct = true;
      last = err;
    }
    break;
  }
  throw last instanceof Error ? last : new JobError("TIMEOUT", "TIMEOUT");
}

function signalAborted(signal: AbortSignal | undefined, err: unknown): boolean {
  return Boolean(signal?.aborted) || (err instanceof Error && err.name === "AbortError");
}

/** Get-Job-Attributes + 프린터 상태 이유. 프린터 상태를 못 읽어도 작업 상태만으로 계속한다. */
export async function getJobSnapshot(printer: Printer, jobId: number, signal?: AbortSignal): Promise<JobSnapshot> {
  const uri = printerUri(printer.host, printer.port, printer.resourcePath, printer.secure);
  const raw = await postIpp(printer, buildGetJobAttributes(uri, jobId, 3), ATTRIBUTES_TIMEOUT_MS, signal);
  const msg = decodeIpp(raw);
  if (msg.code >= 0x0400) fail({ kind: "ipp-status", status: msg.code });
  const printerReasons = await getPrinterAttributes(printer, signal)
    .then((a) => a.reasons)
    .catch(() => [] as string[]);
  return {
    state: intValue(findAttr(msg, "job-state")),
    jobReasons: stringValues(findAttr(msg, "job-state-reasons")),
    printerReasons,
  };
}
