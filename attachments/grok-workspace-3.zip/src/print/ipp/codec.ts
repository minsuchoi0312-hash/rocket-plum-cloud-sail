import {
  IPP_VERSION_MAJOR,
  IPP_VERSION_MINOR,
  Operation,
  Tag,
  type AttributeValue,
  type IppAttribute,
  type IppGroup,
  type IppMessage,
} from "./constants.ts";

class Buf {
  private parts: Uint8Array[] = [];

  u8(n: number) {
    this.parts.push(Uint8Array.of(n & 0xff));
  }
  u16(n: number) {
    this.parts.push(Uint8Array.of((n >>> 8) & 0xff, n & 0xff));
  }
  u32(n: number) {
    this.parts.push(
      Uint8Array.of((n >>> 24) & 0xff, (n >>> 16) & 0xff, (n >>> 8) & 0xff, n & 0xff),
    );
  }
  raw(bytes: Uint8Array) {
    this.parts.push(bytes);
  }
  concat(): Uint8Array {
    const total = this.parts.reduce((n, p) => n + p.length, 0);
    const out = new Uint8Array(total);
    let o = 0;
    for (const p of this.parts) {
      out.set(p, o);
      o += p.length;
    }
    return out;
  }
}

function encodeString(s: string): Uint8Array {
  return new TextEncoder().encode(s);
}

function writeValue(buf: Buf, value: AttributeValue) {
  switch (value.type) {
    case "integer":
    case "enum": {
      buf.u8(value.type === "enum" ? Tag.Enum : Tag.Integer);
      return (nameWriter: () => void) => {
        nameWriter();
        buf.u16(4);
        buf.u32(value.value);
      };
    }
    case "boolean": {
      buf.u8(Tag.Boolean);
      return (nameWriter: () => void) => {
        nameWriter();
        buf.u16(1);
        buf.u8(value.value ? 1 : 0);
      };
    }
    case "charset":
    case "naturalLanguage":
    case "uri":
    case "keyword":
    case "name":
    case "text":
    case "mime": {
      const tag =
        value.type === "charset"
          ? Tag.Charset
          : value.type === "naturalLanguage"
            ? Tag.NaturalLanguage
            : value.type === "uri"
              ? Tag.Uri
              : value.type === "keyword"
                ? Tag.Keyword
                : value.type === "name"
                  ? Tag.NameWithoutLanguage
                  : value.type === "mime"
                    ? Tag.MimeMediaType
                    : Tag.TextWithoutLanguage;
      const bytes = encodeString(value.value);
      buf.u8(tag);
      return (nameWriter: () => void) => {
        nameWriter();
        buf.u16(bytes.length);
        buf.raw(bytes);
      };
    }
    default: {
      buf.u8(value.tag);
      return (nameWriter: () => void) => {
        nameWriter();
        buf.u16(value.value.length);
        buf.raw(value.value);
      };
    }
  }
}

function writeAttribute(buf: Buf, attr: IppAttribute) {
  attr.values.forEach((value, i) => {
    const body = writeValue(buf, value);
    body(() => {
      if (i === 0) {
        const name = encodeString(attr.name);
        buf.u16(name.length);
        buf.raw(name);
      } else {
        buf.u16(0);
      }
    });
  });
}

export function encodeIpp(message: Omit<IppMessage, "document"> & { document?: Uint8Array | null }): Uint8Array {
  const buf = new Buf();
  buf.u8(message.versionMajor);
  buf.u8(message.versionMinor);
  buf.u16(message.code);
  buf.u32(message.requestId);
  for (const group of message.groups) {
    buf.u8(group.tag);
    for (const attr of group.attributes) writeAttribute(buf, attr);
  }
  buf.u8(Tag.EndOfAttributes);
  const header = buf.concat();
  const doc = message.document;
  if (!doc || doc.length === 0) return header;
  const out = new Uint8Array(header.length + doc.length);
  out.set(header, 0);
  out.set(doc, header.length);
  return out;
}

class Reader {
  buf: Uint8Array;
  offset: number;
  constructor(buf: Uint8Array, offset = 0) {
    this.buf = buf;
    this.offset = offset;
  }
  remaining() {
    return this.buf.length - this.offset;
  }
  u8() {
    return this.buf[this.offset++];
  }
  u16() {
    const v = (this.buf[this.offset] << 8) | this.buf[this.offset + 1];
    this.offset += 2;
    return v;
  }
  u32() {
    const v =
      ((this.buf[this.offset] << 24) |
        (this.buf[this.offset + 1] << 16) |
        (this.buf[this.offset + 2] << 8) |
        this.buf[this.offset + 3]) >>>
      0;
    this.offset += 4;
    return v;
  }
  bytes(n: number) {
    const slice = this.buf.subarray(this.offset, this.offset + n);
    this.offset += n;
    return slice;
  }
  ascii(n: number) {
    return new TextDecoder("utf-8").decode(this.bytes(n));
  }
}

function parseValue(tag: number, data: Uint8Array): AttributeValue {
  if (tag === Tag.Integer || tag === Tag.Enum) {
    const v =
      data.length >= 4
        ? ((data[0] << 24) | (data[1] << 16) | (data[2] << 8) | data[3]) >> 0
        : 0;
    return { type: tag === Tag.Enum ? "enum" : "integer", value: v };
  }
  if (tag === Tag.Boolean) {
    return { type: "boolean", value: data[0] === 1 };
  }
  const text = new TextDecoder("utf-8").decode(data);
  if (tag === Tag.Charset) return { type: "charset", value: text };
  if (tag === Tag.NaturalLanguage) return { type: "naturalLanguage", value: text };
  if (tag === Tag.Uri) return { type: "uri", value: text };
  if (tag === Tag.Keyword) return { type: "keyword", value: text };
  if (tag === Tag.NameWithoutLanguage) return { type: "name", value: text };
  if (tag === Tag.TextWithoutLanguage) return { type: "text", value: text };
  if (tag === Tag.MimeMediaType) return { type: "mime", value: text };
  return { type: "unknown", tag, value: data };
}

export function decodeIpp(bytes: Uint8Array): IppMessage {
  if (bytes.length < 8) throw new Error("IPP message too short");
  const r = new Reader(bytes);
  const versionMajor = r.u8();
  const versionMinor = r.u8();
  const code = r.u16();
  const requestId = r.u32();
  const groups: IppGroup[] = [];
  let current: IppGroup | null = null;

  while (r.remaining() > 0) {
    const tag = r.u8();
    if (tag === Tag.EndOfAttributes) break;
    if (tag < 0x10) {
      current = { tag, attributes: [] };
      groups.push(current);
      continue;
    }
    if (!current) {
      current = { tag: Tag.OperationAttributes, attributes: [] };
      groups.push(current);
    }
    const nameLen = r.u16();
    const name = nameLen > 0 ? r.ascii(nameLen) : "";
    const valueLen = r.u16();
    const valueBytes = r.bytes(valueLen);
    const value = parseValue(tag, valueBytes);
    if (nameLen === 0 && current.attributes.length > 0) {
      current.attributes[current.attributes.length - 1].values.push(value);
    } else {
      current.attributes.push({ name, values: [value] });
    }
  }

  const document = r.remaining() > 0 ? bytes.subarray(r.offset) : null;
  return { versionMajor, versionMinor, code, requestId, groups, document };
}

function attr(name: string, ...values: AttributeValue[]): IppAttribute {
  return { name, values };
}

export function buildGetPrinterAttributes(printerUri: string, requestId: number): Uint8Array {
  const requested = [
    "printer-name",
    "printer-make-and-model",
    "document-format-supported",
    "media-supported",
    "sides-supported",
    "color-supported",
    "printer-state",
    "printer-state-reasons",
  ];
  return encodeIpp({
    versionMajor: IPP_VERSION_MAJOR,
    versionMinor: IPP_VERSION_MINOR,
    code: Operation.GetPrinterAttributes,
    requestId,
    groups: [
      {
        tag: Tag.OperationAttributes,
        attributes: [
          attr("attributes-charset", { type: "charset", value: "utf-8" }),
          attr("attributes-natural-language", { type: "naturalLanguage", value: "ko" }),
          attr("printer-uri", { type: "uri", value: printerUri }),
          attr("requested-attributes", ...requested.map((k) => ({ type: "keyword" as const, value: k }))),
        ],
      },
    ],
  });
}

export function buildGetJobAttributes(printerUri: string, jobId: number, requestId: number): Uint8Array {
  const requested = ["job-state", "job-state-reasons", "job-impressions-completed"];
  return encodeIpp({
    versionMajor: IPP_VERSION_MAJOR,
    versionMinor: IPP_VERSION_MINOR,
    code: Operation.GetJobAttributes,
    requestId,
    groups: [
      {
        tag: Tag.OperationAttributes,
        attributes: [
          attr("attributes-charset", { type: "charset", value: "utf-8" }),
          attr("attributes-natural-language", { type: "naturalLanguage", value: "ko" }),
          attr("printer-uri", { type: "uri", value: printerUri }),
          attr("job-id", { type: "integer", value: jobId }),
          attr("requested-attributes", ...requested.map((k) => ({ type: "keyword" as const, value: k }))),
        ],
      },
    ],
  });
}

export interface PrintJobRequest {
  printerUri: string;
  requestId: number;
  jobName: string;
  userName: string;
  copies: number;
  documentFormat: string;
  colorMode?: "color" | "monochrome" | "auto";
  sides?: "one-sided" | "two-sided-long-edge" | "two-sided-short-edge";
  media?: string;
  document: Uint8Array;
}

export function buildPrintJob(req: PrintJobRequest): Uint8Array {
  const opAttrs: IppAttribute[] = [
    attr("attributes-charset", { type: "charset", value: "utf-8" }),
    attr("attributes-natural-language", { type: "naturalLanguage", value: "ko" }),
    attr("printer-uri", { type: "uri", value: req.printerUri }),
    attr("requesting-user-name", { type: "name", value: req.userName }),
    attr("job-name", { type: "name", value: req.jobName }),
    attr("document-format", { type: "mime", value: req.documentFormat }),
  ];
  const jobAttrs: IppAttribute[] = [
    attr("copies", { type: "integer", value: req.copies }),
  ];
  if (req.sides) jobAttrs.push(attr("sides", { type: "keyword", value: req.sides }));
  if (req.colorMode && req.colorMode !== "auto") {
    jobAttrs.push(attr("print-color-mode", { type: "keyword", value: req.colorMode }));
  }
  if (req.media) jobAttrs.push(attr("media", { type: "keyword", value: req.media }));

  return encodeIpp({
    versionMajor: IPP_VERSION_MAJOR,
    versionMinor: IPP_VERSION_MINOR,
    code: Operation.PrintJob,
    requestId: req.requestId,
    groups: [
      { tag: Tag.OperationAttributes, attributes: opAttrs },
      { tag: Tag.JobAttributes, attributes: jobAttrs },
    ],
    document: req.document,
  });
}

export function printerUri(host: string, port: number, path: string, secure: boolean): string {
  const scheme = secure ? "ipps" : "ipp";
  const normalized = path.startsWith("/") ? path : `/${path}`;
  return `${scheme}://${host}:${port}${normalized}`;
}

export function findAttr(message: IppMessage, name: string): IppAttribute | undefined {
  for (const g of message.groups) {
    const hit = g.attributes.find((a) => a.name === name);
    if (hit) return hit;
  }
  return undefined;
}

export function stringValues(attr: IppAttribute | undefined): string[] {
  if (!attr) return [];
  return attr.values
    .map((v) => ("value" in v && typeof v.value === "string" ? v.value : null))
    .filter((v): v is string => Boolean(v));
}

export function boolValue(attr: IppAttribute | undefined): boolean | undefined {
  const v = attr?.values[0];
  if (v && v.type === "boolean") return v.value;
  return undefined;
}

export function intValue(attr: IppAttribute | undefined): number | undefined {
  const v = attr?.values[0];
  if (v && (v.type === "integer" || v.type === "enum")) return v.value;
  return undefined;
}
