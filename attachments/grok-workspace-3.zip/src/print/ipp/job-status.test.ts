import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { classifyReasons, interpretJob, watchJob, type JobSnapshot } from "./job-status.ts";
import { buildGetJobAttributes, decodeIpp, findAttr, intValue } from "./codec.ts";

const snap = (state: number | undefined, jobReasons: string[] = [], printerReasons: string[] = []): JobSnapshot => ({ state, jobReasons, printerReasons });

describe("job status", () => {
  it("maps printer reason keywords to fixable problems", () => {
    assert.equal(classifyReasons(["media-empty-error"], false), "PAPER_OUT");
    assert.equal(classifyReasons(["media-jam"], false), "PAPER_JAM");
    assert.equal(classifyReasons(["toner-empty-error"], false), "TONER_EMPTY");
    assert.equal(classifyReasons(["cover-open-error"], false), "COVER_OPEN");
    assert.equal(classifyReasons(["media-empty-warning"], false), null);
    assert.equal(classifyReasons(["media-empty-warning"], true), "PAPER_OUT");
    assert.equal(classifyReasons(["toner-low-warning", "none"], true), null);
  });

  it("interprets IPP job states", () => {
    assert.equal(interpretJob(snap(9)).kind, "done");
    assert.equal(interpretJob(snap(5)).kind, "working");
    assert.equal(interpretJob(snap(undefined)).kind, "unknown");
    assert.deepEqual(interpretJob(snap(6, [], ["media-empty-error"])), { kind: "failed", code: "PAPER_OUT", reasons: ["media-empty-error"] });
    assert.equal((interpretJob(snap(8)) as { code: string }).code, "JOB_FAILED");
    // 처리 중이라도 -error 이유가 있으면 알리고, 경고만이면 계속 지켜본다.
    assert.equal(interpretJob(snap(5, [], ["media-jam-error"])).kind, "failed");
    assert.equal(interpretJob(snap(5, [], ["media-empty-warning"])).kind, "working");
  });

  it("keeps polling until done, and reports unknown if the status cannot be read", async () => {
    const states = [snap(3), snap(5), snap(9)];
    let i = 0;
    const done = await watchJob(async () => states[i++], { intervalMs: 1, timeoutMs: 1000 });
    assert.equal(done.kind, "done");
    assert.equal(i, 3);
    const unknown = await watchJob(async () => {
      throw new Error("net");
    }, { intervalMs: 1 });
    assert.equal(unknown.kind, "unknown");
    const slow = await watchJob(async () => snap(5), { intervalMs: 1, timeoutMs: 20 });
    assert.equal(slow.kind, "working");
  });

  it("builds a Get-Job-Attributes request with the job id", () => {
    const msg = decodeIpp(buildGetJobAttributes("ipp://192.168.0.9:631/ipp/print", 42, 3));
    assert.equal(msg.code, 0x0009);
    assert.equal(intValue(findAttr(msg, "job-id")), 42);
  });
});
