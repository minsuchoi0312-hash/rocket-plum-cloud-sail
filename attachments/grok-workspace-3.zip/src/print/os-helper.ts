import type { RasterPage } from "../render/rasterize";
import { pageSizePoints } from "../render/paper";
import type { PrintSettings } from "../domain/model";

function pageToJpegUrl(page: RasterPage, quality = 0.84): Promise<string> {
  const canvas = document.createElement("canvas");
  canvas.width = page.width;
  canvas.height = page.height;
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("canvas");
  const image = ctx.createImageData(page.width, page.height);
  image.data.set(page.data);
  ctx.putImageData(image, 0, 0);
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) {
          reject(new Error("jpeg"));
          return;
        }
        resolve(URL.createObjectURL(blob));
      },
      "image/jpeg",
      quality,
    );
  });
}

function mountPrintFrame(url: string) {
  const iframe = document.createElement("iframe");
  iframe.setAttribute("aria-hidden", "true");
  iframe.style.position = "fixed";
  iframe.style.inset = "0";
  iframe.style.width = "100%";
  iframe.style.height = "100%";
  iframe.style.border = "0";
  iframe.style.opacity = "0";
  iframe.style.pointerEvents = "none";
  iframe.src = url;
  document.body.appendChild(iframe);
  return iframe;
}

function printFrame(iframe: HTMLIFrameElement, url: string) {
  try {
    iframe.contentWindow?.focus();
    iframe.contentWindow?.addEventListener("afterprint", () => iframe.remove());
    iframe.contentWindow?.print();
  } catch {
    window.open(url, "_blank");
  }
}

/** 결과 화면에서 사용자가 다시 누를 때. 클릭과 같은 턴에 창을 연다. */
export function openPrintUrl(url: string): boolean {
  const win = window.open(url, "_blank");
  if (!win) return false;
  win.addEventListener("load", () => {
    try {
      win.focus();
      win.print();
    } catch {
      /* PDF 뷰어는 자체 인쇄 버튼이 있다. */
    }
  });
  return true;
}

/**
 * In-app PC helper: hand raster pages to the OS print dialog, where old
 * USB/driver printers already live. No extra install.
 * 브라우저 인쇄 창은 매수를 모르므로 페이지 묶음을 매수만큼 반복한다.
 */
export async function printRasterViaOs(
  pages: RasterPage[],
  settings: PrintSettings,
): Promise<{ url: string; revoke: () => void }> {
  const urls = await Promise.all(pages.map((p) => pageToJpegUrl(p)));
  const pts = pageSizePoints(settings.paper, settings.orientation);
  const copies = Math.max(1, Math.min(99, settings.copies));
  const tiled = Array.from({ length: copies }, () => urls).flat();
  const imgs = tiled.map((u) => `<img src="${u}" alt="" />`).join("");
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>인쇄</title>
<style>
  @page { size: ${pts.width}pt ${pts.height}pt; margin: 0; }
  html, body { margin: 0; background: #fff; }
  img { display: block; width: 100%; page-break-after: always; break-after: page; }
  img:last-child { page-break-after: auto; break-after: auto; }
</style></head><body>${imgs}</body></html>`;
  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const iframe = mountPrintFrame(url);
  iframe.addEventListener("load", () => {
    const frames = Array.from(iframe.contentDocument?.images ?? []);
    void Promise.all(frames.map((img) => img.decode().catch(() => undefined))).then(() => printFrame(iframe, url));
  });
  return {
    url,
    revoke: () => {
      for (const u of urls) URL.revokeObjectURL(u);
    },
  };
}

export function blobDownloadUrl(bytes: Uint8Array, mime: string): string {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return URL.createObjectURL(new Blob([copy.buffer], { type: mime }));
}
