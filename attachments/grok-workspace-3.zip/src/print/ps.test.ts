import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ascii85, encodePostScript } from "./ps.ts";
import { DEFAULT_SETTINGS } from "../domain/model.ts";

const page = (w: number, h: number) => ({ width: w, height: h, data: new Uint8ClampedArray(w * h * 4).fill(200) });

describe("PostScript encoder", () => {
  it("matches known ASCII85 vectors", () => {
    assert.equal(ascii85(new TextEncoder().encode("Man ")), "9jqo^~>\n");
    assert.equal(ascii85(new TextEncoder().encode("Ma")), "9jn~>\n");
    assert.equal(ascii85(new Uint8Array(0)), "~>\n");
  });

  it("writes DSC header, page device, image and EOF", () => {
    const text = new TextDecoder().decode(
      encodePostScript([page(8, 4), page(8, 4)], { ...DEFAULT_SETTINGS, duplex: "SHORT_EDGE", copies: 2 }, { mono: false }),
    );
    assert.ok(text.startsWith("%!PS-Adobe-3.0"));
    assert.ok(text.includes("%%Pages: 2"));
    assert.ok(text.includes("/NumCopies 2"));
    assert.ok(text.includes("/Duplex true /Tumble true"));
    assert.ok(text.includes("/DeviceRGB setcolorspace"));
    assert.equal(text.split("showpage").length - 1, 2);
    assert.ok(text.trimEnd().endsWith("%%EOF"));
  });

  it("uses gray for black-and-white jobs", () => {
    const text = new TextDecoder().decode(encodePostScript([page(8, 4)], DEFAULT_SETTINGS, { mono: true }));
    assert.ok(text.includes("/DeviceGray setcolorspace"));
  });
});
