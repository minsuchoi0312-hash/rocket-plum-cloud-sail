export type AddressSpace = "local" | "loopback";
export type LocalPermission = "granted" | "denied" | "prompt" | "unknown";
export type LocalRequestInit = RequestInit & { targetAddressSpace?: AddressSpace };

/** 사설 IP·.local 은 local, 이 기기 자신은 loopback. 브라우저는 이 표시가 있어야
 *  https 페이지에서 http://192.168.* 요청을 혼합 콘텐츠로 바로 버리지 않는다. */
export function addressSpaceFor(host: string): AddressSpace {
  const h = host.trim().toLowerCase().replace(/^\[|\]$/g, "");
  if (h === "localhost" || h === "::1" || h.startsWith("127.")) return "loopback";
  return "local";
}

export function withLocalTarget(host: string, init: RequestInit = {}): LocalRequestInit {
  return { ...init, targetAddressSpace: addressSpaceFor(host) };
}

export async function localNetworkPermission(): Promise<LocalPermission> {
  if (typeof navigator === "undefined" || !navigator.permissions?.query) return "unknown";
  for (const name of ["local-network", "loopback-network"]) {
    try {
      const status = await navigator.permissions.query({ name } as PermissionDescriptor);
      if (status.state === "granted" || status.state === "denied" || status.state === "prompt") return status.state;
    } catch {
      /* 이 브라우저는 그 이름을 모른다 */
    }
  }
  return "unknown";
}

let gate: Promise<boolean> | null = null;

export function resetLocalNetworkGate(): void {
  gate = null;
}

/**
 * 공용 웹페이지가 집 안 프린터로 붙으려면 로컬 네트워크 허용이 필요하다.
 * 허용 창이 떠 있는 동안 짧은 제한으로 끊으면, 예전처럼 프린터가 잠든 것처럼 보인다.
 * 이미 허용돼 있으면 프린터를 기다리지 않고 바로 돌아온다.
 */
export function ensureLocalNetwork(host: string, signal?: AbortSignal): Promise<boolean> {
  if (!gate) {
    gate = openLocalNetwork(host, signal).then((ok) => {
      if (!ok) gate = null;
      return ok;
    });
  }
  return gate;
}

async function openLocalNetwork(host: string, signal?: AbortSignal): Promise<boolean> {
  if (signal?.aborted) throw new DOMException("aborted", "AbortError");
  const state = await localNetworkPermission();
  if (state === "granted") return true;
  if (state === "denied") return false;

  const url = `http://${host}:631/ipp/print`;
  const controller = new AbortController();
  const onOuter = () => controller.abort();
  signal?.addEventListener("abort", onOuter);
  const waitMs = state === "prompt" ? 25_000 : 8_000;
  let timedOut = false;
  const timer = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, waitMs);

  let status: PermissionStatus | null = null;
  try {
    status = await navigator.permissions.query({ name: "local-network" } as PermissionDescriptor);
  } catch {
    status = null;
  }
  const granted = new Promise<boolean>((resolve) => {
    if (!status || status.state !== "prompt") return;
    const done = () => resolve(status.state === "granted");
    status.addEventListener("change", done, { once: true });
  });

  try {
    return await Promise.race([
      granted,
      fetch(
        url,
        withLocalTarget(host, {
          method: "GET",
          mode: "no-cors",
          cache: "no-store",
          signal: controller.signal,
        }),
      ).then(
        () => true,
        (err: unknown) => {
          if (signal?.aborted) {
            throw err instanceof Error ? err : new DOMException("aborted", "AbortError");
          }
          if (timedOut) return false;
          return false;
        },
      ),
    ]);
  } finally {
    clearTimeout(timer);
    controller.abort();
    signal?.removeEventListener("abort", onOuter);
  }
}
