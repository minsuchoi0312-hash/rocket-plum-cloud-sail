/**
 * Optional PC helper (public/raw-print-helper.mjs). A browser cannot open raw TCP,
 * so the helper does it on 127.0.0.1. Every call fails quietly when it is not running
 * or when the 6-digit code has not been entered.
 */
export const HELPER_BASE = "http://127.0.0.1:47631";
const CODE_KEY = "nuguna.helperCode";

export type HelperState = "off" | "needs-code" | "ready";

let alive: { at: number; promise: Promise<boolean> } | null = null;

export function getHelperCode(): string {
  try {
    return globalThis.localStorage?.getItem(CODE_KEY) ?? "";
  } catch {
    return "";
  }
}

export function setHelperCode(code: string) {
  try {
    globalThis.localStorage?.setItem(CODE_KEY, code.trim());
  } catch {
    /* 저장이 막힌 브라우저 */
  }
}

async function call(path: string, init: RequestInit | undefined, ms: number, signal?: AbortSignal): Promise<Response | null> {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), ms);
  const onOuter = () => ac.abort();
  signal?.addEventListener("abort", onOuter);
  const code = getHelperCode();
  try {
    return await fetch(`${HELPER_BASE}${path}`, {
      ...init,
      headers: { ...(init?.headers as Record<string, string> | undefined), ...(code ? { "X-Helper-Code": code } : {}) },
      cache: "no-store",
      signal: ac.signal,
    });
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onOuter);
  }
}

/** 도우미가 켜져 있고(응답함) 연결 코드도 맞아야 true. */
export function helperAlive(force = false): Promise<boolean> {
  if (!force && alive && Date.now() - alive.at < 5000) return alive.promise;
  const promise = call("/check", undefined, 500).then((r) => Boolean(r?.ok));
  alive = { at: Date.now(), promise };
  return promise;
}

export async function helperState(): Promise<HelperState> {
  const ping = await call("/ping", undefined, 500);
  if (!ping?.ok) return "off";
  const check = await call("/check", undefined, 500);
  return check?.ok ? "ready" : "needs-code";
}

function target(host: string, port: number) {
  return `host=${encodeURIComponent(host)}&port=${port}`;
}

export async function helperProbe(host: string, port = 9100, signal?: AbortSignal): Promise<boolean> {
  if (!(await helperAlive())) return false;
  const r = await call(`/probe?${target(host, port)}`, undefined, 900, signal);
  if (!r?.ok) return false;
  return Boolean((await r.json().catch(() => null))?.open);
}

export async function helperWake(host: string, port = 9100, signal?: AbortSignal): Promise<void> {
  if (!(await helperAlive())) return;
  await call(`/wake?${target(host, port)}`, { method: "POST" }, 2000, signal);
}

export async function helperSend(host: string, port: number, bytes: Uint8Array, signal?: AbortSignal): Promise<boolean> {
  if (!(await helperAlive(true))) return false;
  const r = await call(
    `/print?${target(host, port)}`,
    { method: "POST", headers: { "Content-Type": "application/octet-stream" }, body: bytes.slice() },
    60_000,
    signal,
  );
  return Boolean(r?.ok);
}
