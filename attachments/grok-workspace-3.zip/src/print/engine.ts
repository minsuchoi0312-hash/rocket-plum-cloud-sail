import { dpiForQuality, usesInAppEngine, type Printer, type PrintSettings } from "../domain/model.ts";
import { concatBytes, encodePclJob, PCL_MIME } from "./pcl.ts";
import { encodePwgRaster, PWG_MIME } from "./pwg.ts";
import { encodePostScript, PS_MIME } from "./ps.ts";
import { rasterPages, shouldForceMono, type RasterPage, type RasterSource } from "../render/rasterize.ts";

export type EngineFormat = "pdf" | "pwg" | "pcl" | "ps";

export interface ConvertedJob {
  bytes: Uint8Array;
  mime: string;
  label: string;
  format: EngineFormat;
  /** 이 묶음에 들어간 래스터 페이지(이 컴퓨터 드라이버로 넘길 때 쓴다). */
  pages: RasterPage[];
  /** 이 묶음이 전체에서 몇 번째 페이지까지인지. */
  pagesDone: number;
  pagesTotal: number;
  batchIndex: number;
}

export function pickEngineFormat(printer: Printer): EngineFormat {
  if (!usesInAppEngine(printer)) return "pdf";
  if (printer.language === "pcl" || printer.language === "ps" || printer.language === "pwg") return printer.language;
  if (printer.protocol === "RAW9100") return "pcl";
  if (printer.lastMethod === "IPP_PWG") return "pwg";
  if (printer.lastMethod === "IPP_PCL") return "pcl";
  if (printer.lastMethod === "IPP_PS") return "ps";
  const pdl = (printer.pdl ?? []).map((p) => p.toLowerCase());
  if (pdl.some((p) => p.includes("pwg-raster"))) return "pwg";
  if (pdl.some((p) => p.includes("pcl") && !p.includes("pclm"))) return "pcl";
  if (pdl.some((p) => p.includes("postscript"))) return "ps";
  if (pdl.some((p) => p.includes("pwg"))) return "pwg";
  return "pcl";
}

export function formatLabel(format: EngineFormat): string {
  if (format === "pwg") return "PWG Raster";
  if (format === "pcl") return "PCL";
  if (format === "ps") return "PostScript";
  return "PDF";
}

export function formatMime(format: EngineFormat): string {
  if (format === "pwg") return PWG_MIME;
  if (format === "ps") return PS_MIME;
  if (format === "pcl") return PCL_MIME;
  return "application/pdf";
}

export function formatExtension(format: EngineFormat): string {
  if (format === "pwg") return "pwg";
  if (format === "ps") return "ps";
  return "prn";
}

/**
 * 한 번에 변환하는 페이지 수. 양면이 쌍으로 맞도록 항상 짝수.
 * 매수가 2장 이상이면 순서(1·2·3 · 1·2·3)가 섞이지 않게 쪼개지 않는다.
 */
export function batchPageLimit(settings: PrintSettings, mono: boolean, dpi: number): number {
  if (settings.copies > 1) return Number.POSITIVE_INFINITY;
  if (mono) return 16;
  return dpi >= 150 ? 4 : 8;
}

function encodeBatch(format: EngineFormat, pages: RasterPage[], settings: PrintSettings, mono: boolean, dpi: number) {
  if (format === "pwg") return encodePwgRaster(pages, settings, { mono, dpi });
  if (format === "ps") return encodePostScript(pages, settings, { mono, dpi });
  return encodePclJob(pages, settings, { mono, dpi });
}

/** 페이지를 한 장씩 만들고, 묶음이 차면 변환해서 내보낸다. 큰 문서도 메모리를 한꺼번에 쓰지 않는다. */
export async function* convertBatches(
  source: RasterSource,
  printer: Printer,
  settings: PrintSettings,
  opts: {
    signal?: AbortSignal;
    onPage?: (done: number, total: number) => void;
    keepPages?: boolean;
    /** false면 매수를 데이터에 넣지 않는다(IPP는 copies 속성으로 따로 보내므로 두 번 곱해지지 않게). */
    embedCopies?: boolean;
  } = {},
): AsyncGenerator<ConvertedJob> {
  const format = pickEngineFormat(printer);
  if (format === "pdf") throw new Error("pdf");
  const dpi = dpiForQuality(settings.quality);
  const mono = shouldForceMono(settings, printer);
  const limit = batchPageLimit(settings, mono, dpi);
  const encodeSettings = opts.embedCopies === false ? { ...settings, copies: 1 } : settings;
  let batch: RasterPage[] = [];
  let index = 0;
  let done = 0;
  let total = 0;

  const make = (pages: RasterPage[]): ConvertedJob => ({
    bytes: encodeBatch(format, pages, encodeSettings, mono, dpi),
    mime: formatMime(format),
    label: formatLabel(format),
    format,
    pages: opts.keepPages ? pages : [],
    pagesDone: done,
    pagesTotal: total,
    batchIndex: index++,
  });

  for await (const { page, progress } of rasterPages(source, settings, dpi, opts.signal)) {
    done = progress.done;
    total = progress.total;
    opts.onPage?.(done, total);
    batch.push(page);
    if (batch.length >= limit) {
      yield make(batch);
      batch = [];
    }
  }
  if (batch.length > 0) yield make(batch);
}

export { concatBytes };
