import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { compressPwgPage } from "./pwg.ts";

/** 스펙대로 풀어서 원본과 같은지 확인하는 디코더. */
function decode(data: Uint8Array, width: number, height: number, bpp: number): Uint8Array {
  const out = new Uint8Array(width * height * bpp);
  let p = 0;
  let y = 0;
  while (y < height) {
    const repeat = data[p++] + 1;
    const line = new Uint8Array(width * bpp);
    let x = 0;
    while (x < width) {
      const c = data[p++];
      if (c <= 127) {
        const px = data.subarray(p, p + bpp);
        p += bpp;
        for (let k = 0; k <= c; k++) line.set(px, (x++) * bpp);
      } else {
        const n = 257 - c;
        for (let k = 0; k < n; k++) {
          line.set(data.subarray(p, p + bpp), (x++) * bpp);
          p += bpp;
        }
      }
    }
    for (let r = 0; r < repeat; r++) out.set(line, (y++) * width * bpp);
  }
  assert.equal(p, data.length);
  return out;
}

function noisy(width: number, height: number, bpp: number, seed: number) {
  const a = new Uint8Array(width * height * bpp);
  let s = seed;
  for (let i = 0; i < a.length; i++) {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    // 반복·직접 나열·같은 줄이 섞이도록 값 범위를 좁게 둔다.
    a[i] = (s >> 8) % 3 === 0 ? 255 : (s >> 12) % 4;
  }
  return a;
}

describe("PWG raster compression", () => {
  for (const bpp of [1, 3]) {
    it(`round-trips mixed content (bpp ${bpp})`, () => {
      const w = 301;
      const h = 40;
      const px = noisy(w, h, bpp, 7);
      for (let y = 10; y < 30; y++) px.copyWithin(y * w * bpp, 9 * w * bpp, 10 * w * bpp); // 같은 줄 반복
      assert.deepEqual(decode(compressPwgPage(px, w, h, bpp), w, h, bpp), px);
    });
  }

  it("collapses a blank page to almost nothing and handles >256 repeated lines", () => {
    const w = 640;
    const h = 700;
    const white = new Uint8Array(w * h).fill(255);
    const packed = compressPwgPage(white, w, h, 1);
    assert.ok(packed.length < 64);
    assert.deepEqual(decode(packed, w, h, 1), white);
  });
});
