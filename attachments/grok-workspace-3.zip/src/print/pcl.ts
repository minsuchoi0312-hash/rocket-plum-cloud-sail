import type { PaperSize, PrintSettings } from "../domain/model.ts";
import { resolvePaper } from "../render/paper.ts";
import type { RasterPage } from "../render/rasterize.ts";

const ESC = 0x1b;
const encoder = new TextEncoder();

function paperCode(paper: PaperSize): number {
  switch (resolvePaper(paper)) {
    case "LETTER":
      return 2;
    case "LEGAL":
      return 3;
    case "A5":
      return 25;
    case "B5":
      return 45;
    case "PHOTO_4X6":
      return 71;
    default:
      return 26;
  }
}

function duplexCode(duplex: PrintSettings["duplex"]): number {
  if (duplex === "LONG_EDGE") return 1;
  if (duplex === "SHORT_EDGE") return 2;
  return 0;
}

class Out {
  buf: Uint8Array;
  o = 0;
  constructor(cap: number) {
    this.buf = new Uint8Array(Math.max(256, cap));
  }
  grow(need: number) {
    if (this.o + need <= this.buf.length) return;
    let n = this.buf.length;
    while (n < this.o + need) n *= 2;
    const next = new Uint8Array(n);
    next.set(this.buf.subarray(0, this.o));
    this.buf = next;
  }
  bytes(b: Uint8Array) {
    this.grow(b.length);
    this.buf.set(b, this.o);
    this.o += b.length;
  }
  str(s: string) {
    this.bytes(encoder.encode(s));
  }
  u8(...n: number[]) {
    this.grow(n.length);
    this.buf.set(n, this.o);
    this.o += n.length;
  }
  result() {
    return this.buf.subarray(0, this.o);
  }
}

function packMonoPage(page: RasterPage): Uint8Array {
  const bpl = (page.width + 7) >> 3;
  const out = new Uint8Array(bpl * page.height);
  const src = page.data;
  const w = page.width;
  const h = page.height;
  for (let y = 0; y < h; y++) {
    const row = y * bpl;
    const srcRow = y * w * 4;
    for (let x = 0; x < w; x++) {
      const i = srcRow + (x << 2);
      if (src[i] + src[i + 1] + src[i + 2] < 400) out[row + (x >> 3)] |= 0x80 >> (x & 7);
    }
  }
  return out;
}

function packRgbPage(page: RasterPage): Uint8Array {
  const w = page.width;
  const h = page.height;
  const out = new Uint8Array(w * h * 3);
  const src = page.data;
  let d = 0;
  for (let i = 0; i < src.length; i += 4) {
    out[d++] = src[i];
    out[d++] = src[i + 1];
    out[d++] = src[i + 2];
  }
  return out;
}

export function pclJobStart(settings: PrintSettings, dpi: number): Uint8Array {
  const out = new Out(256);
  out.u8(ESC, 0x45);
  out.str(`\x1B&l${paperCode(settings.paper)}A`);
  // 가로 문서는 가로 방향 래스터로 만들어지므로 프린터 쪽 용지 방향도 가로로 맞춘다.
  out.str(`\x1B&l${settings.orientation === "LANDSCAPE" ? 1 : 0}O`);
  out.str(`\x1B&l${duplexCode(settings.duplex)}S`);
  if (settings.duplex === "SHORT_EDGE") out.str(`\x1B&l1G`);
  out.str(`\x1B&l${Math.max(1, Math.min(99, settings.copies))}X`);
  out.str(`\x1B&l0E`);
  out.str(`\x1B*t${dpi}R`);
  return out.result();
}

export function pclPage(page: RasterPage, opts: { mono: boolean }): Uint8Array {
  const bpl = opts.mono ? (page.width + 7) >> 3 : page.width * 3;
  const out = new Out(page.height * (bpl + 8) + 128);
  out.str(`\x1B*p0x0Y`);
  out.str(`\x1B*r${page.width}S`);
  out.str(`\x1B*r${page.height}T`);
  if (opts.mono) {
    out.str(`\x1B*b0M`);
    out.str(`\x1B*r1A`);
    const packed = packMonoPage(page);
    const prefix = encoder.encode(`\x1B*b${bpl}W`);
    for (let y = 0; y < page.height; y++) {
      out.bytes(prefix);
      out.bytes(packed.subarray(y * bpl, y * bpl + bpl));
    }
  } else {
    out.u8(ESC, 0x2a, 0x76, 0x36, 0x57, 0, 1, 0, 8, 8, 8);
    out.str(`\x1B*b0M`);
    out.str(`\x1B*r1A`);
    const packed = packRgbPage(page);
    const prefix = encoder.encode(`\x1B*b${bpl}W`);
    for (let y = 0; y < page.height; y++) {
      out.bytes(prefix);
      out.bytes(packed.subarray(y * bpl, y * bpl + bpl));
    }
  }
  out.str(`\x1B*rC`);
  out.str(`\x1B&l0H`);
  return out.result();
}

export function pclJobEnd(): Uint8Array {
  return Uint8Array.of(ESC, 0x45);
}

export function concatBytes(chunks: Uint8Array[]): Uint8Array {
  let total = 0;
  for (const c of chunks) total += c.length;
  const out = new Uint8Array(total);
  let o = 0;
  for (const c of chunks) {
    out.set(c, o);
    o += c.length;
  }
  return out;
}

/** HP PCL 5 raster — duplex &l#S (0 simplex, 1 long-edge, 2 short-edge). */
export function encodePclJob(
  pages: RasterPage[],
  settings: PrintSettings,
  opts: { mono: boolean; dpi?: number },
): Uint8Array {
  const dpi = opts.dpi ?? 75;
  return concatBytes([pclJobStart(settings, dpi), ...pages.map((p) => pclPage(p, { mono: opts.mono })), pclJobEnd()]);
}

export const PCL_MIME = "application/vnd.hp-PCL";
