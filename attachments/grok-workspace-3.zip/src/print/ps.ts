import type { PrintSettings } from "../domain/model.ts";
import { pageSizePoints } from "../render/paper.ts";
import type { RasterPage } from "../render/rasterize.ts";

export const PS_MIME = "application/postscript";

/** Adobe ASCII85 (z 단축 없이). 모든 PostScript 프린터가 읽는다. */
export function ascii85(bytes: Uint8Array): string {
  const lines: string[] = [];
  let line = "";
  const flush = (s: string) => {
    line += s;
    while (line.length >= 72) {
      lines.push(line.slice(0, 72));
      line = line.slice(72);
    }
  };
  for (let i = 0; i < bytes.length; i += 4) {
    const n = Math.min(4, bytes.length - i);
    let v = 0;
    for (let k = 0; k < 4; k++) v = v * 256 + (k < n ? bytes[i + k] : 0);
    const chars: string[] = [];
    for (let k = 4; k >= 0; k--) {
      chars[k] = String.fromCharCode(33 + (v % 85));
      v = Math.floor(v / 85);
    }
    flush(chars.slice(0, n + 1).join(""));
  }
  if (line) lines.push(line);
  return `${lines.join("\n")}~>\n`;
}

function pixelData(page: RasterPage, mono: boolean): Uint8Array {
  const { width: w, height: h, data } = page;
  if (mono) {
    const out = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) {
      const o = i * 4;
      out[i] = Math.round(data[o] * 0.299 + data[o + 1] * 0.587 + data[o + 2] * 0.114);
    }
    return out;
  }
  const out = new Uint8Array(w * h * 3);
  for (let i = 0; i < w * h; i++) {
    out[i * 3] = data[i * 4];
    out[i * 3 + 1] = data[i * 4 + 1];
    out[i * 3 + 2] = data[i * 4 + 2];
  }
  return out;
}

/** PostScript Level 2: 페이지마다 setpagedevice로 용지·양면·매수를 정하고 래스터를 그린다. */
export function encodePostScript(
  pages: RasterPage[],
  settings: PrintSettings,
  opts: { mono: boolean; dpi?: number },
): Uint8Array {
  const pts = pageSizePoints(settings.paper, settings.orientation);
  const pw = pts.width.toFixed(2);
  const ph = pts.height.toFixed(2);
  const duplex = settings.duplex !== "NONE";
  const tumble = settings.duplex === "SHORT_EDGE";
  const copies = Math.max(1, Math.min(99, settings.copies));
  const parts: string[] = [`%!PS-Adobe-3.0\n%%Pages: ${pages.length}\n%%EndComments\n`];
  pages.forEach((page, i) => {
    const space = opts.mono ? "/DeviceGray" : "/DeviceRGB";
    const decode = opts.mono ? "[0 1]" : "[0 1 0 1 0 1]";
    parts.push(
      `%%Page: ${i + 1} ${i + 1}\n` +
        `<< /PageSize [${pw} ${ph}] /NumCopies ${copies} /Duplex ${duplex} /Tumble ${tumble} >> setpagedevice\n` +
        `gsave\n${pw} ${ph} scale\n${space} setcolorspace\n` +
        `<< /ImageType 1 /Width ${page.width} /Height ${page.height} /BitsPerComponent 8 /Decode ${decode}\n` +
        `/ImageMatrix [${page.width} 0 0 -${page.height} 0 ${page.height}]\n` +
        `/DataSource currentfile /ASCII85Decode filter >> image\n`,
      ascii85(pixelData(page, opts.mono)),
      "grestore\nshowpage\n",
    );
  });
  parts.push("%%EOF\n");
  return new TextEncoder().encode(parts.join(""));
}
