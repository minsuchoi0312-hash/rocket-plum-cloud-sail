import assert from "node:assert/strict";
import { afterEach, describe, it } from "node:test";
import { addressSpaceFor, ensureLocalNetwork, resetLocalNetworkGate, withLocalTarget } from "./local-fetch.ts";

const realFetch = globalThis.fetch;

describe("local network fetch", () => {
  afterEach(() => {
    globalThis.fetch = realFetch;
    resetLocalNetworkGate();
  });

  it("marks LAN hosts as local and this device as loopback", () => {
    assert.equal(addressSpaceFor("192.168.0.100"), "local");
    assert.equal(addressSpaceFor("10.0.0.2"), "local");
    assert.equal(addressSpaceFor("printer.local"), "local");
    assert.equal(addressSpaceFor("localhost"), "loopback");
    assert.equal(addressSpaceFor("127.0.0.1"), "loopback");
    assert.equal(withLocalTarget("192.168.0.100").targetAddressSpace, "local");
  });

  it("permission probe never opens port 9100", async () => {
    const urls: string[] = [];
    globalThis.fetch = (async (input: unknown) => {
      urls.push(String(input));
      return new Response(null, { status: 200 });
    }) as typeof fetch;
    await ensureLocalNetwork("192.168.0.100");
    assert.equal(urls.length, 1);
    assert.match(urls[0], /^http:\/\/192\.168\.0\.100:631\/ipp\/print$/);
    assert.equal(urls.some((u) => u.includes(":9100")), false);
  });

  it("does not wait on the printer when access is already granted", async () => {
    const original = navigator.permissions;
    Object.defineProperty(navigator, "permissions", {
      configurable: true,
      value: {
        query: async () => ({ state: "granted", addEventListener() {} }),
      },
    });
    let called = false;
    globalThis.fetch = (async () => {
      called = true;
      return new Response(null);
    }) as typeof fetch;
    const ok = await ensureLocalNetwork("192.168.0.100");
    assert.equal(ok, true);
    assert.equal(called, false);
    Object.defineProperty(navigator, "permissions", { configurable: true, value: original });
  });
});
