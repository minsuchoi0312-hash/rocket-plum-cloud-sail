import type { PrintSettings } from "../domain/model.ts";
import { pageSizePoints } from "../render/paper.ts";
import type { RasterPage } from "../render/rasterize.ts";

const HEADER_SIZE = 1796;

function u32(buf: DataView, offset: number, value: number) {
  buf.setUint32(offset, value >>> 0, false);
}

function f32(buf: DataView, offset: number, value: number) {
  buf.setFloat32(offset, value, false);
}

function cstr(bytes: Uint8Array, offset: number, value: string, max: number) {
  const enc = new TextEncoder().encode(value.slice(0, max - 1));
  bytes.set(enc, offset);
}

function writeHeader(page: RasterPage, settings: PrintSettings, opts: { mono: boolean; dpi: number }): Uint8Array {
  const bytes = new Uint8Array(HEADER_SIZE);
  const view = new DataView(bytes.buffer);
  const pts = pageSizePoints(settings.paper, settings.orientation);
  const dpi = opts.dpi;
  const bpp = opts.mono ? 8 : 24;
  const bpl = opts.mono ? page.width : page.width * 3;

  cstr(bytes, 0, "PwgRaster", 64);
  cstr(bytes, 192, "Auto", 64);
  u32(view, 272, settings.duplex === "NONE" ? 0 : 1);
  u32(view, 276, dpi);
  u32(view, 280, dpi);
  u32(view, 340, Math.max(1, settings.copies));
  u32(view, 352, Math.round(pts.width));
  u32(view, 356, Math.round(pts.height));
  u32(view, 368, settings.duplex === "SHORT_EDGE" ? 1 : 0);
  u32(view, 372, page.width);
  u32(view, 376, page.height);
  u32(view, 384, 8);
  u32(view, 388, bpp);
  u32(view, 392, bpl);
  u32(view, 396, 0);
  u32(view, 400, opts.mono ? 18 : 19); // sGray / sRGB
  u32(view, 404, 0);
  u32(view, 420, opts.mono ? 1 : 3);
  f32(view, 428, pts.width);
  f32(view, 432, pts.height);
  cstr(bytes, 1668, "relative", 64);
  cstr(bytes, 1732, pts.mediaKeyword, 64);
  return bytes;
}

function pagePixels(page: RasterPage, mono: boolean): Uint8Array {
  const { width: w, height: h, data } = page;
  if (mono) {
    const out = new Uint8Array(w * h);
    for (let i = 0; i < w * h; i++) {
      const o = i * 4;
      out[i] = Math.round(data[o] * 0.299 + data[o + 1] * 0.587 + data[o + 2] * 0.114);
    }
    return out;
  }
  const out = new Uint8Array(w * h * 3);
  for (let i = 0; i < w * h; i++) {
    const s = i * 4;
    const d = i * 3;
    out[d] = data[s];
    out[d + 1] = data[s + 1];
    out[d + 2] = data[s + 2];
  }
  return out;
}

class Bytes {
  buf = new Uint8Array(4096);
  n = 0;
  push(...v: number[]) {
    this.ensure(v.length);
    for (const x of v) this.buf[this.n++] = x;
  }
  pushArr(a: Uint8Array) {
    this.ensure(a.length);
    this.buf.set(a, this.n);
    this.n += a.length;
  }
  ensure(extra: number) {
    if (this.n + extra <= this.buf.length) return;
    let size = this.buf.length;
    while (size < this.n + extra) size *= 2;
    const next = new Uint8Array(size);
    next.set(this.buf.subarray(0, this.n));
    this.buf = next;
  }
  result() {
    return this.buf.subarray(0, this.n);
  }
}

function samePixel(line: Uint8Array, a: number, b: number, bpp: number) {
  for (let k = 0; k < bpp; k++) if (line[a * bpp + k] !== line[b * bpp + k]) return false;
  return true;
}

/** PWG Raster 한 줄: 같은 픽셀 반복(0..127 = n+1번) 또는 직접 나열(−1..−127 = 1−c개). */
export function packPwgLine(line: Uint8Array, bpp: number, out: Bytes) {
  const px = line.length / bpp;
  let i = 0;
  while (i < px) {
    let run = 1;
    while (i + run < px && run < 128 && samePixel(line, i, i + run, bpp)) run++;
    if (run >= 2) {
      out.push(run - 1);
      out.pushArr(line.subarray(i * bpp, i * bpp + bpp));
      i += run;
      continue;
    }
    let lit = 1;
    while (i + lit < px && lit < 128 && !(i + lit + 1 < px && samePixel(line, i + lit, i + lit + 1, bpp))) lit++;
    if (lit === 1) {
      out.push(0);
    } else {
      out.push((1 - lit) & 0xff);
    }
    out.pushArr(line.subarray(i * bpp, (i + lit) * bpp));
    i += lit;
  }
}

/** 한 페이지: 같은 줄이 이어지면 반복 횟수(최대 256)를 앞에 붙이고 한 번만 쓴다. */
export function compressPwgPage(pixels: Uint8Array, width: number, height: number, bpp: number): Uint8Array {
  const out = new Bytes();
  const bpl = width * bpp;
  let y = 0;
  while (y < height) {
    const line = pixels.subarray(y * bpl, y * bpl + bpl);
    let repeat = 1;
    while (y + repeat < height && repeat < 256) {
      const next = pixels.subarray((y + repeat) * bpl, (y + repeat) * bpl + bpl);
      let same = true;
      for (let k = 0; k < bpl; k++) {
        if (line[k] !== next[k]) {
          same = false;
          break;
        }
      }
      if (!same) break;
      repeat++;
    }
    out.push(repeat - 1);
    packPwgLine(line, bpp, out);
    y += repeat;
  }
  return out.result();
}

export function pwgPage(page: RasterPage, settings: PrintSettings, opts: { mono: boolean; dpi: number }): Uint8Array {
  const header = writeHeader(page, settings, opts);
  const body = compressPwgPage(pagePixels(page, opts.mono), page.width, page.height, opts.mono ? 1 : 3);
  const out = new Uint8Array(header.length + body.length);
  out.set(header, 0);
  out.set(body, header.length);
  return out;
}

/** PWG Raster 5102.4: "RaS2" 동기 단어 + (페이지 헤더 + 압축된 줄)들. */
export function encodePwgRaster(
  pages: RasterPage[],
  settings: PrintSettings,
  opts: { mono: boolean; dpi?: number },
): Uint8Array {
  const dpi = opts.dpi ?? 100;
  const chunks: Uint8Array[] = [new TextEncoder().encode("RaS2")];
  for (const page of pages) chunks.push(pwgPage(page, settings, { mono: opts.mono, dpi }));
  let total = 0;
  for (const c of chunks) total += c.length;
  const out = new Uint8Array(total);
  let o = 0;
  for (const c of chunks) {
    out.set(c, o);
    o += c.length;
  }
  return out;
}

export const PWG_MIME = "image/pwg-raster";
export const PWG_HEADER_SIZE = HEADER_SIZE;
