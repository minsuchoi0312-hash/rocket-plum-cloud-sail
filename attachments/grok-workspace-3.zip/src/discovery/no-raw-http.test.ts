import assert from "node:assert/strict";
import { afterEach, describe, it } from "node:test";
import { probeHost } from "./lan.ts";
import { wakePrinter } from "./wake.ts";
import type { Printer } from "../domain/model.ts";

// 회귀 방지: 브라우저가 9100번 포트로 HTTP를 보내면 프린터가 그 문구를 영어 글자로 인쇄한다.
const realFetch = globalThis.fetch;
const urls: string[] = [];

function mockFetch() {
  urls.length = 0;
  globalThis.fetch = (async (input: unknown) => {
    urls.push(String(input));
    throw new Error("refused");
  }) as typeof fetch;
}

const sentToPort9100 = (u: string) => /^https?:\/\/[^/]*:9100(\/|$)/.test(u);

describe("no HTTP to port 9100", () => {
  afterEach(() => {
    globalThis.fetch = realFetch;
  });

  it("LAN probe never touches :9100 directly", async () => {
    mockFetch();
    await probeHost("192.168.0.50");
    assert.ok(urls.length > 0);
    assert.equal(urls.filter(sentToPort9100).length, 0, urls.join("\n"));
  });

  it("wake poke never touches :9100 directly", async () => {
    mockFetch();
    const printer = { host: "192.168.0.51", port: 9100, source: "MANUAL", protocol: "RAW9100", resourcePath: "/", secure: false } as unknown as Printer;
    await wakePrinter(printer, { force: true });
    assert.ok(urls.length > 0);
    assert.equal(urls.filter(sentToPort9100).length, 0, urls.join("\n"));
  });
});
