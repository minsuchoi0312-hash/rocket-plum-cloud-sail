import { helperProbe } from "../print/helper.ts";
import { withLocalTarget } from "../print/local-fetch.ts";

const PRIVATE =
  /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.)/;

const LAST_OCTETS = [2, 3, 4, 10, 11, 12, 15, 16, 20, 21, 22, 25, 30, 40, 50, 51, 60, 80, 100, 101, 110, 150, 200, 254];

export function isPrivateIPv4(ip: string): boolean {
  return PRIVATE.test(ip) && !ip.startsWith("127.") && ip !== "0.0.0.0";
}

export function subnetOf(ip: string): string | null {
  const p = ip.split(".");
  if (p.length !== 4) return null;
  return `${p[0]}.${p[1]}.${p[2]}`;
}

export function candidateIPs(subnet: string, extra: string[] = []): string[] {
  const set = new Set<string>(extra.filter((h) => h.startsWith(`${subnet}.`)));
  for (const n of LAST_OCTETS) set.add(`${subnet}.${n}`);
  return [...set];
}

export async function guessLocalIPv4s(timeoutMs = 450): Promise<string[]> {
  if (typeof RTCPeerConnection === "undefined") return [];
  const ips = new Set<string>();
  const pc = new RTCPeerConnection({ iceServers: [] });
  try {
    pc.createDataChannel("p");
    pc.onicecandidate = (ev) => {
      const line = ev.candidate?.candidate ?? "";
      const m = line.match(/(\d{1,3}(?:\.\d{1,3}){3})/);
      if (m && isPrivateIPv4(m[1])) ips.add(m[1]);
    };
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await wait(timeoutMs);
  } catch {
    /* no WebRTC */
  } finally {
    try {
      pc.close();
    } catch {
      /* ignore */
    }
  }
  return [...ips];
}

function wait(ms: number, signal?: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    if (signal?.aborted) {
      reject(new DOMException("aborted", "AbortError"));
      return;
    }
    const t = setTimeout(resolve, ms);
    signal?.addEventListener(
      "abort",
      () => {
        clearTimeout(t);
        reject(new DOMException("aborted", "AbortError"));
      },
      { once: true },
    );
  });
}

export async function probeUrl(url: string, ms = 280, signal?: AbortSignal): Promise<boolean> {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), ms);
  const onOuter = () => ac.abort();
  signal?.addEventListener("abort", onOuter);
  try {
    await fetch(url, withLocalTarget(host, { method: "GET", mode: "no-cors", cache: "no-store", signal: ac.signal }));
    return true;
  } catch {
    return false;
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onOuter);
  }
}

export interface ProbeHit {
  host: string;
  port: number;
  via: "ipp" | "raw" | "http";
}

export async function probeHost(host: string, signal?: AbortSignal): Promise<ProbeHit | null> {
  // 9100(Raw)은 HTTP 요청을 글자 그대로 인쇄해 버리므로 브라우저가 직접 찔러보지 않는다.
  // PC 도우미가 켜져 있을 때만 도우미를 통해 TCP 연결 여부만 확인한다.
  const [ipp, http, raw] = await Promise.all([
    probeUrl(`http://${host}:631/ipp/print`, 260, signal),
    probeUrl(`http://${host}/`, 220, signal),
    helperProbe(host, 9100, signal),
  ]);
  if (ipp) return { host, port: 631, via: "ipp" };
  if (raw) return { host, port: 9100, via: "raw" };
  if (http) return { host, port: 80, via: "http" };
  return null;
}

async function mapPool<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R | null>): Promise<R[]> {
  const out: R[] = [];
  let i = 0;
  async function worker() {
    while (i < items.length) {
      const idx = i++;
      const hit = await fn(items[idx]);
      if (hit) out.push(hit);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
  return out;
}

const LOCAL_NAMES = [
  "printer.local",
  "hp.local",
  "hpprinter.local",
  "canon.local",
  "epson.local",
  "brother.local",
  "xerox.local",
  "ricoh.local",
  "laserjet.local",
];

export async function scanSubnet(
  subnet: string,
  remembered: string[],
  signal?: AbortSignal,
): Promise<ProbeHit[]> {
  const hosts = candidateIPs(subnet, remembered);
  return mapPool(hosts, 8, (host) => probeHost(host, signal));
}

export async function scanHostnames(signal?: AbortSignal): Promise<ProbeHit[]> {
  return mapPool(LOCAL_NAMES, 6, (host) => probeHost(host, signal));
}

export async function discoverLan(opts: {
  remembered?: string[];
  signal?: AbortSignal;
}): Promise<{ localIps: string[]; subnet: string | null; hits: ProbeHit[] }> {
  const localIps = await guessLocalIPv4s(420);
  const remembered = opts.remembered ?? [];
  const subnet = localIps.map(subnetOf).find((s): s is string => Boolean(s)) ?? subnetOf(remembered[0] ?? "") ?? "192.168.0";
  const [hits, names] = await Promise.all([scanSubnet(subnet, remembered, opts.signal), scanHostnames(opts.signal)]);
  const seen = new Set<string>();
  const merged: ProbeHit[] = [];
  for (const h of [...hits, ...names]) {
    const k = `${h.host}:${h.port}`;
    if (seen.has(k)) continue;
    seen.add(k);
    merged.push(h);
  }
  return { localIps, subnet, hits: merged };
}
