import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { candidateIPs, isPrivateIPv4, subnetOf } from "./lan.ts";

describe("lan ip precision", () => {
  it("accepts RFC1918 and rejects loopback", () => {
    assert.equal(isPrivateIPv4("192.168.0.24"), true);
    assert.equal(isPrivateIPv4("10.0.0.8"), true);
    assert.equal(isPrivateIPv4("172.16.5.5"), true);
    assert.equal(isPrivateIPv4("127.0.0.1"), false);
    assert.equal(isPrivateIPv4("8.8.8.8"), false);
  });

  it("builds a tight candidate list on the inferred subnet", () => {
    const ips = candidateIPs("192.168.1", ["192.168.1.77", "10.0.0.3"]);
    assert.ok(ips.includes("192.168.1.50"));
    assert.ok(ips.includes("192.168.1.77"));
    assert.ok(!ips.includes("10.0.0.3"));
    assert.ok(ips.length < 40);
    assert.equal(new Set(ips).size, ips.length);
  });

  it("parses /24 subnet", () => {
    assert.equal(subnetOf("192.168.0.24"), "192.168.0");
    assert.equal(subnetOf("bad"), null);
  });
});
