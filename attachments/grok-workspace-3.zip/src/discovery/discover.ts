import {
  DEMO_IPP_ID,
  DEMO_LEGACY_ID,
  LOCAL_PRINTER_ID,
  type Printer,
} from "../domain/model";
import { JobError } from "../print/ipp/client";
import { discoverLan, type ProbeHit } from "./lan";
import { wakePrinter } from "./wake";

export function localPrinter(): Printer {
  return {
    id: LOCAL_PRINTER_ID,
    displayName: "이 컴퓨터로 인쇄",
    host: "localhost",
    port: 0,
    resourcePath: "/",
    secure: false,
    protocol: "IPP",
    supportsPdf: true,
    supportsDuplex: true,
    supportsColor: true,
    lastSuccessAt: null,
    source: "LOCAL",
    makeAndModel: "Browser Print Dialog",
  };
}

export function demoIppPrinter(host = "192.168.0.20"): Printer {
  return {
    id: DEMO_IPP_ID,
    displayName: "누구나프린트 데모 (IPP Everywhere)",
    host,
    port: 631,
    resourcePath: "/ipp/print",
    secure: false,
    protocol: "IPP",
    supportsPdf: true,
    supportsDuplex: true,
    supportsColor: true,
    lastSuccessAt: null,
    source: "DEMO",
    makeAndModel: "PublicPrint Virtual IPP",
    pdl: ["application/pdf", "image/pwg-raster"],
    mediaSupported: ["iso_a4_210x297mm", "na_letter_8.5x11in", "na_index-4x6_4x6in"],
    sidesSupported: ["one-sided", "two-sided-long-edge", "two-sided-short-edge"],
  };
}

export function demoLegacyPrinter(host = "192.168.0.50"): Printer {
  return {
    id: DEMO_LEGACY_ID,
    displayName: "구형 사무실 프린터",
    host,
    port: 9100,
    resourcePath: "/",
    secure: false,
    protocol: "RAW9100",
    supportsPdf: false,
    supportsDuplex: true,
    supportsColor: true,
    lastSuccessAt: null,
    source: "DEMO",
    makeAndModel: "Generic PCL",
    pdl: ["application/vnd.hp-PCL", "application/PCLm", "image/pwg-raster"],
    mediaSupported: ["iso_a4_210x297mm", "na_letter_8.5x11in", "na_index-4x6_4x6in"],
    sidesSupported: ["one-sided", "two-sided-long-edge", "two-sided-short-edge"],
    experimental: false,
  };
}

function fromHit(hit: ProbeHit): Printer {
  const raw = hit.via === "raw" || hit.port === 9100;
  // 80번만 답하는 기기는 IPP가 아니다. 631로 단정하면 8초 타임아웃만 난다.
  const webOnly = hit.via === "http";
  const jetdirect = raw || webOnly;
  return {
    id: `scan-${hit.host}`,
    displayName: jetdirect ? `프린터 ${hit.host}` : `IPP 프린터 ${hit.host}`,
    host: hit.host,
    port: jetdirect ? 9100 : 631,
    resourcePath: jetdirect ? "/" : "/ipp/print",
    secure: false,
    protocol: jetdirect ? "RAW9100" : "IPP",
    supportsPdf: jetdirect ? false : null,
    supportsDuplex: true,
    supportsColor: true,
    lastSuccessAt: null,
    source: "MDNS",
    pdl: jetdirect ? ["application/vnd.hp-PCL", "image/pwg-raster"] : undefined,
  };
}

export interface DiscoverOpts {
  remembered?: string[];
  onStatus?: (label: string) => void;
  onLan?: (lan: { localIp: string | null; subnet: string | null }) => void;
}

export async function discoverPrinters(
  onFound: (printer: Printer) => void,
  signal?: AbortSignal,
  opts: DiscoverOpts = {},
): Promise<{ found: number; online: boolean; subnet: string | null; localIp: string | null }> {
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    throw new JobError("NO_NETWORK", "NO_NETWORK");
  }
  opts.onStatus?.("이 기기 주소를 읽는 중…");
  onFound(localPrinter());

  let subnet = "192.168.0";
  let localIp: string | null = null;
  let hits: ProbeHit[] = [];
  try {
    opts.onStatus?.("같은 네트워크 IP를 정밀 검색하는 중…");
    const lan = await discoverLan({ remembered: opts.remembered, signal });
    subnet = lan.subnet ?? subnet;
    localIp = lan.localIps[0] ?? null;
    hits = lan.hits;
    opts.onLan?.({ localIp, subnet });
  } catch {
    opts.onLan?.({ localIp: null, subnet });
  }

  onFound(demoIppPrinter(`${subnet}.20`));
  onFound(demoLegacyPrinter(`${subnet}.50`));

  opts.onStatus?.("절전 프린터에 깨우기 신호…");
  const skip = new Set([`${subnet}.20`, `${subnet}.50`, "127.0.0.1", "localhost"]);
  for (const hit of hits) {
    if (skip.has(hit.host)) continue;
    onFound(fromHit(hit));
  }

  return { found: 3 + hits.length, online: true, subnet, localIp };
}

export async function wakeKnown(printers: Printer[], signal?: AbortSignal) {
  await Promise.all(
    printers.filter((p) => p.source !== "LOCAL").map((p) => wakePrinter(p, { signal }).catch(() => undefined)),
  );
}

const IPV4 =
  /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;

export function isValidIPv4(value: string): boolean {
  return IPV4.test(value.trim());
}

export function isValidPort(value: number): boolean {
  return Number.isInteger(value) && value >= 1 && value <= 65535;
}
