import type { Printer } from "../domain/model.ts";
import { buildGetPrinterAttributes, printerUri } from "../print/ipp/codec.ts";
import { probeUrl } from "./lan.ts";
import { helperWake } from "../print/helper.ts";
import { withLocalTarget } from "../print/local-fetch.ts";

const WAKE_GAP_MS = 12_000;
const lastWake = new Map<string, number>();

function wait(ms: number, signal?: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    if (signal?.aborted) {
      reject(new DOMException("aborted", "AbortError"));
      return;
    }
    const t = setTimeout(resolve, ms);
    signal?.addEventListener(
      "abort",
      () => {
        clearTimeout(t);
        reject(new DOMException("aborted", "AbortError"));
      },
      { once: true },
    );
  });
}

async function poke(url: string, method: "GET" | "POST", body?: Uint8Array, signal?: AbortSignal) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), 320);
  const onOuter = () => ac.abort();
  signal?.addEventListener("abort", onOuter);
  try {
    await fetch(
      url,
      withLocalTarget(hostOf(url), {
        method,
        mode: "no-cors",
        cache: "no-store",
        body: body ? body.slice() : undefined,
        signal: ac.signal,
      }),
    );
  } catch {
    /* closed port or sleep — the SYN itself is the wake */
  } finally {
    clearTimeout(timer);
    signal?.removeEventListener("abort", onOuter);
  }
}

/**
 * Office printers leave sleep on a 631/80 poke. 9100은 HTTP를 글자로 인쇄하므로 건드리지 않는다.
 * Magic-packet WOL needs UDP; this TCP/HTTP nudge is the best a browser can do.
 */
export async function wakePrinter(
  printer: Printer,
  opts?: { signal?: AbortSignal; force?: boolean },
): Promise<{ woke: boolean; skipped: boolean }> {
  if (printer.source === "LOCAL") return { woke: false, skipped: true };
  const key = `${printer.host}:${printer.port}`;
  const prev = lastWake.get(key) ?? 0;
  if (!opts?.force && Date.now() - prev < WAKE_GAP_MS) return { woke: true, skipped: true };

  if (printer.source === "DEMO") {
    await wait(70, opts?.signal);
    lastWake.set(key, Date.now());
    return { woke: true, skipped: false };
  }

  const host = printer.host;
  let ipp: Uint8Array | undefined;
  try {
    ipp = buildGetPrinterAttributes(printerUri(host, printer.port || 631, printer.resourcePath || "/ipp/print", printer.secure), 1);
  } catch {
    ipp = undefined;
  }

  await Promise.all([
    poke(`http://${host}:631/ipp/print`, "POST", ipp, opts?.signal),
    poke(`http://${host}/`, "GET", undefined, opts?.signal),
    probeUrl(`http://${host}:80/`, 280, opts?.signal),
    helperWake(host, 9100, opts?.signal),
  ]);
  await wait(160, opts?.signal);
  lastWake.set(key, Date.now());
  return { woke: true, skipped: false };
}

export function rememberWake(host: string, port: number) {
  lastWake.set(`${host}:${port}`, Date.now());
}
