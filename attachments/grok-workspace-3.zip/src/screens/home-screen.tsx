import { useRef, useState, type ReactNode } from "react";
import { ChevronRight, FileText, Image as ImageIcon, Settings, Sheet } from "lucide-react";
import { PhoneFrame, ScreenBody, TopBar } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/data/store";
import { localPrinter } from "@/discovery/discover";
import { DEFAULT_SETTINGS, LOCAL_PRINTER_ID } from "@/domain/model";

const MAX_IMAGES = 20;
const MAX_PDF_BYTES = 40 * 1024 * 1024;

export function HomeScreen() {
  const go = useAppStore((s) => s.go);
  const printers = useAppStore((s) => s.printers);
  const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
  const session = useAppStore((s) => s.session);
  const jobs = useAppStore((s) => s.jobs);
  const setSession = useAppStore((s) => s.setSession);
  const photoRef = useRef<HTMLInputElement>(null);
  const pdfRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const printer = printers.find((p) => p.id === selectedPrinterId) ?? printers[0];

  async function openImages(list: FileList | null) {
    const files = [...(list ?? [])].filter((f) => f.type.startsWith("image/")).slice(0, MAX_IMAGES);
    if (files.length === 0) return;
    setError(null);
    const images = files.map((file) => ({
      name: file.name,
      url: URL.createObjectURL(file),
      blob: file,
    }));
    setSession({
      kind: "image",
      name: files.length === 1 ? files[0].name : `사진 ${files.length}장`,
      images,
      pdfBytes: null,
      previewUrl: images[0].url,
      pageCount: images.length,
      settings: { ...DEFAULT_SETTINGS },
    });
    go("preview");
  }

  async function openPdf(list: FileList | null) {
    const file = list?.[0];
    if (!file) return;
    if (file.size > MAX_PDF_BYTES) {
      setError("PDF가 40MB보다 큽니다. 더 작은 파일로 나눠 주세요.");
      return;
    }
    setError(null);
    setBusy("PDF 미리보기 만드는 중…");
    try {
      const pdfBytes = new Uint8Array(await file.arrayBuffer());
      const { pdfPreview } = await import("@/render/pdf-preview");
      const preview = await pdfPreview(pdfBytes);
      setSession({
        kind: "pdf",
        name: file.name,
        images: [],
        pdfBytes,
        previewUrl: preview.url,
        pageCount: preview.pageCount,
        settings: { ...DEFAULT_SETTINGS },
      });
      go("preview");
    } catch {
      setError("이 PDF는 열 수 없습니다. 다른 파일로 시도해 보세요.");
    } finally {
      setBusy(null);
    }
  }

  async function openTest() {
    setError(null);
    setBusy("테스트 페이지 그리는 중…");
    try {
      const target = printer ?? localPrinter();
      const device = `${navigator.language}`;
      const { renderTestPageJpeg } = await import("@/render/test-page");
      const jpeg = await renderTestPageJpeg(target, device, new Date(), { scale: 1.05, quality: 0.82 });
      const copy = new Uint8Array(jpeg.byteLength);
      copy.set(jpeg);
      const url = URL.createObjectURL(new Blob([copy], { type: "image/jpeg" }));
      setSession({
        kind: "test",
        name: "테스트 페이지",
        images: [],
        pdfBytes: null,
        previewUrl: url,
        pageCount: 1,
        settings: { ...DEFAULT_SETTINGS, copies: 1, duplex: "NONE", paper: "A4" },
      });
      go("preview");
    } catch {
      setError("테스트 페이지를 만들지 못했습니다.");
    } finally {
      setBusy(null);
    }
  }

  return (
    <PhoneFrame>
      <TopBar
        title="누구나프린트"
        trailing={
          <Button variant="ghost" size="icon" aria-label="설정" onClick={() => go("settings")}>
            <Settings className="size-5" />
          </Button>
        }
      />
      <ScreenBody className="gap-8">
        <header>
          <h2 className="text-3xl font-medium tracking-tight">무엇을 보낼까요</h2>
          <p className="mt-2 max-w-prose text-sm leading-relaxed text-muted">
            사진이나 PDF를 고른 뒤 매수와 용지를 정합니다. 같은 Wi-Fi가 아니면 IP로 프린터를 넣으세요.
          </p>
        </header>

        <button
          type="button"
          onClick={() => go("printers")}
          className="flex items-center gap-3 border-y border-border py-4 text-left"
        >
          <span className="min-w-0 flex-1">
            <span className="block text-xs text-subtle">프린터</span>
            <span className="mt-1 block truncate text-base font-medium">{printer?.displayName ?? "프린터를 고르세요"}</span>
          </span>
          <span className="flex items-center gap-1 text-sm text-accent">
            변경
            <ChevronRight className="size-4" />
          </span>
        </button>

        <div className="flex flex-col">
          <ActionRow icon={<ImageIcon className="size-5" />} title="사진" hint="여러 장" onClick={() => photoRef.current?.click()} />
          <ActionRow icon={<FileText className="size-5" />} title="PDF" hint="첫 장 미리보기" onClick={() => pdfRef.current?.click()} />
          <ActionRow
            icon={<Sheet className="size-5" />}
            title={busy ?? "테스트 페이지"}
            hint="연결 확인 1장"
            onClick={() => void openTest()}
            disabled={Boolean(busy)}
          />
        </div>
        <input
          ref={photoRef}
          type="file"
          accept="image/*"
          multiple
          className="hidden"
          onChange={(e) => {
            void openImages(e.target.files);
            e.target.value = "";
          }}
        />
        <input
          ref={pdfRef}
          type="file"
          accept="application/pdf,.pdf"
          className="hidden"
          onChange={(e) => {
            void openPdf(e.target.files);
            e.target.value = "";
          }}
        />

        {session ? (
          <Button className="w-full" onClick={() => go("preview")}>
            이어서 인쇄 · {session.name}
          </Button>
        ) : null}

        {error ? <p className="text-sm text-danger">{error}</p> : null}

        {printer?.id === LOCAL_PRINTER_ID ? (
          <p className="text-xs leading-relaxed text-subtle">
            기본은 이 기기의 인쇄 창입니다. 매수는 그 창에 같은 문서를 반복해서 넣습니다. 검색하면 데모 프린터도 나옵니다.
          </p>
        ) : null}

        {jobs.length > 0 ? (
          <section>
            <p className="text-xs text-subtle">최근</p>
            <ul className="mt-2">
              {jobs.slice(0, 4).map((job) => (
                <li key={job.id} className="flex items-center justify-between gap-3 border-b border-border py-3 text-sm">
                  <span className="min-w-0 truncate">{job.printerName}</span>
                  <span className={job.status === "SUCCESS" ? "shrink-0 text-accent" : "shrink-0 text-danger"}>
                    {job.status === "SUCCESS" ? "보냄" : job.status === "PARTIAL" ? "일부" : "실패"}
                    <span className="ml-2 font-mono text-subtle">{job.copies}</span>
                  </span>
                </li>
              ))}
            </ul>
          </section>
        ) : null}
      </ScreenBody>
    </PhoneFrame>
  );
}

function ActionRow({
  icon,
  title,
  hint,
  onClick,
  disabled,
}: {
  icon: ReactNode;
  title: string;
  hint: string;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className="flex h-16 items-center gap-4 border-b border-border text-left disabled:opacity-45"
    >
      <span className="text-fg">{icon}</span>
      <span className="min-w-0 flex-1">
        <span className="block font-medium">{title}</span>
        <span className="block text-xs text-muted">{hint}</span>
      </span>
      <ChevronRight className="size-4 text-subtle" />
    </button>
  );
}
