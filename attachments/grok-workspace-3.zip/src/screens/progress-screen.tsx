import { methodFromResult, rememberSettings } from "@/domain/remember";
import { useEffect, useRef, useState } from "react";
import { PhoneFrame, ScreenBody } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/data/store";
import { usesInAppEngine } from "@/domain/model";
import { JobError } from "@/print/ipp/client";
import { submitPrintJob } from "@/print/submit";
import type { JobErrorCode } from "@/domain/model";

export function ProgressScreen() {
  const go = useAppStore((s) => s.go);
  const session = useAppStore((s) => s.session);
  const printers = useAppStore((s) => s.printers);
  const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
  const setResult = useAppStore((s) => s.setResult);
  const addJob = useAppStore((s) => s.addJob);
  const markSuccess = useAppStore((s) => s.markSuccess);
  const setPdfBytes = useAppStore((s) => s.setPdfBytes);
  const printer = printers.find((p) => p.id === selectedPrinterId);
  const [percent, setPercent] = useState(0);
  const [label, setLabel] = useState("준비 중…");
  const abortRef = useRef<AbortController | null>(null);
  const userCancel = useRef(false);

  useEffect(() => {
    if (!session || !printer) {
      go("home");
      return;
    }
    const ac = new AbortController();
    abortRef.current = ac;

    void (async () => {
      try {
        let pdf = session.pdfBytes;
        let images = session.images;
        if (usesInAppEngine(printer)) {
          if (session.kind === "test") {
            setLabel("앱 변환 엔진 · 테스트 페이지");
            if (session.previewUrl) {
              const blob = await fetch(session.previewUrl).then((r) => r.blob());
              images = [{ name: "test.jpg", url: session.previewUrl, blob }];
            } else {
              const { renderTestPageJpeg } = await import("@/render/test-page");
              const device = `${navigator.platform || "web"} · ${navigator.language}`;
              const jpeg = await renderTestPageJpeg(printer, device, new Date(), { scale: 1.15, quality: 0.8 });
              const copy = new Uint8Array(jpeg.byteLength);
              copy.set(jpeg);
              images = [{ name: "test.jpg", url: "", blob: new Blob([copy.buffer], { type: "image/jpeg" }) }];
            }
            pdf = null;
          } else if (session.kind === "image") {
            setLabel("앱 변환 엔진 · 사진");
            pdf = null;
          }
        } else {
          if (!pdf && session.kind === "image") {
            setLabel("사진으로 PDF 만드는 중…");
            const { imagesToPdf } = await import("@/render/image-to-pdf");
            pdf = await imagesToPdf(session.images, session.settings);
            setPdfBytes(pdf, session.images.length);
          }
          if (!pdf && session.kind === "test") {
            setLabel("테스트 페이지 만드는 중…");
            const { buildTestPagePdf } = await import("@/render/test-page");
            pdf = await buildTestPagePdf(printer);
            setPdfBytes(pdf, 1);
          }
          if (!pdf) throw new JobError("REJECTED", "REJECTED");
        }
        const result = await submitPrintJob({
          printer,
          pdf,
          images,
          settings: session.settings,
          jobName: session.kind === "test" ? "연결-테스트" : "print-job",
          onProgress: (p) => {
            setPercent(p.percent);
            setLabel(p.label);
          },
          signal: ac.signal,
        });
        if (ac.signal.aborted) return;
        addJob({
          id: crypto.randomUUID(),
          printerId: printer.id,
          printerName: printer.displayName,
          documentKind: session.kind,
          copies: session.settings.copies,
          status: result.status,
          error: result.error,
          at: Date.now(),
        });
        if (result.status === "SUCCESS") {
          markSuccess(printer.id, {
            method: methodFromResult(result),
            settings: session.kind === "test" ? undefined : rememberSettings(session.settings),
          });
        }
        setResult({
          status: result.status,
          printerName: printer.displayName,
          usedLocalDialog: result.usedLocalDialog,
          usedHelper: result.usedHelper,
          directRaw: result.directRaw,
          error: result.error,
          jobState: result.jobState,
          sentPages: result.sentPages,
          totalPages: result.totalPages,
          convertedFormat: result.convertedFormat,
          downloadUrl: result.downloadUrl,
          downloadName: result.downloadName,
          packetBytes: result.packetBytes,
        });
        go("result");
      } catch (err) {
        if ((err as Error)?.name === "AbortError") {
          if (userCancel.current) go("preview");
          return;
        }
        const code: JobErrorCode = err instanceof JobError ? err.code : "TIMEOUT";
        addJob({
          id: crypto.randomUUID(),
          printerId: printer.id,
          printerName: printer.displayName,
          documentKind: session.kind,
          copies: session.settings.copies,
          status: "FAILURE",
          error: code,
          at: Date.now(),
        });
        setResult({
          status: "FAILURE",
          error: code,
          printerName: printer.displayName,
        });
        go("result");
      }
    })();

    return () => {
      ac.abort();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <PhoneFrame>
      <ScreenBody className="items-center justify-center text-center">
        <p className="text-sm text-muted">보내는 중</p>
        <p className="mt-4 font-mono text-6xl font-medium tabular-nums tracking-tight">
          {percent}
          <span className="text-2xl text-subtle">%</span>
        </p>
        <p className="mt-3 text-base text-muted">{label}</p>
        <div className="mt-8 h-px w-full max-w-xs bg-border">
          <div className="h-px bg-accent" style={{ width: `${percent}%` }} />
        </div>
        <p className="mt-8 text-sm text-subtle">{printer?.displayName}</p>
        <Button
          variant="secondary"
          className="mt-10"
          onClick={() => {
            userCancel.current = true;
            abortRef.current?.abort();
            go("preview");
          }}
        >
          취소
        </Button>
      </ScreenBody>
    </PhoneFrame>
  );
}
