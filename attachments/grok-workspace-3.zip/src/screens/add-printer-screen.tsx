import { useState, type ReactNode } from "react";
import { PhoneFrame, ScreenBody, TopBar } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { isValidIPv4, isValidPort } from "@/discovery/discover";
import { useAppStore } from "@/data/store";
import type { EngineLanguage, Protocol } from "@/domain/model";
import { cn } from "@/lib/utils";

const PROTOCOLS: { id: Protocol; label: string; port: number; note: string; experimental?: boolean }[] = [
  { id: "IPP", label: "IPP", port: 631, note: "가장 흔함 · 포트 631" },
  { id: "IPPS", label: "IPPS", port: 631, note: "암호화. 사설 인증서는 실패할 수 있음" },
  { id: "RAW9100", label: "Raw 9100", port: 9100, note: "구형 사무기 · 이 컴퓨터 드라이버로 인쇄" },
];

export function AddPrinterScreen() {
  const go = useAppStore((s) => s.go);
  const upsertPrinter = useAppStore((s) => s.upsertPrinter);
  const selectPrinter = useAppStore((s) => s.selectPrinter);
  const lan = useAppStore((s) => s.lan);
  const [name, setName] = useState("");
  const [host, setHost] = useState("");
  const [port, setPort] = useState("631");
  const [protocol, setProtocol] = useState<Protocol>("IPP");
  const [path, setPath] = useState("/ipp/print");
  const [language, setLanguage] = useState<EngineLanguage>("auto");
  const [error, setError] = useState<string | null>(null);

  function applyProtocol(p: Protocol) {
    setProtocol(p);
    const def = PROTOCOLS.find((x) => x.id === p);
    if (def) setPort(String(def.port));
  }

  function submit() {
    setError(null);
    const p = Number(port);
    const hostTrim = host.trim();
    const hostOk = isValidIPv4(hostTrim) || hostTrim === "localhost" || /^[a-z0-9.-]+$/i.test(hostTrim);
    if (!hostOk || !isValidPort(p)) {
      setError("IP 또는 포트가 올바르지 않습니다.");
      return;
    }
    const id = crypto.randomUUID();
    upsertPrinter({
      id,
      displayName: name.trim() || hostTrim,
      host: hostTrim,
      port: p,
      resourcePath: path.trim() || "/ipp/print",
      secure: protocol === "IPPS",
      protocol,
      supportsPdf: protocol === "RAW9100" ? false : null,
      supportsDuplex: true,
      supportsColor: true,
      lastSuccessAt: null,
      source: "MANUAL",
      pdl: protocol === "RAW9100" ? ["application/vnd.hp-PCL", "image/pwg-raster"] : undefined,
      experimental: false,
      language: protocol === "RAW9100" ? language : undefined,
    });
    selectPrinter(id);
    go("printers");
  }

  return (
    <PhoneFrame>
      <TopBar title="프린터 추가" onBack={() => go("printers")} />
      <ScreenBody className="gap-5">
        <Field label="별칭">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="거실 프린터"
            className="field"
          />
        </Field>
        <Field label="IP 주소">
          <input
            value={host}
            onChange={(e) => setHost(e.target.value)}
            placeholder={lan.subnet ? `${lan.subnet}.20` : "192.168.0.20"}
            inputMode="decimal"
            autoCapitalize="off"
            className="field"
          />
          <p className="mt-2 text-xs text-muted">
            {lan.subnet
              ? `이 기기 대역은 ${lan.subnet}.0/24${lan.localIp ? ` (지금 ${lan.localIp})` : ""}입니다.`
              : "같은 Wi-Fi의 IPv4를 입력하세요."}
          </p>
        </Field>
        <Field label="프로토콜">
          <div className="grid grid-cols-3 gap-2">
            {PROTOCOLS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => applyProtocol(item.id)}
                className={cn(
                  "rounded-md border px-2 py-3 text-center text-sm",
                  protocol === item.id ? "border-accent bg-accent-soft text-fg" : "border-border bg-surface text-muted",
                )}
              >
                <span className="block font-medium text-fg">{item.label}</span>
                {item.experimental ? <span className="text-xs text-warn">실험</span> : null}
              </button>
            ))}
          </div>
          <p className="mt-2 text-xs text-muted">{PROTOCOLS.find((item) => item.id === protocol)?.note}</p>
        </Field>
        <Field label="포트">
          <input
            value={port}
            onChange={(e) => setPort(e.target.value)}
            inputMode="numeric"
            className="field"
          />
        </Field>
        {protocol !== "RAW9100" ? (
          <Field label="경로">
            <input value={path} onChange={(e) => setPath(e.target.value)} className="field" />
          </Field>
        ) : (
          <p className="border-y border-border py-3 text-xs leading-relaxed text-muted">
            구형 사무기는 PDF 대신 앱 안 변환 엔진이 바꿔 보냅니다. 기본은 PCL이고, 영어 글자만 나오면 PostScript로 바꿔 보세요.
          </p>
        )}
        {protocol === "RAW9100" ? (
          <Field label="인쇄 언어">
            <div className="grid grid-cols-4 gap-2">
              {(
                [
                  ["auto", "자동"],
                  ["pcl", "PCL"],
                  ["ps", "PostScript"],
                  ["pwg", "PWG"],
                ] as [EngineLanguage, string][]
              ).map(([id, label]) => (
                <button
                  key={id}
                  type="button"
                  onClick={() => setLanguage(id)}
                  className={cn(
                    "h-11 rounded-md border text-sm",
                    language === id ? "border-accent bg-accent-soft text-accent" : "border-border bg-surface text-muted",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          </Field>
        ) : null}
        {error ? <p className="text-sm text-danger">{error}</p> : null}
        <Button className="mt-auto w-full" onClick={submit}>
          저장
        </Button>
      </ScreenBody>
    </PhoneFrame>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-medium">{label}</span>
      {children}
    </label>
  );
}
