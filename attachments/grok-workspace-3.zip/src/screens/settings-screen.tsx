import { useEffect, useState, type ReactNode } from "react";
import { CopyBlock } from "@/components/copy-block";
import { PhoneFrame, ScreenBody, TopBar } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/data/store";
import { getHelperCode, helperState, setHelperCode, type HelperState } from "@/print/helper";

export function SettingsScreen() {
  const go = useAppStore((s) => s.go);
  const jobs = useAppStore((s) => s.jobs);
  const clearJobs = useAppStore((s) => s.clearJobs);
  const [helper, setHelper] = useState<HelperState | null>(null);
  const [code, setCode] = useState(getHelperCode());

  useEffect(() => {
    let live = true;
    void helperState().then((s) => live && setHelper(s));
    return () => {
      live = false;
    };
  }, []);

  async function connect() {
    setHelperCode(code);
    setHelper(await helperState());
  }

  return (
    <PhoneFrame>
      <TopBar title="설정" onBack={() => go("home")} />
      <ScreenBody className="gap-6">
        <section>
          <h2 className="text-2xl font-medium tracking-tight">누구나프린트</h2>
          <p className="mt-1 text-sm text-muted">이 기기에만 저장됩니다.</p>
        </section>

        <Card>
          <p className="text-sm font-medium">변환 엔진</p>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            PCL · PWG Raster 변환기가 앱 안에 들어 있습니다. 구형 사무기를 위해 따로 프로그램을 받지 않습니다.
          </p>
        </Card>

        <Card>
          <p className="text-sm font-medium">
            PC 도우미 (선택) ·{" "}
            <span className={helper === "ready" ? "text-accent" : "text-subtle"}>
              {helper === null ? "확인 중" : helper === "ready" ? "연결됨" : helper === "needs-code" ? "연결 코드 필요" : "꺼져 있음"}
            </span>
          </p>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            9100번 구형 프린터에 변환한 데이터를 곧바로 보냅니다. 꺼져 있으면 이 컴퓨터 드라이버로 인쇄합니다.
            Node 18 이상이 깔린 PC에서 파일을 받아 실행하면 6자리 연결 코드가 나옵니다. 아래에 한 번만 입력하세요.
          </p>
          <div className="mt-3 flex gap-2">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              inputMode="numeric"
              placeholder="연결 코드 6자리"
              className="field min-w-0 flex-1 font-mono tracking-widest"
            />
            <Button variant="secondary" className="h-11" onClick={connect} disabled={code.length !== 6}>
              연결
            </Button>
          </div>
          <div className="mt-3 flex flex-col gap-2">
            <a
              href="/raw-print-helper.mjs"
              download="raw-print-helper.mjs"
              className="inline-flex h-11 items-center justify-center rounded-md border border-border bg-surface text-sm font-medium"
            >
              도우미 파일 받기
            </a>
            <CopyBlock text="node raw-print-helper.mjs" label="실행 명령 복사" />
          </div>
        </Card>

        <section>
          <p className="text-sm font-medium">연결 층</p>
          <ol className="mt-2 space-y-2 text-sm leading-relaxed text-muted">
            <li>
              <span className="font-medium text-fg">1층 IPP</span> — PDF를 받는 AirPrint/Mopria/IPP Everywhere. 그대로
              보냅니다.
            </li>
            <li>
              <span className="font-medium text-fg">2층 변환 엔진</span> — 앱에 내장. PDF를 못 받는 구형기는 PCL 또는
              PWG Raster로 바꿔 보냅니다. 따로 설치하지 않습니다.
            </li>
            <li>
              <span className="font-medium text-fg">3층 이 컴퓨터 드라이버</span> — 앱 도우미가 변환한 페이지를 이
              기기에 깔린 프린터 드라이버로 넘깁니다.
            </li>
            <li>
              <span className="font-medium text-fg">4층 PC 도우미(선택)</span> — 9100번 구형기에 변환한 데이터를
              직접 보냅니다. 꺼져 있으면 3층으로 넘어갑니다.
            </li>
            <li>
              <span className="font-medium text-fg">절전 깨우기</span> — 인쇄 전에 IPP · 웹으로 신호를 보냅니다.
              잠든 사무기도 알아서 일어납니다.
            </li>
          </ol>
        </section>

        <section className="flex flex-col gap-2">
          <p className="text-sm font-medium">앱</p>
          <Row label="오픈소스 라이선스" onClick={() => go("licenses")} />
          <Row label={`최근 작업 삭제 (${jobs.length})`} onClick={clearJobs} />
        </section>

        <section>
          <p className="text-sm leading-relaxed text-muted">
            사진과 PDF, 매수, 용지, 양면, 테스트 페이지, 같은 망 검색, 구형기 PCL 변환까지 이 화면에서 처리합니다. 집 안
            이름을 자동으로 듣거나 USB를 직접 여는 것은 브라우저가 막습니다.
          </p>
        </section>

        <Button variant="secondary" className="mt-auto w-full" onClick={() => go("home")}>
          닫기
        </Button>
      </ScreenBody>
    </PhoneFrame>
  );
}

export function LicensesScreen() {
  const go = useAppStore((s) => s.go);
  return (
    <PhoneFrame>
      <TopBar title="라이선스" onBack={() => go("settings")} />
      <ScreenBody className="gap-4">
        <Card>
          <p className="font-medium">누구나프린트</p>
          <p className="mt-1 text-sm text-muted">Apache License 2.0</p>
          <p className="mt-3 text-sm leading-relaxed text-muted">
            앱 본체는 Apache-2.0입니다. 변환 엔진(PCL/PWG Raster)은 앱 안에 포함되어 있으며 추가 설치가 없습니다.
          </p>
        </Card>
        <Card>
          <p className="font-medium">사용 라이브러리</p>
          <ul className="mt-2 space-y-1 text-sm text-muted">
            <li>pdf-lib — MIT</li>
            <li>pdfjs-dist — Apache-2.0</li>
            <li>React / TanStack — MIT</li>
            <li>Lucide — ISC</li>
            <li>Zustand — MIT</li>
          </ul>
        </Card>
      </ScreenBody>
    </PhoneFrame>
  );
}

function Card({ children }: { children: ReactNode }) {
  return <div className="border-b border-border py-4">{children}</div>;
}

function Row({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex h-12 items-center justify-between border-b border-border text-left text-sm"
    >
      {label}
      <span className="text-subtle">›</span>
    </button>
  );
}
