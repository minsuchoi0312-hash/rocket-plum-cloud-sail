import { useState } from "react";
import { Check, CircleAlert, Download } from "lucide-react";
import { CopyBlock } from "@/components/copy-block";
import { PhoneFrame, ScreenBody } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/data/store";
import { JOB_ERROR_HINT, JOB_ERROR_MESSAGE, PRINTER_PROBLEM_CODES } from "@/domain/errors";
import { openPrintUrl } from "@/print/os-helper";

export function ResultScreen() {
  const go = useAppStore((s) => s.go);
  const result = useAppStore((s) => s.result);
  const session = useAppStore((s) => s.session);
  const setSession = useAppStore((s) => s.setSession);
  const ok = result?.status === "SUCCESS";
  const code = result?.error;
  const partial = result?.status === "PARTIAL";
  const problem = Boolean(code && PRINTER_PROBLEM_CODES.includes(code));
  const duplex = session?.settings.duplex;
  const [printNote, setPrintNote] = useState<string | null>(null);
  const detail = [
    "누구나프린트 인쇄 오류",
    `프린터: ${result?.printerName ?? "-"}`,
    `코드: ${code ?? "-"}`,
    code ? `내용: ${JOB_ERROR_MESSAGE[code]}` : "내용: 인쇄를 완료하지 못했습니다.",
    code ? `안내: ${JOB_ERROR_HINT[code]}` : "",
    `시각: ${new Date().toLocaleString("ko-KR")}`,
  ]
    .filter(Boolean)
    .join("\n");

  function home() {
    setSession(null);
    go("home");
  }

  return (
    <PhoneFrame>
      <ScreenBody className="items-stretch">
        <div className="flex flex-1 flex-col items-center justify-center text-center">
          <div
            className={
              ok
                ? "flex size-14 items-center justify-center rounded-full bg-accent-soft text-accent"
                : "flex size-14 items-center justify-center rounded-full bg-surface-2 text-danger"
            }
          >
            {ok ? <Check className="size-7" strokeWidth={1.7} /> : <CircleAlert className="size-7" strokeWidth={1.7} />}
          </div>
          <h1 className="mt-5 text-3xl font-medium tracking-tight">
            {ok ? "보냈습니다" : partial ? "일부만 보냈습니다" : problem ? "프린터에 문제가 있습니다" : "보내지 못했습니다"}
          </h1>
          <p className="mt-3 max-w-sm text-base leading-relaxed text-muted">
            {ok
              ? result?.directRaw
                ? `${result.printerName}에 ${result.convertedFormat ?? "PCL"} 데이터를 PC 도우미로 직접 보냈습니다.`
                : result?.usedHelper
                  ? `${result.printerName} · 앱 변환 엔진이 ${result.convertedFormat ?? "PCL"}로 바꿔 이 컴퓨터 드라이버로 넘겼습니다.`
                  : result?.convertedFormat
                    ? `${result.printerName}에 ${result.convertedFormat} 변환 작업을 전달했습니다.`
                    : result?.usedLocalDialog
                      ? `${result.printerName}의 인쇄 창입니다. 안 열리면 아래 버튼으로 다시 여세요.`
                      : `${result?.printerName}으로 작업을 전달했습니다.`
              : partial
                ? `${result?.sentPages ?? 0}/${result?.totalPages ?? 0}쪽까지 보냈고 나머지는 보내지 못했습니다.${code ? ` ${JOB_ERROR_MESSAGE[code]}` : ""}`
                : code
                  ? JOB_ERROR_MESSAGE[code]
                  : "인쇄를 완료하지 못했습니다."}
          </p>
          {!ok && code ? <p className="mt-3 max-w-sm text-sm leading-relaxed text-subtle">{JOB_ERROR_HINT[code]}</p> : null}
          {ok && result?.jobState === "completed" ? (
            <p className="mt-3 text-xs text-subtle">프린터가 인쇄를 마쳤다고 알려왔습니다.</p>
          ) : null}
          {ok && result?.jobState === "processing" ? (
            <p className="mt-3 text-xs text-subtle">프린터가 작업을 받아 인쇄하는 중입니다.</p>
          ) : null}
          {ok && result?.convertedFormat ? (
            <p className="mt-3 text-xs text-subtle">
              앱 변환 엔진 · {result.convertedFormat}
              {duplex && duplex !== "NONE" ? ` · 양면 ${duplex === "SHORT_EDGE" ? "짧은 변" : "긴 변"}` : ""}
            </p>
          ) : null}
          {ok && result?.packetBytes ? (
            <p className="mt-1 font-mono text-xs text-subtle">
              {result.convertedFormat ? result.convertedFormat : "IPP"} {result.packetBytes.toLocaleString("ko-KR")}바이트
            </p>
          ) : null}
        </div>

        {!ok ? (
          <div className="mb-6 flex flex-col gap-2">
            <CopyBlock text={detail} label="오류 내용 복사" />
            <p className="mt-2 text-sm font-medium">다른 방법</p>
            <Button variant="secondary" className="w-full" onClick={() => go("printers")}>
              다시 검색
            </Button>
            <Button variant="secondary" className="w-full" onClick={() => go("add-printer")}>
              IP 수동 추가
            </Button>
            <Button
              variant="secondary"
              className="w-full"
              onClick={() => {
                useAppStore.getState().selectPrinter("local-device");
                go("preview");
              }}
            >
              이 컴퓨터로 인쇄
            </Button>
            <p className="px-1 text-xs leading-relaxed text-subtle">
              구형기는 앱 안 변환 엔진이 처리합니다. 이 컴퓨터로 인쇄하면 깔려 있는 드라이버를 씁니다.
            </p>
          </div>
        ) : null}

        {result?.usedLocalDialog && result.downloadUrl ? (
          <Button
            className="mb-3 w-full"
            onClick={() => {
              const opened = openPrintUrl(result.downloadUrl!);
              setPrintNote(opened ? null : "창이 막혔습니다. 아래 파일을 저장한 뒤 인쇄하세요.");
            }}
          >
            인쇄 창 열기{session && session.settings.copies > 1 ? ` · ${session.settings.copies}매` : ""}
          </Button>
        ) : null}
        {printNote ? <p className="mb-3 text-sm text-danger">{printNote}</p> : null}

        {result?.downloadUrl ? (
          <a
            href={result.downloadUrl}
            download={result.downloadName ?? "print.pdf"}
            className="mb-3 inline-flex h-12 items-center justify-center gap-2 rounded-md border border-border bg-surface text-sm font-medium"
          >
            <Download className="size-4" />
            {result.downloadName?.endsWith(".prn") || result.downloadName?.endsWith(".pwg") || result.downloadName?.endsWith(".ps")
              ? "변환 파일 저장"
              : "파일 저장"}
          </a>
        ) : null}

        <Button className="w-full" onClick={home} variant={ok && result?.usedLocalDialog ? "secondary" : "default"}>
          {ok ? "홈으로" : "닫기"}
        </Button>
      </ScreenBody>
    </PhoneFrame>
  );
}
