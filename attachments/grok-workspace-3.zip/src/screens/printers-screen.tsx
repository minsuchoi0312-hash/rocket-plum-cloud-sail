import { useEffect, useRef, useState } from "react";
import { LoaderCircle, Plus, RefreshCw, Trash2, WifiOff } from "lucide-react";
import { PhoneFrame, ScreenBody, TopBar } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { discoverPrinters, localPrinter, wakeKnown } from "@/discovery/discover";
import { JobError } from "@/print/ipp/client";
import { useAppStore, sortedPrinters } from "@/data/store";
import { methodLabel } from "@/domain/remember";
import { canUseDuplex, isPdfDirectSupported, usesInAppEngine, type EngineLanguage, type Printer } from "@/domain/model";
import { JOB_ERROR_MESSAGE } from "@/domain/errors";
import { cn } from "@/lib/utils";

function sourceLabel(p: Printer) {
  if (p.source === "LOCAL") return "이 기기";
  if (p.source === "MANUAL") return "수동";
  if (p.source === "DEMO") return "검색";
  return "검색";
}

function PrinterCard({
  printer,
  selected,
  onSelect,
  onRemove,
  onLanguage,
}: {
  printer: Printer;
  selected: boolean;
  onSelect: () => void;
  onRemove?: () => void;
  onLanguage?: (language: EngineLanguage) => void;
}) {
  const pdfOk = isPdfDirectSupported(printer);
  const engine = usesInAppEngine(printer);
  return (
    <div className={cn("border-b border-border py-4", selected && "border-accent")}>
      <button type="button" onClick={onSelect} className="w-full text-left">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="truncate text-lg font-medium tracking-tight">{printer.displayName}</p>
            <p className="mt-1 truncate text-sm text-muted">
              {printer.source === "LOCAL" ? "브라우저 인쇄" : `${printer.host}:${printer.port}`}
              {printer.secure ? " · IPPS" : printer.protocol === "RAW9100" ? " · Raw 9100" : " · IPP"}
            </p>
            {methodLabel(printer.lastMethod) ? (
              <p className="mt-0.5 truncate text-xs text-subtle">지난번 성공 · {methodLabel(printer.lastMethod)}</p>
            ) : null}
          </div>
          <span className="shrink-0 text-xs text-subtle">{sourceLabel(printer)}</span>
        </div>
        <p className="mt-2 text-xs text-subtle">
          {[pdfOk ? "PDF" : "앱 변환", engine && !pdfOk ? "PCL · PS · PWG" : null, canUseDuplex(printer) ? "양면" : null, printer.secure ? "IPPS" : null]
            .filter(Boolean)
            .join("  ·  ")}
        </p>
        {engine && !pdfOk ? (
          <p className="mt-2 text-xs leading-relaxed text-muted">
            PDF를 직접 받지 않습니다. 앱에 들어 있는 변환 엔진이 그림(PCL/PWG)으로 바꿔 보냅니다.
          </p>
        ) : null}
      </button>
      {engine && onLanguage ? (
        <div className="mt-3">
          <p className="text-xs text-muted">인쇄 언어 (영어 글자나 깨진 그림이 나오면 바꿔 보세요)</p>
          <div className="mt-1.5 flex flex-wrap gap-1.5">
            {(
              [
                ["auto", "자동"],
                ["pcl", "PCL"],
                ["ps", "PostScript"],
                ["pwg", "PWG"],
              ] as [EngineLanguage, string][]
            ).map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => onLanguage(id)}
                className={cn(
                  "h-9 rounded-md border px-3 text-xs",
                  (printer.language ?? "auto") === id ? "border-accent bg-accent-soft text-accent" : "border-border text-muted",
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      ) : null}
      {printer.source === "MANUAL" && onRemove ? (
        <button
          type="button"
          onClick={onRemove}
          className="mt-3 flex items-center gap-1 text-xs text-muted"
          aria-label="프린터 삭제"
        >
          <Trash2 className="size-3.5" />
          삭제
        </button>
      ) : null}
    </div>
  );
}

export function PrintersScreen() {
  const go = useAppStore((s) => s.go);
  const printers = useAppStore((s) => s.printers);
  const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
  const upsertPrinter = useAppStore((s) => s.upsertPrinter);
  const removePrinter = useAppStore((s) => s.removePrinter);
  const selectPrinter = useAppStore((s) => s.selectPrinter);
  const searching = useAppStore((s) => s.searching);
  const setSearching = useAppStore((s) => s.setSearching);
  const setLan = useAppStore((s) => s.setLan);
  const lan = useAppStore((s) => s.lan);
  const [error, setError] = useState<string | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const ran = useRef(false);

  async function search() {
    setError(null);
    setSearching(true);
    setStatus("이 기기 주소를 읽는 중…");
    const ac = new AbortController();
    try {
      upsertPrinter(localPrinter());
      const remembered = printers.filter((p) => p.source !== "LOCAL").map((p) => p.host);
      void wakeKnown(
        printers.filter((p) => p.source !== "LOCAL"),
        ac.signal,
      );
      await discoverPrinters((p) => upsertPrinter(p), ac.signal, {
        remembered,
        onStatus: setStatus,
        onLan: setLan,
      });
    } catch (err) {
      if (err instanceof JobError) setError(JOB_ERROR_MESSAGE[err.code]);
      else if ((err as Error)?.name !== "AbortError") setError(JOB_ERROR_MESSAGE.NOT_FOUND);
    } finally {
      setSearching(false);
      setStatus(null);
    }
  }

  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    void search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const list = sortedPrinters(printers);
  const emptyNet = !searching && list.filter((p) => p.source !== "LOCAL").length === 0;

  return (
    <PhoneFrame>
      <TopBar
        title="프린터"
        onBack={() => go("home")}
        trailing={
          <Button variant="ghost" size="icon" aria-label="다시 검색" onClick={() => void search()} disabled={searching}>
            <RefreshCw className={cn("size-5", searching && "animate-spin")} />
          </Button>
        }
      />
      <ScreenBody className="gap-4">
        {searching ? (
          <div className="flex items-center gap-3 border-b border-border py-3 text-sm text-muted">
            <LoaderCircle className="size-5 animate-spin text-accent" />
            {status ?? "근처 프린터를 찾는 중…"}
          </div>
        ) : lan.subnet ? (
          <p className="text-xs text-subtle">검색 대역 {lan.subnet}.0/24{lan.localIp ? ` · 이 기기 ${lan.localIp}` : ""}</p>
        ) : null}
        {error ? (
          <div className="flex gap-3 border-b border-border py-3 text-sm text-danger">
            <WifiOff className="mt-0.5 size-5 shrink-0" />
            {error}
          </div>
        ) : null}

        <div className="flex flex-col gap-3">
          {list.map((p) => (
            <PrinterCard
              key={p.id}
              printer={p}
              selected={p.id === selectedPrinterId}
              onSelect={() => {
                selectPrinter(p.id);
                go("home");
              }}
              onRemove={p.source === "MANUAL" ? () => removePrinter(p.id) : undefined}
              onLanguage={p.source === "LOCAL" ? undefined : (language) => upsertPrinter({ ...p, language })}
            />
          ))}
        </div>

        {emptyNet || list.length <= 1 ? (
          <div className="mt-2 flex flex-col gap-3">
            <p className="text-sm font-medium">다음 행동</p>
            <HelpCard title="절전이어도 됩니다" body="검색과 인쇄 때 IPP·웹으로 깨우기 신호를 보냅니다. PrinterShare처럼 잠든 사무기를 직접 깨웁니다." />
            <HelpCard title="IP가 있으면 수동 추가" body="같은 대역을 정밀 검색합니다. 그래도 없으면 프린터 네트워크 페이지의 IP를 입력하세요." />
            <HelpCard
              title="AirPrint/Mopria 없는 구형기"
              body="PDF를 못 받아도 됩니다. 앱 안 변환 엔진이 PCL/PWG로 바꿔 보내고, 필요하면 이 컴퓨터 드라이버로 넘깁니다. 따로 설치할 프로그램은 없습니다."
            />
          </div>
        ) : null}

        <Button className="mt-auto w-full" onClick={() => go("add-printer")}>
          <Plus className="size-5" />
          IP로 수동 추가
        </Button>
      </ScreenBody>
    </PhoneFrame>
  );
}

function HelpCard({ title, body }: { title: string; body: string }) {
  return (
    <div className="border-b border-border py-3">
      <p className="font-medium">{title}</p>
      <p className="mt-1 text-sm leading-relaxed text-muted">{body}</p>
    </div>
  );
}
