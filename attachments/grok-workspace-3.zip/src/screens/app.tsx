import { useEffect } from "react";
import { Printer } from "lucide-react";
import { useAppStore } from "@/data/store";
import { LOCAL_PRINTER_ID } from "@/domain/model";
import { localPrinter } from "@/discovery/discover";
import { AddPrinterScreen } from "@/screens/add-printer-screen";
import { HomeScreen } from "@/screens/home-screen";
import { PreviewScreen } from "@/screens/preview-screen";
import { PrintersScreen } from "@/screens/printers-screen";
import { ProgressScreen } from "@/screens/progress-screen";
import { ResultScreen } from "@/screens/result-screen";
import { LicensesScreen, SettingsScreen } from "@/screens/settings-screen";

export function NugunaApp() {
  const screen = useAppStore((s) => s.screen);
  const printers = useAppStore((s) => s.printers);
  const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
  const jobs = useAppStore((s) => s.jobs);
  const go = useAppStore((s) => s.go);
  const printer = printers.find((p) => p.id === selectedPrinterId);

  useEffect(() => {
    void Promise.resolve(useAppStore.persist.rehydrate()).then(() => {
      const state = useAppStore.getState();
      if (!state.printers.some((p) => p.id === LOCAL_PRINTER_ID)) {
        state.upsertPrinter(localPrinter());
      }
      if (!state.selectedPrinterId) state.selectPrinter(LOCAL_PRINTER_ID);
    });
  }, []);

  return (
    <div className="min-h-dvh bg-bg text-fg">
      <div className="mx-auto grid min-h-dvh w-full max-w-6xl lg:grid-cols-[16rem_minmax(0,1fr)]">
        <aside className="hidden flex-col border-r border-border px-6 py-10 lg:flex">
          <p className="text-2xl font-medium tracking-tight">누구나프린트</p>
          <p className="mt-3 text-sm leading-relaxed text-muted">같은 망의 프린터, 또는 이 기기의 인쇄 창.</p>
          <button
            type="button"
            onClick={() => go("printers")}
            className="mt-10 flex items-center gap-3 border-y border-border py-4 text-left"
          >
            <Printer className="size-5 shrink-0" />
            <span className="min-w-0">
              <span className="block text-xs text-subtle">프린터</span>
              <span className="mt-1 block truncate text-sm font-medium">{printer?.displayName ?? "선택 안 함"}</span>
            </span>
          </button>
          <p className="mt-auto pt-8 font-mono text-xs text-subtle">최근 {jobs.length}건 · 이 기기에만</p>
        </aside>
        <main className="mx-auto flex w-full max-w-xl flex-col">{body(screen)}</main>
      </div>
    </div>
  );
}

function body(screen: ReturnType<typeof useAppStore.getState>["screen"]) {
  switch (screen) {
    case "printers":
      return <PrintersScreen />;
    case "add-printer":
      return <AddPrinterScreen />;
    case "preview":
      return <PreviewScreen />;
    case "progress":
      return <ProgressScreen />;
    case "result":
      return <ResultScreen />;
    case "settings":
      return <SettingsScreen />;
    case "licenses":
      return <LicensesScreen />;
    default:
      return <HomeScreen />;
  }
}
