import { Minus, Plus } from "lucide-react";
import type { ReactNode } from "react";
import { PhoneFrame, ScreenBody, TopBar } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { useAppStore } from "@/data/store";
import { canUseColor, canUseDuplex, type ColorMode, type Duplex, type Orientation, type Quality } from "@/domain/model";
import { PAPER_OPTIONS } from "@/render/paper";
import { cn } from "@/lib/utils";

const COLORS: { id: ColorMode; label: string }[] = [
  { id: "AUTO", label: "자동" },
  { id: "COLOR", label: "컬러" },
  { id: "MONO", label: "흑백" },
];

const ORIENTATIONS: { id: Orientation; label: string }[] = [
  { id: "PORTRAIT", label: "세로" },
  { id: "LANDSCAPE", label: "가로" },
];

const DUPLEXES: { id: Duplex; label: string }[] = [
  { id: "NONE", label: "단면" },
  { id: "LONG_EDGE", label: "긴 변" },
  { id: "SHORT_EDGE", label: "짧은 변" },
];

const QUALITIES: { id: Quality; label: string }[] = [
  { id: "FAST", label: "빠르게" },
  { id: "NORMAL", label: "보통" },
  { id: "SHARP", label: "선명" },
];

export function PreviewScreen() {
  const go = useAppStore((s) => s.go);
  const session = useAppStore((s) => s.session);
  const printers = useAppStore((s) => s.printers);
  const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
  const updateSettings = useAppStore((s) => s.updateSettings);
  const printer = printers.find((p) => p.id === selectedPrinterId);
  const settings = session?.settings;

  if (!session || !settings) {
    return (
      <PhoneFrame>
        <TopBar title="미리보기" onBack={() => go("home")} />
        <ScreenBody className="items-center justify-center gap-4 text-center">
          <p className="text-muted">인쇄할 파일이 없습니다.</p>
          <Button onClick={() => go("home")}>홈으로</Button>
        </ScreenBody>
      </PhoneFrame>
    );
  }

  const copies = settings.copies;
  const colorOk = canUseColor(printer);
  const duplexOk = canUseDuplex(printer);

  return (
    <PhoneFrame>
      <TopBar title={session.name} onBack={() => go("home")} />
      <ScreenBody className="gap-5">
        <button
          type="button"
          onClick={() => go("printers")}
          className="flex items-center justify-between border-y border-border py-3 text-left text-sm"
        >
          <span className="min-w-0 truncate">{printer?.displayName ?? "프린터 없음"}</span>
          <span className="shrink-0 text-accent">변경</span>
        </button>

        <div className="bg-surface shadow-soft">
          {session.previewUrl ? (
            <img src={session.previewUrl} alt="" className="mx-auto max-h-80 w-full bg-surface object-contain" />
          ) : (
            <div className="flex h-48 items-center justify-center text-sm text-muted">미리보기 없음</div>
          )}
          <p className="border-t border-border px-4 py-2 font-mono text-xs text-muted">
            {session.pageCount}쪽
            {session.kind === "image" && session.images.length > 1 ? ` · 사진 ${session.images.length}장` : ""}
          </p>
        </div>

        {session.kind === "image" && session.images.length > 1 ? (
          <div className="flex gap-2 overflow-x-auto pb-1">
            {session.images.map((img) => (
              <img key={img.url} src={img.url} alt="" className="h-16 w-16 shrink-0 rounded-lg border border-border object-cover" />
            ))}
          </div>
        ) : null}

        <Row label="매수">
          <div className="flex items-center gap-3">
            <Button
              variant="secondary"
              size="icon"
              aria-label="매수 줄이기"
              disabled={copies <= 1}
              onClick={() => updateSettings({ copies: Math.max(1, copies - 1) })}
            >
              <Minus className="size-4" />
            </Button>
            <span className="w-8 text-center font-mono text-xl tabular-nums">{copies}</span>
            <Button
              variant="secondary"
              size="icon"
              aria-label="매수 늘리기"
              disabled={copies >= 99}
              onClick={() => updateSettings({ copies: Math.min(99, copies + 1) })}
            >
              <Plus className="size-4" />
            </Button>
          </div>
        </Row>

        <Choice label="색" value={colorOk ? settings.color : "MONO"} options={COLORS} disabled={!colorOk} onChange={(color) => updateSettings({ color })} />
        <Choice label="방향" value={settings.orientation} options={ORIENTATIONS} onChange={(orientation) => updateSettings({ orientation })} />
        <div>
          <p className="mb-2 text-sm font-medium">용지</p>
          <div className="flex flex-wrap gap-2">
            {PAPER_OPTIONS.map((item) => (
              <Chip key={item.id} active={settings.paper === item.id} onClick={() => updateSettings({ paper: item.id })}>
                {item.label}
              </Chip>
            ))}
          </div>
        </div>
        <Choice
          label="양면"
          value={settings.duplex}
          options={DUPLEXES}
          disabled={!duplexOk}
          onChange={(duplex) => updateSettings({ duplex })}
        />
        <Choice label="품질" value={settings.quality} options={QUALITIES} onChange={(quality) => updateSettings({ quality })} />

        <div className="sticky bottom-0 mt-auto bg-bg pt-3">
          {printer ? (
            <Button className="w-full" onClick={() => go("progress")}>
              인쇄
            </Button>
          ) : (
            <Button className="w-full" onClick={() => go("printers")}>
              프린터 선택
            </Button>
          )}
        </div>
      </ScreenBody>
    </PhoneFrame>
  );
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <p className="text-sm font-medium">{label}</p>
      {children}
    </div>
  );
}

function Choice<T extends string>({
  label,
  value,
  options,
  disabled,
  onChange,
}: {
  label: string;
  value: T;
  options: { id: T; label: string }[];
  disabled?: boolean;
  onChange: (id: T) => void;
}) {
  return (
    <div>
      <p className="mb-2 text-sm font-medium">{label}</p>
      <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` }}>
        {options.map((item) => (
          <Chip key={item.id} active={value === item.id} disabled={disabled} onClick={() => onChange(item.id)}>
            {item.label}
          </Chip>
        ))}
      </div>
    </div>
  );
}

function Chip({
  active,
  disabled,
  onClick,
  children,
}: {
  active: boolean;
  disabled?: boolean;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "h-11 rounded-md border px-3 text-sm",
        active ? "border-accent bg-accent-soft text-accent" : "border-border bg-surface text-muted",
        disabled && "opacity-45",
      )}
    >
      {children}
    </button>
  );
}
