/**
 * 복사.
 * 미리보기 iframe은 Clipboard API를 막는 경우가 많다.
 * writeText를 기다린 뒤에 execCommand를 부르면 클릭 제스처가 사라져 둘 다 실패하므로,
 * 둘 다 클릭과 같은 턴에 시작한다.
 */
export async function copyText(text: string): Promise<boolean> {
  const modern = startClipboardWrite(text);
  const legacy = copyWithCommand(text);
  return (await modern) || legacy;
}

function startClipboardWrite(text: string): Promise<boolean> {
  try {
    if (typeof navigator === "undefined" || !navigator.clipboard?.writeText || !window.isSecureContext) {
      return Promise.resolve(false);
    }
    return navigator.clipboard.writeText(text).then(
      () => true,
      () => false,
    );
  } catch {
    return Promise.resolve(false);
  }
}

function copyWithCommand(text: string): boolean {
  if (typeof document === "undefined") return false;
  let injected = false;
  const onCopy = (event: ClipboardEvent) => {
    try {
      event.preventDefault();
      event.clipboardData?.setData("text/plain", text);
      injected = true;
    } catch {
      /* ignore */
    }
  };
  document.addEventListener("copy", onCopy, true);
  const area = document.createElement("textarea");
  area.value = text;
  area.setAttribute("readonly", "");
  area.setAttribute("aria-hidden", "true");
  area.tabIndex = -1;
  area.style.position = "fixed";
  area.style.top = "0";
  area.style.left = "0";
  area.style.width = "2em";
  area.style.height = "2em";
  area.style.padding = "0";
  area.style.border = "none";
  area.style.outline = "none";
  area.style.boxShadow = "none";
  area.style.background = "transparent";
  area.style.fontSize = "16px";
  document.body.appendChild(area);
  const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  area.focus({ preventScroll: true });
  area.select();
  area.setSelectionRange(0, text.length);
  let ok = false;
  try {
    ok = document.execCommand("copy");
  } catch {
    ok = false;
  } finally {
    document.removeEventListener("copy", onCopy, true);
    area.remove();
    previous?.focus({ preventScroll: true });
  }
  return ok || injected;
}
