import { createFileRoute } from "@tanstack/react-router";
import { NugunaApp } from "@/screens/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <NugunaApp />;
}
