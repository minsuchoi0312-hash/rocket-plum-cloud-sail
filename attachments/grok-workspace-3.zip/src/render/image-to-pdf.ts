import { PDFDocument } from "pdf-lib";
import type { PrintSettings } from "../domain/model";
import { pageSizePoints } from "./paper";

async function toJpeg(blob: Blob): Promise<Uint8Array> {
  if (blob.type === "image/jpeg" || blob.type === "image/jpg") {
    return new Uint8Array(await blob.arrayBuffer());
  }
  const bmp = await createImageBitmap(blob);
  const canvas = document.createElement("canvas");
  canvas.width = bmp.width;
  canvas.height = bmp.height;
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("canvas");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(bmp, 0, 0);
  bmp.close();
  const out = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("jpeg"))), "image/jpeg", 0.92);
  });
  return new Uint8Array(await out.arrayBuffer());
}

export async function imagesToPdf(images: { blob: Blob }[], settings: PrintSettings): Promise<Uint8Array> {
  const doc = await PDFDocument.create();
  const size = pageSizePoints(settings.paper, settings.orientation);
  for (const image of images) {
    const jpeg = await toJpeg(image.blob);
    const embedded = await doc.embedJpg(jpeg);
    const page = doc.addPage([size.width, size.height]);
    const scale = Math.min(size.width / embedded.width, size.height / embedded.height);
    const w = embedded.width * scale;
    const h = embedded.height * scale;
    page.drawImage(embedded, {
      x: (size.width - w) / 2,
      y: (size.height - h) / 2,
      width: w,
      height: h,
    });
  }
  return doc.save();
}

/** 브라우저 인쇄 창은 매수를 모르므로, 문서 전체를 매수만큼 이어 붙인다. */
export async function repeatPdfCopies(pdf: Uint8Array, copies: number): Promise<Uint8Array> {
  const count = Math.max(1, Math.min(99, Math.floor(copies)));
  if (count <= 1) return pdf;
  const src = await PDFDocument.load(pdf);
  const out = await PDFDocument.create();
  const indexes = src.getPageIndices();
  for (let copy = 0; copy < count; copy++) {
    const pages = await out.copyPages(src, indexes);
    for (const page of pages) out.addPage(page);
  }
  return out.save();
}
