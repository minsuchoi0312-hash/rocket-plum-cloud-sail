import type { ColorMode, Orientation, PaperSize, Printer, PrintSettings } from "../domain/model.ts";
import { dpiForQuality } from "../domain/model.ts";
import { pageSizePoints } from "./paper.ts";

export interface RasterPage {
  width: number;
  height: number;
  data: Uint8ClampedArray;
}

export const RASTER_DPI = 80;

function pagePixels(paper: PaperSize, orientation: Orientation, dpi: number) {
  const pts = pageSizePoints(paper, orientation);
  const width = Math.max(32, Math.round((pts.width / 72) * dpi));
  const height = Math.max(32, Math.round((pts.height / 72) * dpi));
  // 예전에는 긴 변을 840~1400px로 잘라 선언한 dpi와 실제 크기가 어긋나 글자가 작게 찍혔다.
  // 이제는 용지 크기 × dpi 그대로 만들고, 메모리는 페이지 단위로 나눠 처리해 감당한다.
  return { width, height };
}

function canvasContext(w: number, h: number) {
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { alpha: false, willReadFrequently: true });
  if (!ctx) throw new Error("canvas");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, w, h);
  return { canvas, ctx };
}

function toPage(ctx: CanvasRenderingContext2D, w: number, h: number): RasterPage {
  const image = ctx.getImageData(0, 0, w, h);
  return { width: w, height: h, data: image.data };
}

async function bitmapFromBlob(blob: Blob): Promise<ImageBitmap> {
  try {
    return await createImageBitmap(blob, { imageOrientation: "from-image" });
  } catch {
    return createImageBitmap(blob);
  }
}

export type RasterSource = { pdf?: Uint8Array | null; images?: { blob: Blob }[] };

export interface RasterProgress {
  done: number;
  total: number;
}

/** 페이지를 한 장씩 만들어 넘긴다. 호출한 쪽이 변환 뒤 바로 버리면 메모리를 아낄 수 있다. */
export async function* rasterPages(
  source: RasterSource,
  settings: PrintSettings,
  dpi = dpiForQuality(settings.quality),
  signal?: AbortSignal,
): AsyncGenerator<{ page: RasterPage; progress: RasterProgress }> {
  const abortIfNeeded = () => {
    if (signal?.aborted) throw new DOMException("aborted", "AbortError");
  };
  if (source.images && source.images.length > 0) {
    const target = pagePixels(settings.paper, settings.orientation, dpi);
    const total = source.images.length;
    for (let i = 0; i < total; i++) {
      abortIfNeeded();
      const bmp = await bitmapFromBlob(source.images[i].blob);
      const width = Math.min(bmp.width, target.width);
      const height = Math.min(bmp.height, target.height);
      const { ctx } = canvasContext(width, height);
      ctx.drawImage(bmp, 0, 0, width, height);
      bmp.close();
      yield { page: toPage(ctx, width, height), progress: { done: i + 1, total } };
    }
    return;
  }
  const { loadPdf } = await import("./pdf-preview.ts");
  const pdf = await loadPdf(source.pdf ?? new Uint8Array());
  const { width, height } = pagePixels(settings.paper, settings.orientation, dpi);
  for (let n = 1; n <= pdf.numPages; n++) {
    abortIfNeeded();
    const page = await pdf.getPage(n);
    const unscaled = page.getViewport({ scale: 1 });
    const scale = Math.min(width / unscaled.width, height / unscaled.height);
    const viewport = page.getViewport({ scale });
    const { canvas, ctx } = canvasContext(width, height);
    ctx.translate((width - viewport.width) / 2, (height - viewport.height) / 2);
    await page.render({ canvas, canvasContext: ctx, viewport }).promise;
    yield { page: toPage(ctx, width, height), progress: { done: n, total: pdf.numPages } };
  }
}

export async function rasterizeImages(
  images: { blob: Blob }[],
  settings: PrintSettings,
  dpi = dpiForQuality(settings.quality),
): Promise<RasterPage[]> {
  const pages: RasterPage[] = [];
  for await (const { page } of rasterPages({ images }, settings, dpi)) pages.push(page);
  return pages;
}

export async function rasterizePdf(
  pdfBytes: Uint8Array,
  settings: PrintSettings,
  dpi = dpiForQuality(settings.quality),
): Promise<RasterPage[]> {
  const pages: RasterPage[] = [];
  for await (const { page } of rasterPages({ pdf: pdfBytes }, settings, dpi)) pages.push(page);
  return pages;
}

export function shouldForceMono(settings: { color: ColorMode }, _printer: Printer): boolean {
  return settings.color === "MONO";
}
