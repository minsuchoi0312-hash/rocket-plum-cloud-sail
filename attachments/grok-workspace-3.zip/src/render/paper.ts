import type { Orientation, PaperSize } from "../domain/model";

export type ConcretePaper = Exclude<PaperSize, "AUTO">;

interface PaperSpec {
  width: number;
  height: number;
  mediaKeyword: string;
}

/** Points (1/72 in). B5 is JIS — PCL paper code 45 and most Korean office printers. */
const SPECS: Record<ConcretePaper, PaperSpec> = {
  A4: { width: 595.28, height: 841.89, mediaKeyword: "iso_a4_210x297mm" },
  A5: { width: 419.53, height: 595.28, mediaKeyword: "iso_a5_148x210mm" },
  B5: { width: 515.91, height: 728.5, mediaKeyword: "jis_b5_182x257mm" },
  LETTER: { width: 612, height: 792, mediaKeyword: "na_letter_8.5x11in" },
  LEGAL: { width: 612, height: 1008, mediaKeyword: "na_legal_8.5x14in" },
  PHOTO_4X6: { width: 288, height: 432, mediaKeyword: "na_index-4x6_4x6in" },
};

export const PAPER_OPTIONS: { id: PaperSize; label: string }[] = [
  { id: "AUTO", label: "자동" },
  { id: "A4", label: "A4" },
  { id: "A5", label: "A5" },
  { id: "B5", label: "B5" },
  { id: "LETTER", label: "레터" },
  { id: "LEGAL", label: "리걸" },
  { id: "PHOTO_4X6", label: "4×6" },
];

export function resolvePaper(paper: PaperSize): ConcretePaper {
  if (paper === "AUTO") return "A4";
  return paper;
}

export function pageSizePoints(paper: PaperSize, orientation: Orientation) {
  const spec = SPECS[resolvePaper(paper)];
  const landscape = orientation === "LANDSCAPE";
  return {
    width: landscape ? spec.height : spec.width,
    height: landscape ? spec.width : spec.height,
    mediaKeyword: spec.mediaKeyword,
  };
}
