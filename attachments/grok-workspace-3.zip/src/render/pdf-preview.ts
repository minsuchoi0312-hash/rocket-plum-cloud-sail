import workerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";
import { getDocument, GlobalWorkerOptions, type PDFDocumentProxy } from "pdfjs-dist";

GlobalWorkerOptions.workerSrc = workerUrl;

export async function loadPdf(data: Uint8Array): Promise<PDFDocumentProxy> {
  const copy = data.slice();
  return getDocument({ data: copy }).promise;
}

export async function pdfPreview(data: Uint8Array, maxWidth = 900): Promise<{ url: string; pageCount: number }> {
  const pdf = await loadPdf(data);
  const page = await pdf.getPage(1);
  const base = page.getViewport({ scale: 1 });
  const viewport = page.getViewport({ scale: Math.min(2, maxWidth / base.width) });
  const canvas = document.createElement("canvas");
  canvas.width = Math.ceil(viewport.width);
  canvas.height = Math.ceil(viewport.height);
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("canvas");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  await page.render({ canvas, canvasContext: ctx, viewport }).promise;
  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("preview"))), "image/jpeg", 0.86);
  });
  return { url: URL.createObjectURL(blob), pageCount: pdf.numPages };
}
