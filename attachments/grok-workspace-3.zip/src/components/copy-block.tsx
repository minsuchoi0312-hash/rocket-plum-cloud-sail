import { useRef, useState } from "react";
import { Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { copyText } from "@/lib/clipboard";

/** 자동 복사가 막히면 글을 그대로 보여 주고 선택해 둔다. */
export function CopyBlock({ text, label }: { text: string; label: string }) {
  const [state, setState] = useState<"idle" | "ok" | "manual">("idle");
  const areaRef = useRef<HTMLTextAreaElement>(null);

  async function onCopy() {
    const ok = await copyText(text);
    setState(ok ? "ok" : "manual");
    if (!ok) {
      requestAnimationFrame(() => {
        const area = areaRef.current;
        if (!area) return;
        area.focus({ preventScroll: true });
        area.select();
      });
    } else {
      window.setTimeout(() => setState("idle"), 2000);
    }
  }

  return (
    <div className="flex flex-col gap-2">
      <Button variant="secondary" className="w-full" onClick={() => void onCopy()}>
        <Copy className="size-4" />
        {state === "ok" ? "복사했습니다" : label}
      </Button>
      {state === "manual" ? (
        <>
          <p className="text-xs leading-relaxed text-muted">이 화면에서는 자동 복사가 막혀 있습니다. 아래 글이 선택되어 있으니 복사만 누르세요.</p>
          <textarea
            ref={areaRef}
            readOnly
            value={text}
            onFocus={(e) => e.currentTarget.select()}
            className="min-h-28 w-full resize-none rounded-md border border-border bg-surface p-3 font-mono text-xs leading-relaxed text-fg"
          />
        </>
      ) : null}
    </div>
  );
}
