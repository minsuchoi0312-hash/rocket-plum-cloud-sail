import type { ReactNode } from "react";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function PhoneFrame({ children }: { children: ReactNode }) {
  return <div className="flex min-h-dvh flex-1 flex-col">{children}</div>;
}

export function TopBar({
  title,
  onBack,
  trailing,
}: {
  title: string;
  onBack?: () => void;
  trailing?: ReactNode;
}) {
  return (
    <header className="sticky top-0 z-10 flex h-14 items-center gap-1 border-b border-border bg-bg/90 px-2 backdrop-blur-md">
      {onBack ? (
        <Button variant="ghost" size="icon" aria-label="뒤로" onClick={onBack}>
          <ChevronLeft className="size-5" />
        </Button>
      ) : (
        <span className="size-11 shrink-0" />
      )}
      <h1 className="min-w-0 flex-1 truncate text-center text-base font-medium tracking-tight">{title}</h1>
      <div className="flex size-11 shrink-0 items-center justify-center">{trailing}</div>
    </header>
  );
}

export function ScreenBody({ className, children }: { className?: string; children: ReactNode }) {
  return (
    <div className={cn("screen-in flex flex-1 flex-col px-5 pt-6 pb-8", className)} style={{ paddingBottom: "max(2rem, env(safe-area-inset-bottom))" }}>
      {children}
    </div>
  );
}
