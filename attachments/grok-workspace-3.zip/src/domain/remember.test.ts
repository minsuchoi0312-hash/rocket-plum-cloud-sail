import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { applyRemembered, methodFromResult, methodLabel, rememberSettings } from "./remember.ts";
import { DEFAULT_SETTINGS, usesInAppEngine, type Printer } from "./model.ts";
import { pickEngineFormat } from "../print/engine.ts";

const base = {
  id: "p",
  displayName: "사무기",
  host: "192.168.0.9",
  port: 631,
  resourcePath: "/ipp/print",
  secure: false,
  protocol: "IPP",
  supportsPdf: null,
  supportsDuplex: null,
  supportsColor: null,
  lastSuccessAt: null,
  source: "MANUAL",
} as Printer;

describe("remembered print method", () => {
  it("maps results to a method", () => {
    assert.equal(methodFromResult({ directRaw: true, convertedFormat: "PCL" }), "RAW_HELPER");
    assert.equal(methodFromResult({ usedHelper: true, convertedFormat: "PCL" }), "OS_DRIVER");
    assert.equal(methodFromResult({ usedLocalDialog: true }), "OS_DRIVER");
    assert.equal(methodFromResult({ convertedFormat: "PCL" }), "IPP_PCL");
    assert.equal(methodFromResult({ convertedFormat: "PWG Raster" }), "IPP_PWG");
    assert.equal(methodFromResult({}), "IPP_PDF");
    assert.equal(methodLabel(undefined), null);
  });

  it("skips the PDF attempt when conversion worked last time", () => {
    assert.equal(usesInAppEngine(base), false);
    const pcl = { ...base, lastMethod: "IPP_PCL" } as Printer;
    assert.equal(usesInAppEngine(pcl), true);
    assert.equal(pickEngineFormat(pcl), "pcl");
    assert.equal(pickEngineFormat({ ...base, lastMethod: "IPP_PWG" } as Printer), "pwg");
  });

  it("restores last settings but keeps the copy count", () => {
    const saved = rememberSettings({ ...DEFAULT_SETTINGS, copies: 5, duplex: "LONG_EDGE", color: "MONO", paper: "A5" });
    assert.equal("copies" in saved, false);
    const next = applyRemembered({ ...DEFAULT_SETTINGS, copies: 2 }, { ...base, lastSettings: saved });
    assert.equal(next.copies, 2);
    assert.equal(next.duplex, "LONG_EDGE");
    assert.equal(next.color, "MONO");
    assert.equal(next.paper, "A5");
    assert.deepEqual(applyRemembered(DEFAULT_SETTINGS, base), DEFAULT_SETTINGS);
  });
});
