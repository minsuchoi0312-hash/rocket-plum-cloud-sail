import type { PrintMethod, Printer, PrintSettings, RememberedSettings } from "./model.ts";

export function methodFromResult(r: {
  directRaw?: boolean;
  usedHelper?: boolean;
  usedLocalDialog?: boolean;
  convertedFormat?: string;
}): PrintMethod {
  if (r.directRaw) return "RAW_HELPER";
  if (r.usedHelper || r.usedLocalDialog) return "OS_DRIVER";
  if (r.convertedFormat === "PWG Raster") return "IPP_PWG";
  if (r.convertedFormat === "PCL") return "IPP_PCL";
  if (r.convertedFormat === "PostScript") return "IPP_PS";
  return "IPP_PDF";
}

export function methodLabel(method: PrintMethod | undefined): string | null {
  switch (method) {
    case "IPP_PDF":
      return "PDF 직접 전송";
    case "IPP_PCL":
      return "PCL 변환 전송";
    case "IPP_PWG":
      return "PWG Raster 변환 전송";
    case "IPP_PS":
      return "PostScript 변환 전송";
    case "RAW_HELPER":
      return "PC 도우미 직접 전송";
    case "OS_DRIVER":
      return "이 컴퓨터 드라이버";
    default:
      return null;
  }
}

export function rememberSettings(s: PrintSettings): RememberedSettings {
  return { color: s.color, paper: s.paper, orientation: s.orientation, duplex: s.duplex, quality: s.quality };
}

/** 새 문서를 열 때 그 프린터의 지난 설정을 불러온다. 매수는 항상 지금 값을 쓴다. */
export function applyRemembered(base: PrintSettings, printer: Printer | undefined): PrintSettings {
  if (!printer?.lastSettings) return base;
  return { ...base, ...printer.lastSettings, copies: base.copies };
}
