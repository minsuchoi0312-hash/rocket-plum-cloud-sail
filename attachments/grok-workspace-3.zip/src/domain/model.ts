export type PrinterSource = "MDNS" | "MANUAL" | "LOCAL" | "DEMO";

export type Protocol = "IPP" | "IPPS" | "RAW9100";

export type ColorMode = "AUTO" | "COLOR" | "MONO";

export type PaperSize = "A4" | "A5" | "B5" | "LETTER" | "LEGAL" | "PHOTO_4X6" | "AUTO";

export type Orientation = "PORTRAIT" | "LANDSCAPE";

export type Quality = "FAST" | "NORMAL" | "SHARP";

export type Duplex = "NONE" | "LONG_EDGE" | "SHORT_EDGE";

export type JobErrorCode =
  | "NO_NETWORK"
  | "NO_PERMISSION"
  | "NOT_FOUND"
  | "TIMEOUT"
  | "UNSUPPORTED_FORMAT"
  | "REJECTED"
  | "BUSY"
  | "UNAUTHORIZED"
  | "BAD_ADDRESS"
  | "PAPER_OUT"
  | "PAPER_JAM"
  | "TONER_EMPTY"
  | "COVER_OPEN"
  | "JOB_FAILED";

export type JobResultStatus = "SUCCESS" | "PARTIAL" | "FAILURE";

/** 지난번에 성공한 인쇄 방식. 다음 인쇄 때 시행착오를 줄이는 데 쓴다. */
export type PrintMethod = "IPP_PDF" | "IPP_PCL" | "IPP_PWG" | "IPP_PS" | "RAW_HELPER" | "OS_DRIVER";

/** 앱 변환 엔진이 프린터에 보낼 인쇄 언어. auto는 프린터가 알려준 형식을 보고 고른다. */
export type EngineLanguage = "auto" | "pcl" | "ps" | "pwg";

export interface Printer {
  id: string;
  displayName: string;
  host: string;
  port: number;
  resourcePath: string;
  secure: boolean;
  protocol: Protocol;
  supportsPdf: boolean | null;
  supportsDuplex: boolean | null;
  supportsColor: boolean | null;
  lastSuccessAt: number | null;
  source: PrinterSource;
  makeAndModel?: string;
  mediaSupported?: string[];
  sidesSupported?: string[];
  pdl?: string[];
  experimental?: boolean;
  language?: EngineLanguage;
  lastMethod?: PrintMethod;
  lastSettings?: RememberedSettings;
}

export interface PrintJob {
  id: string;
  printerId: string;
  documentName: string;
  copies: number;
  color: ColorMode;
  paper: PaperSize;
  orientation: Orientation;
  duplex: Duplex;
  pageRange: { start: number; end: number } | null;
  createdAt: number;
}

export interface JobRecord {
  id: string;
  printerId: string;
  printerName: string;
  documentKind: "image" | "pdf" | "test";
  copies: number;
  status: JobResultStatus;
  error?: JobErrorCode;
  at: number;
}

export interface PrintSettings {
  copies: number;
  color: ColorMode;
  paper: PaperSize;
  orientation: Orientation;
  duplex: Duplex;
  quality: Quality;
}

/** 프린터별로 기억하는 설정. 매수(copies)는 매번 달라서 기억하지 않는다. */
export type RememberedSettings = Pick<PrintSettings, "color" | "paper" | "orientation" | "duplex" | "quality">;

export const DEFAULT_SETTINGS: PrintSettings = {
  copies: 1,
  color: "AUTO",
  paper: "AUTO",
  orientation: "PORTRAIT",
  duplex: "NONE",
  quality: "FAST",
};

export const LOCAL_PRINTER_ID = "local-device";
export const DEMO_IPP_ID = "demo-ipp-everywhere";
export const DEMO_LEGACY_ID = "demo-pcl-legacy";

export function isPdfDirectSupported(printer: Printer): boolean {
  if (printer.supportsPdf === false) return false;
  if (printer.pdl && printer.pdl.length > 0) {
    const hasPdf = printer.pdl.some((p) => p.toLowerCase().includes("pdf"));
    const rasterOnly = printer.pdl.every(
      (p) =>
        p.toLowerCase().includes("pwg-raster") ||
        p.toLowerCase().includes("pclm") ||
        p.toLowerCase().includes("pcl") ||
        p.toLowerCase().includes("postscript"),
    );
    if (!hasPdf && rasterOnly) return false;
  }
  return true;
}

export function usesInAppEngine(printer: Printer): boolean {
  if (printer.protocol === "RAW9100") return true;
  // 사용자가 인쇄 언어를 직접 골랐으면 앱 변환 엔진을 쓴다.
  if (printer.language && printer.language !== "auto") return true;
  // 지난번에 앱 변환으로 성공했다면 PDF 직접 전송을 다시 시도하지 않는다.
  if (printer.lastMethod === "IPP_PCL" || printer.lastMethod === "IPP_PWG" || printer.lastMethod === "IPP_PS") return true;
  return !isPdfDirectSupported(printer);
}

/** Duplex is always user-controlled. Unknown or old printers still get the command. */
export function canUseDuplex(_printer: Printer | undefined): boolean {
  return true;
}

export function canUseColor(printer: Printer | undefined): boolean {
  if (!printer) return true;
  return printer.supportsColor !== false;
}

export function dpiForQuality(quality: Quality | undefined): number {
  // PCL 래스터가 받는 해상도(75/100/150/200/300/600)만 쓴다. 80·130 같은 값은 프린터가 무시한다.
  if (quality === "SHARP") return 150;
  if (quality === "NORMAL") return 100;
  return 75;
}
