import type { JobErrorCode } from "./model";

export const JOB_ERROR_MESSAGE: Record<JobErrorCode, string> = {
  NO_NETWORK: "휴대폰이 Wi-Fi에 연결되어 있지 않습니다.",
  NO_PERMISSION: "근처 프린터를 찾으려면 로컬 네트워크 권한이 필요합니다.",
  NOT_FOUND: "같은 네트워크에서 IPP 프린터를 찾지 못했습니다.",
  TIMEOUT: "브라우저가 프린터 응답을 읽지 못했습니다. 인쇄 창으로 넘겼습니다. 창에서 같은 프린터를 고르세요.",
  UNSUPPORTED_FORMAT:
    "이 프린터는 받은 형식을 거절했습니다. 앱 변환 엔진이 다른 방식으로 다시 보냅니다.",
  REJECTED: "프린터가 작업을 거절했습니다. 용지/잉크/커버를 확인하세요.",
  BUSY: "프린터가 다른 작업 중입니다.",
  UNAUTHORIZED: "이 프린터는 로그인이 필요합니다. MVP에서는 미지원입니다.",
  BAD_ADDRESS: "IP 또는 포트가 올바르지 않습니다.",
  PAPER_OUT: "프린터에 용지가 없습니다.",
  PAPER_JAM: "프린터 안에 용지가 걸렸습니다.",
  TONER_EMPTY: "프린터의 토너 또는 잉크가 떨어졌습니다.",
  COVER_OPEN: "프린터 덮개나 문이 열려 있습니다.",
  JOB_FAILED: "프린터가 작업을 끝내지 못했습니다.",
};

/** 작업은 프린터에 도착했지만 프린터 쪽 문제로 멈춘 경우. */
export const PRINTER_PROBLEM_CODES: JobErrorCode[] = ["PAPER_OUT", "PAPER_JAM", "TONER_EMPTY", "COVER_OPEN", "JOB_FAILED"];

export const JOB_ERROR_HINT: Record<JobErrorCode, string> = {
  NO_NETWORK: "Wi-Fi를 켠 뒤 같은 네트워크에서 다시 검색해 보세요.",
  NO_PERMISSION: "설정에서 로컬 네트워크 접근을 허용하면 근처 프린터를 찾을 수 있습니다.",
  NOT_FOUND:
    "프린터가 켜져 있고 같은 Wi-Fi인지 확인하거나, IP를 알고 있으면 수동으로 추가하세요.",
  TIMEOUT: "이 화면은 PrinterShare처럼 프린터 포트를 직접 열 수 없습니다. 인쇄 창이 없으면 결과 화면에서 다시 여세요.",
  UNSUPPORTED_FORMAT:
    "앱 안에서 PCL/PWG로 바꿔 보내거나, 이 컴퓨터에 깔린 드라이버로 넘깁니다. 추가 프로그램은 필요 없습니다.",
  REJECTED: "용지함, 잉크, 덮개를 확인한 다음 테스트 페이지부터 다시 보내 보세요.",
  BUSY: "현재 작업이 끝난 뒤 다시 인쇄하세요.",
  UNAUTHORIZED: "로그인 필요한 프린터는 아직 지원하지 않습니다. 이 컴퓨터로 인쇄해 보세요.",
  BAD_ADDRESS: "IPv4 주소와 포트(IPP 기본 631)를 다시 입력하세요.",
  PAPER_OUT: "용지를 넣으면 보낸 작업이 이어서 인쇄될 수 있습니다. 인쇄되지 않으면 다시 보내세요.",
  PAPER_JAM: "걸린 용지를 빼면 이어서 인쇄될 수 있습니다. 인쇄되지 않으면 다시 보내세요.",
  TONER_EMPTY: "토너나 잉크를 바꾼 뒤 인쇄되지 않으면 다시 보내세요.",
  COVER_OPEN: "덮개를 닫으면 이어서 인쇄될 수 있습니다. 인쇄되지 않으면 다시 보내세요.",
  JOB_FAILED: "프린터 화면의 오류를 확인한 뒤 테스트 페이지부터 다시 보내 보세요.",
};

export function messageFor(code: JobErrorCode): string {
  return JOB_ERROR_MESSAGE[code];
}

export type IppStatusMapInput = {
  kind: "ipp-status" | "network";
  status?: number;
  network?: "timeout" | "refused" | "abort" | "cors" | "offline" | "bad-url";
};

export function mapFailure(input: IppStatusMapInput): JobErrorCode {
  if (input.kind === "network") {
    switch (input.network) {
      case "offline":
        return "NO_NETWORK";
      case "bad-url":
        return "BAD_ADDRESS";
      case "timeout":
      case "abort":
        return "TIMEOUT";
      case "refused":
        return "BAD_ADDRESS";
      case "cors":
        return "TIMEOUT";
      default:
        return "TIMEOUT";
    }
  }
  const s = input.status ?? -1;
  if (s === 0x040a) return "UNSUPPORTED_FORMAT";
  if (s === 0x0401 || s === 0x0402 || s === 0x0403) return "UNAUTHORIZED";
  if (s === 0x0507) return "BUSY";
  if (s === 0x0400 || s === 0x0405) return "REJECTED";
  if (s >= 0x0400 && s < 0x0500) return "REJECTED";
  if (s >= 0x0500) return "REJECTED";
  return "REJECTED";
}
