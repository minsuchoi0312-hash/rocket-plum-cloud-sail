//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DLxwe1vv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CZbIsAQD.js", "/assets/rolldown-runtime-hePW80VL.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CZbIsAQD.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-2sB7Zq6s.js"]
	}
} });
//#endregion
export { tsrStartManifest };
