import { t as PDFDocument } from "../_libs/pdf-lib.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/test-page-Dnk1WEz9.js
function blobToBytes(blob) {
	return blob.arrayBuffer().then((buf) => new Uint8Array(buf));
}
async function renderTestPageJpeg(printer, device, when, opts) {
	const scale = opts?.scale ?? 1;
	const w = Math.round(794 * scale);
	const h = Math.round(1123 * scale);
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d", { alpha: false });
	if (!ctx) throw new Error("canvas");
	try {
		await document.fonts.load(`${Math.round(28 * scale)}px "IBM Plex Sans KR"`);
	} catch {}
	ctx.fillStyle = "#fbf8f2";
	ctx.fillRect(0, 0, w, h);
	ctx.fillStyle = "#c2410c";
	ctx.fillRect(0, 0, w, Math.round(18 * scale));
	const mark = (x, y) => {
		ctx.strokeStyle = "#1c1914";
		ctx.lineWidth = Math.max(1, scale);
		ctx.beginPath();
		ctx.moveTo(x - 18 * scale, y);
		ctx.lineTo(x + 18 * scale, y);
		ctx.moveTo(x, y - 18 * scale);
		ctx.lineTo(x, y + 18 * scale);
		ctx.stroke();
	};
	const inset = 36 * scale;
	mark(inset, inset + 10 * scale);
	mark(w - inset, inset + 10 * scale);
	mark(inset, h - inset);
	mark(w - inset, h - inset);
	ctx.fillStyle = "#1c1914";
	ctx.font = `600 ${Math.round(42 * scale)}px "Fraunces", "IBM Plex Sans KR", serif`;
	ctx.fillText("누구나프린트", 48 * scale, 110 * scale);
	ctx.font = `500 ${Math.round(22 * scale)}px "IBM Plex Sans KR", sans-serif`;
	ctx.fillStyle = "#5e574c";
	ctx.fillText("연결 테스트 1장", 48 * scale, 148 * scale);
	const lines = [
		printer.displayName,
		printer.source === "LOCAL" ? "이 기기의 인쇄 대화상자" : `${printer.host}:${printer.port} · ${printer.protocol}`,
		when.toLocaleString("ko-KR"),
		device
	];
	ctx.fillStyle = "#1c1914";
	ctx.font = `400 ${Math.round(18 * scale)}px "IBM Plex Sans KR", sans-serif`;
	lines.forEach((line, i) => {
		ctx.fillText(line, 48 * scale, (210 + i * 32) * scale);
	});
	[
		"#1c1914",
		"#c2410c",
		"#b42318",
		"#1d4e89",
		"#2f6b4f",
		"#e7c84a"
	].forEach((color, i) => {
		ctx.fillStyle = color;
		ctx.fillRect((48 + i * 112) * scale, 360 * scale, 96 * scale, 72 * scale);
	});
	for (let i = 0; i < 10; i++) {
		const g = Math.round(i / 9 * 255);
		ctx.fillStyle = `rgb(${g} ${g} ${g})`;
		ctx.fillRect((48 + i * 68) * scale, 460 * scale, 68 * scale, 36 * scale);
	}
	ctx.fillStyle = "#1c1914";
	ctx.font = `500 ${Math.round(20 * scale)}px "IBM Plex Sans KR", sans-serif`;
	[
		"한글이 네모가 아니라 글자로 보이면 변환이 된 것입니다.",
		"가나다라마바사 아자차카타파하",
		"The quick brown fox jumps over the lazy dog.",
		"0123456789  ·  양면 · 용지 · 컬러"
	].forEach((line, i) => ctx.fillText(line, 48 * scale, (560 + i * 40) * scale));
	ctx.strokeStyle = "#ddd4c4";
	ctx.strokeRect(48 * scale, 760 * scale, w - 96 * scale, 220 * scale);
	ctx.font = `400 ${Math.round(16 * scale)}px "IBM Plex Sans KR", sans-serif`;
	ctx.fillStyle = "#5e574c";
	ctx.fillText("이 칸이 잘리지 않으면 용지 크기가 맞습니다.", 68 * scale, 860 * scale);
	return blobToBytes(await new Promise((resolve, reject) => {
		canvas.toBlob((b) => b ? resolve(b) : reject(/* @__PURE__ */ new Error("jpeg")), "image/jpeg", opts?.quality ?? .86);
	}));
}
async function buildTestPagePdf(printer) {
	const jpeg = await renderTestPageJpeg(printer, "web", /* @__PURE__ */ new Date(), {
		scale: 1.15,
		quality: .85
	});
	const doc = await PDFDocument.create();
	const image = await doc.embedJpg(jpeg);
	doc.addPage([595.28, 841.89]).drawImage(image, {
		x: 0,
		y: 0,
		width: 595.28,
		height: 841.89
	});
	return doc.save();
}
//#endregion
export { buildTestPagePdf, renderTestPageJpeg };
