import { i as __toESM } from "../_runtime.mjs";
import { G as require_jsx_runtime, K as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ChevronLeft, a as Settings, c as Plus, d as Image, f as FileText, g as ChevronRight, h as CircleAlert, i as Sheet, l as Minus, m as Copy, o as RefreshCw, p as Download, r as Trash2, s as Printer, t as WifiOff, u as LoaderCircle, v as Check } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-B5kXr77f.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
/** Points (1/72 in). B5 is JIS — PCL paper code 45 and most Korean office printers. */
var SPECS = {
	A4: {
		width: 595.28,
		height: 841.89,
		mediaKeyword: "iso_a4_210x297mm"
	},
	A5: {
		width: 419.53,
		height: 595.28,
		mediaKeyword: "iso_a5_148x210mm"
	},
	B5: {
		width: 515.91,
		height: 728.5,
		mediaKeyword: "jis_b5_182x257mm"
	},
	LETTER: {
		width: 612,
		height: 792,
		mediaKeyword: "na_letter_8.5x11in"
	},
	LEGAL: {
		width: 612,
		height: 1008,
		mediaKeyword: "na_legal_8.5x14in"
	},
	PHOTO_4X6: {
		width: 288,
		height: 432,
		mediaKeyword: "na_index-4x6_4x6in"
	}
};
var PAPER_OPTIONS = [
	{
		id: "AUTO",
		label: "자동"
	},
	{
		id: "A4",
		label: "A4"
	},
	{
		id: "A5",
		label: "A5"
	},
	{
		id: "B5",
		label: "B5"
	},
	{
		id: "LETTER",
		label: "레터"
	},
	{
		id: "LEGAL",
		label: "리걸"
	},
	{
		id: "PHOTO_4X6",
		label: "4×6"
	}
];
function resolvePaper(paper) {
	if (paper === "AUTO") return "A4";
	return paper;
}
function pageSizePoints(paper, orientation) {
	const spec = SPECS[resolvePaper(paper)];
	const landscape = orientation === "LANDSCAPE";
	return {
		width: landscape ? spec.height : spec.width,
		height: landscape ? spec.width : spec.height,
		mediaKeyword: spec.mediaKeyword
	};
}
var DEFAULT_SETTINGS = {
	copies: 1,
	color: "AUTO",
	paper: "AUTO",
	orientation: "PORTRAIT",
	duplex: "NONE",
	quality: "FAST"
};
var LOCAL_PRINTER_ID = "local-device";
var DEMO_IPP_ID = "demo-ipp-everywhere";
var DEMO_LEGACY_ID = "demo-pcl-legacy";
function isPdfDirectSupported(printer) {
	if (printer.supportsPdf === false) return false;
	if (printer.pdl && printer.pdl.length > 0) {
		const hasPdf = printer.pdl.some((p) => p.toLowerCase().includes("pdf"));
		const rasterOnly = printer.pdl.every((p) => p.toLowerCase().includes("pwg-raster") || p.toLowerCase().includes("pclm") || p.toLowerCase().includes("pcl") || p.toLowerCase().includes("postscript"));
		if (!hasPdf && rasterOnly) return false;
	}
	return true;
}
function usesInAppEngine(printer) {
	if (printer.protocol === "RAW9100") return true;
	if (printer.language && printer.language !== "auto") return true;
	if (printer.lastMethod === "IPP_PCL" || printer.lastMethod === "IPP_PWG" || printer.lastMethod === "IPP_PS") return true;
	return !isPdfDirectSupported(printer);
}
/** Duplex is always user-controlled. Unknown or old printers still get the command. */
function canUseDuplex(_printer) {
	return true;
}
function canUseColor(printer) {
	if (!printer) return true;
	return printer.supportsColor !== false;
}
function dpiForQuality(quality) {
	if (quality === "SHARP") return 150;
	if (quality === "NORMAL") return 100;
	return 75;
}
var JOB_ERROR_MESSAGE = {
	NO_NETWORK: "휴대폰이 Wi-Fi에 연결되어 있지 않습니다.",
	NO_PERMISSION: "근처 프린터를 찾으려면 로컬 네트워크 권한이 필요합니다.",
	NOT_FOUND: "같은 네트워크에서 IPP 프린터를 찾지 못했습니다.",
	TIMEOUT: "프린터가 응답하지 않습니다. 앱이 절전 깨우기를 보냈으니 몇 초 뒤 다시 보내 보세요.",
	UNSUPPORTED_FORMAT: "이 프린터는 받은 형식을 거절했습니다. 앱 변환 엔진이 다른 방식으로 다시 보냅니다.",
	REJECTED: "프린터가 작업을 거절했습니다. 용지/잉크/커버를 확인하세요.",
	BUSY: "프린터가 다른 작업 중입니다.",
	UNAUTHORIZED: "이 프린터는 로그인이 필요합니다. MVP에서는 미지원입니다.",
	BAD_ADDRESS: "IP 또는 포트가 올바르지 않습니다.",
	PAPER_OUT: "프린터에 용지가 없습니다.",
	PAPER_JAM: "프린터 안에 용지가 걸렸습니다.",
	TONER_EMPTY: "프린터의 토너 또는 잉크가 떨어졌습니다.",
	COVER_OPEN: "프린터 덮개나 문이 열려 있습니다.",
	JOB_FAILED: "프린터가 작업을 끝내지 못했습니다."
};
/** 작업은 프린터에 도착했지만 프린터 쪽 문제로 멈춘 경우. */
var PRINTER_PROBLEM_CODES = [
	"PAPER_OUT",
	"PAPER_JAM",
	"TONER_EMPTY",
	"COVER_OPEN",
	"JOB_FAILED"
];
var JOB_ERROR_HINT = {
	NO_NETWORK: "Wi-Fi를 켠 뒤 같은 네트워크에서 다시 검색해 보세요.",
	NO_PERMISSION: "설정에서 로컬 네트워크 접근을 허용하면 근처 프린터를 찾을 수 있습니다.",
	NOT_FOUND: "프린터가 켜져 있고 같은 Wi-Fi인지 확인하거나, IP를 알고 있으면 수동으로 추가하세요.",
	TIMEOUT: "깨우기 신호를 다시 보낸 뒤 테스트 페이지부터 보내 보세요. IP가 바뀌었으면 검색을 다시 하세요.",
	UNSUPPORTED_FORMAT: "앱 안에서 PCL/PWG로 바꿔 보내거나, 이 컴퓨터에 깔린 드라이버로 넘깁니다. 추가 프로그램은 필요 없습니다.",
	REJECTED: "용지함, 잉크, 덮개를 확인한 다음 테스트 페이지부터 다시 보내 보세요.",
	BUSY: "현재 작업이 끝난 뒤 다시 인쇄하세요.",
	UNAUTHORIZED: "로그인 필요한 프린터는 아직 지원하지 않습니다. 이 컴퓨터로 인쇄해 보세요.",
	BAD_ADDRESS: "IPv4 주소와 포트(IPP 기본 631)를 다시 입력하세요.",
	PAPER_OUT: "용지를 넣으면 보낸 작업이 이어서 인쇄될 수 있습니다. 인쇄되지 않으면 다시 보내세요.",
	PAPER_JAM: "걸린 용지를 빼면 이어서 인쇄될 수 있습니다. 인쇄되지 않으면 다시 보내세요.",
	TONER_EMPTY: "토너나 잉크를 바꾼 뒤 인쇄되지 않으면 다시 보내세요.",
	COVER_OPEN: "덮개를 닫으면 이어서 인쇄될 수 있습니다. 인쇄되지 않으면 다시 보내세요.",
	JOB_FAILED: "프린터 화면의 오류를 확인한 뒤 테스트 페이지부터 다시 보내 보세요."
};
function mapFailure(input) {
	if (input.kind === "network") switch (input.network) {
		case "offline": return "NO_NETWORK";
		case "bad-url": return "BAD_ADDRESS";
		case "timeout":
		case "abort": return "TIMEOUT";
		case "refused": return "BAD_ADDRESS";
		case "cors": return "TIMEOUT";
		default: return "TIMEOUT";
	}
	const s = input.status ?? -1;
	if (s === 1034) return "UNSUPPORTED_FORMAT";
	if (s === 1025 || s === 1026 || s === 1027) return "UNAUTHORIZED";
	if (s === 1287) return "BUSY";
	if (s === 1024 || s === 1029) return "REJECTED";
	if (s >= 1024 && s < 1280) return "REJECTED";
	if (s >= 1280) return "REJECTED";
	return "REJECTED";
}
var Tag = {
	OperationAttributes: 1,
	JobAttributes: 2,
	EndOfAttributes: 3,
	PrinterAttributes: 4,
	UnsupportedAttributes: 5,
	Integer: 33,
	Boolean: 34,
	Enum: 35,
	TextWithoutLanguage: 65,
	NameWithoutLanguage: 66,
	Keyword: 68,
	Uri: 69,
	Charset: 71,
	NaturalLanguage: 72,
	MimeMediaType: 73
};
var Operation = {
	PrintJob: 2,
	GetJobAttributes: 9,
	GetPrinterAttributes: 11
};
var StatusCode = {
	SuccessfulOk: 0,
	SuccessfulOkIgnoredOrSubstituted: 1
};
var Buf = class {
	parts = [];
	u8(n) {
		this.parts.push(Uint8Array.of(n & 255));
	}
	u16(n) {
		this.parts.push(Uint8Array.of(n >>> 8 & 255, n & 255));
	}
	u32(n) {
		this.parts.push(Uint8Array.of(n >>> 24 & 255, n >>> 16 & 255, n >>> 8 & 255, n & 255));
	}
	raw(bytes) {
		this.parts.push(bytes);
	}
	concat() {
		const total = this.parts.reduce((n, p) => n + p.length, 0);
		const out = new Uint8Array(total);
		let o = 0;
		for (const p of this.parts) {
			out.set(p, o);
			o += p.length;
		}
		return out;
	}
};
function encodeString(s) {
	return new TextEncoder().encode(s);
}
function writeValue(buf, value) {
	switch (value.type) {
		case "integer":
		case "enum":
			buf.u8(value.type === "enum" ? Tag.Enum : Tag.Integer);
			return (nameWriter) => {
				nameWriter();
				buf.u16(4);
				buf.u32(value.value);
			};
		case "boolean":
			buf.u8(Tag.Boolean);
			return (nameWriter) => {
				nameWriter();
				buf.u16(1);
				buf.u8(value.value ? 1 : 0);
			};
		case "charset":
		case "naturalLanguage":
		case "uri":
		case "keyword":
		case "name":
		case "text":
		case "mime": {
			const tag = value.type === "charset" ? Tag.Charset : value.type === "naturalLanguage" ? Tag.NaturalLanguage : value.type === "uri" ? Tag.Uri : value.type === "keyword" ? Tag.Keyword : value.type === "name" ? Tag.NameWithoutLanguage : value.type === "mime" ? Tag.MimeMediaType : Tag.TextWithoutLanguage;
			const bytes = encodeString(value.value);
			buf.u8(tag);
			return (nameWriter) => {
				nameWriter();
				buf.u16(bytes.length);
				buf.raw(bytes);
			};
		}
		default:
			buf.u8(value.tag);
			return (nameWriter) => {
				nameWriter();
				buf.u16(value.value.length);
				buf.raw(value.value);
			};
	}
}
function writeAttribute(buf, attr) {
	attr.values.forEach((value, i) => {
		writeValue(buf, value)(() => {
			if (i === 0) {
				const name = encodeString(attr.name);
				buf.u16(name.length);
				buf.raw(name);
			} else buf.u16(0);
		});
	});
}
function encodeIpp(message) {
	const buf = new Buf();
	buf.u8(message.versionMajor);
	buf.u8(message.versionMinor);
	buf.u16(message.code);
	buf.u32(message.requestId);
	for (const group of message.groups) {
		buf.u8(group.tag);
		for (const attr of group.attributes) writeAttribute(buf, attr);
	}
	buf.u8(Tag.EndOfAttributes);
	const header = buf.concat();
	const doc = message.document;
	if (!doc || doc.length === 0) return header;
	const out = new Uint8Array(header.length + doc.length);
	out.set(header, 0);
	out.set(doc, header.length);
	return out;
}
var Reader = class {
	buf;
	offset;
	constructor(buf, offset = 0) {
		this.buf = buf;
		this.offset = offset;
	}
	remaining() {
		return this.buf.length - this.offset;
	}
	u8() {
		return this.buf[this.offset++];
	}
	u16() {
		const v = this.buf[this.offset] << 8 | this.buf[this.offset + 1];
		this.offset += 2;
		return v;
	}
	u32() {
		const v = (this.buf[this.offset] << 24 | this.buf[this.offset + 1] << 16 | this.buf[this.offset + 2] << 8 | this.buf[this.offset + 3]) >>> 0;
		this.offset += 4;
		return v;
	}
	bytes(n) {
		const slice = this.buf.subarray(this.offset, this.offset + n);
		this.offset += n;
		return slice;
	}
	ascii(n) {
		return new TextDecoder("utf-8").decode(this.bytes(n));
	}
};
function parseValue(tag, data) {
	if (tag === Tag.Integer || tag === Tag.Enum) {
		const v = data.length >= 4 ? (data[0] << 24 | data[1] << 16 | data[2] << 8 | data[3]) >> 0 : 0;
		return {
			type: tag === Tag.Enum ? "enum" : "integer",
			value: v
		};
	}
	if (tag === Tag.Boolean) return {
		type: "boolean",
		value: data[0] === 1
	};
	const text = new TextDecoder("utf-8").decode(data);
	if (tag === Tag.Charset) return {
		type: "charset",
		value: text
	};
	if (tag === Tag.NaturalLanguage) return {
		type: "naturalLanguage",
		value: text
	};
	if (tag === Tag.Uri) return {
		type: "uri",
		value: text
	};
	if (tag === Tag.Keyword) return {
		type: "keyword",
		value: text
	};
	if (tag === Tag.NameWithoutLanguage) return {
		type: "name",
		value: text
	};
	if (tag === Tag.TextWithoutLanguage) return {
		type: "text",
		value: text
	};
	if (tag === Tag.MimeMediaType) return {
		type: "mime",
		value: text
	};
	return {
		type: "unknown",
		tag,
		value: data
	};
}
function decodeIpp(bytes) {
	if (bytes.length < 8) throw new Error("IPP message too short");
	const r = new Reader(bytes);
	const versionMajor = r.u8();
	const versionMinor = r.u8();
	const code = r.u16();
	const requestId = r.u32();
	const groups = [];
	let current = null;
	while (r.remaining() > 0) {
		const tag = r.u8();
		if (tag === Tag.EndOfAttributes) break;
		if (tag < 16) {
			current = {
				tag,
				attributes: []
			};
			groups.push(current);
			continue;
		}
		if (!current) {
			current = {
				tag: Tag.OperationAttributes,
				attributes: []
			};
			groups.push(current);
		}
		const nameLen = r.u16();
		const name = nameLen > 0 ? r.ascii(nameLen) : "";
		const valueLen = r.u16();
		const value = parseValue(tag, r.bytes(valueLen));
		if (nameLen === 0 && current.attributes.length > 0) current.attributes[current.attributes.length - 1].values.push(value);
		else current.attributes.push({
			name,
			values: [value]
		});
	}
	return {
		versionMajor,
		versionMinor,
		code,
		requestId,
		groups,
		document: r.remaining() > 0 ? bytes.subarray(r.offset) : null
	};
}
function attr(name, ...values) {
	return {
		name,
		values
	};
}
function buildGetPrinterAttributes(printerUri, requestId) {
	return encodeIpp({
		versionMajor: 1,
		versionMinor: 1,
		code: Operation.GetPrinterAttributes,
		requestId,
		groups: [{
			tag: Tag.OperationAttributes,
			attributes: [
				attr("attributes-charset", {
					type: "charset",
					value: "utf-8"
				}),
				attr("attributes-natural-language", {
					type: "naturalLanguage",
					value: "ko"
				}),
				attr("printer-uri", {
					type: "uri",
					value: printerUri
				}),
				attr("requested-attributes", ...[
					"printer-name",
					"printer-make-and-model",
					"document-format-supported",
					"media-supported",
					"sides-supported",
					"color-supported",
					"printer-state",
					"printer-state-reasons"
				].map((k) => ({
					type: "keyword",
					value: k
				})))
			]
		}]
	});
}
function buildGetJobAttributes(printerUri, jobId, requestId) {
	return encodeIpp({
		versionMajor: 1,
		versionMinor: 1,
		code: Operation.GetJobAttributes,
		requestId,
		groups: [{
			tag: Tag.OperationAttributes,
			attributes: [
				attr("attributes-charset", {
					type: "charset",
					value: "utf-8"
				}),
				attr("attributes-natural-language", {
					type: "naturalLanguage",
					value: "ko"
				}),
				attr("printer-uri", {
					type: "uri",
					value: printerUri
				}),
				attr("job-id", {
					type: "integer",
					value: jobId
				}),
				attr("requested-attributes", ...[
					"job-state",
					"job-state-reasons",
					"job-impressions-completed"
				].map((k) => ({
					type: "keyword",
					value: k
				})))
			]
		}]
	});
}
function buildPrintJob(req) {
	const opAttrs = [
		attr("attributes-charset", {
			type: "charset",
			value: "utf-8"
		}),
		attr("attributes-natural-language", {
			type: "naturalLanguage",
			value: "ko"
		}),
		attr("printer-uri", {
			type: "uri",
			value: req.printerUri
		}),
		attr("requesting-user-name", {
			type: "name",
			value: req.userName
		}),
		attr("job-name", {
			type: "name",
			value: req.jobName
		}),
		attr("document-format", {
			type: "mime",
			value: req.documentFormat
		})
	];
	const jobAttrs = [attr("copies", {
		type: "integer",
		value: req.copies
	})];
	if (req.sides) jobAttrs.push(attr("sides", {
		type: "keyword",
		value: req.sides
	}));
	if (req.colorMode && req.colorMode !== "auto") jobAttrs.push(attr("print-color-mode", {
		type: "keyword",
		value: req.colorMode
	}));
	if (req.media) jobAttrs.push(attr("media", {
		type: "keyword",
		value: req.media
	}));
	return encodeIpp({
		versionMajor: 1,
		versionMinor: 1,
		code: Operation.PrintJob,
		requestId: req.requestId,
		groups: [{
			tag: Tag.OperationAttributes,
			attributes: opAttrs
		}, {
			tag: Tag.JobAttributes,
			attributes: jobAttrs
		}],
		document: req.document
	});
}
function printerUri(host, port, path, secure) {
	return `${secure ? "ipps" : "ipp"}://${host}:${port}${path.startsWith("/") ? path : `/${path}`}`;
}
function findAttr(message, name) {
	for (const g of message.groups) {
		const hit = g.attributes.find((a) => a.name === name);
		if (hit) return hit;
	}
}
function stringValues(attr) {
	if (!attr) return [];
	return attr.values.map((v) => "value" in v && typeof v.value === "string" ? v.value : null).filter((v) => Boolean(v));
}
function boolValue(attr) {
	const v = attr?.values[0];
	if (v && v.type === "boolean") return v.value;
}
function intValue(attr) {
	const v = attr?.values[0];
	if (v && (v.type === "integer" || v.type === "enum")) return v.value;
}
var JobError = class extends Error {
	code;
	constructor(code, message) {
		super(message);
		this.code = code;
		this.name = "JobError";
	}
};
function fail(input) {
	const code = mapFailure(input);
	throw new JobError(code, code);
}
function httpUrlFor(printer) {
	const scheme = printer.secure || printer.protocol === "IPPS" ? "https" : "http";
	const path = printer.resourcePath.startsWith("/") ? printer.resourcePath : `/${printer.resourcePath}`;
	return `${scheme}://${printer.host}:${printer.port}${path}`;
}
var ATTRIBUTES_TIMEOUT_MS = 8e3;
var PRINT_TIMEOUT_MS = 2e4;
async function postIpp(printer, body, timeoutMs, signal) {
	if (typeof navigator !== "undefined" && navigator.onLine === false) fail({
		kind: "network",
		network: "offline"
	});
	const controller = new AbortController();
	const timer = setTimeout(() => controller.abort(), timeoutMs);
	const onOuter = () => controller.abort();
	signal?.addEventListener("abort", onOuter);
	try {
		const res = await fetch(httpUrlFor(printer), {
			method: "POST",
			headers: { "Content-Type": "application/ipp" },
			body: body.slice(),
			signal: controller.signal
		});
		const buf = new Uint8Array(await res.arrayBuffer());
		if (!res.ok && buf.length < 8) {
			if (res.status === 401 || res.status === 403) fail({
				kind: "ipp-status",
				status: 1026
			});
			fail({
				kind: "network",
				network: "refused"
			});
		}
		return buf;
	} catch (err) {
		if (err instanceof JobError) throw err;
		const name = err instanceof Error ? err.name : "";
		const message = err instanceof Error ? err.message : String(err);
		if (name === "AbortError") fail({
			kind: "network",
			network: "timeout"
		});
		if (/Failed to fetch|NetworkError|CORS|Load failed/i.test(message)) fail({
			kind: "network",
			network: "cors"
		});
		fail({
			kind: "network",
			network: "timeout"
		});
	} finally {
		clearTimeout(timer);
		signal?.removeEventListener("abort", onOuter);
	}
	return /* @__PURE__ */ new Uint8Array();
}
function applyAttributes(printer, attrs) {
	const formats = attrs.formats.map((f) => f.toLowerCase());
	const supportsPdf = formats.some((f) => f.includes("pdf"));
	return {
		...printer,
		displayName: attrs.name || printer.displayName,
		makeAndModel: attrs.makeAndModel || printer.makeAndModel,
		pdl: attrs.formats.length ? attrs.formats : printer.pdl,
		mediaSupported: attrs.media,
		sidesSupported: attrs.sides,
		supportsColor: attrs.color ?? printer.supportsColor,
		supportsDuplex: attrs.sides.some((s) => s.includes("two-sided")) || printer.supportsDuplex,
		supportsPdf: formats.length ? supportsPdf : printer.supportsPdf
	};
}
async function getPrinterAttributes(printer, signal) {
	const msg = decodeIpp(await postIpp(printer, buildGetPrinterAttributes(printerUri(printer.host, printer.port, printer.resourcePath, printer.secure), 1), ATTRIBUTES_TIMEOUT_MS, signal));
	if (msg.code >= 1024) fail({
		kind: "ipp-status",
		status: msg.code
	});
	return {
		name: stringValues(findAttr(msg, "printer-name"))[0],
		makeAndModel: stringValues(findAttr(msg, "printer-make-and-model"))[0],
		formats: stringValues(findAttr(msg, "document-format-supported")),
		media: stringValues(findAttr(msg, "media-supported")),
		sides: stringValues(findAttr(msg, "sides-supported")),
		color: boolValue(findAttr(msg, "color-supported")),
		state: (() => {
			const v = findAttr(msg, "printer-state")?.values[0];
			return v && v.type === "enum" ? v.value : void 0;
		})(),
		reasons: stringValues(findAttr(msg, "printer-state-reasons"))
	};
}
async function printJob(printer, document, options) {
	const body = buildPrintJob({
		printerUri: printerUri(printer.host, printer.port, printer.resourcePath, printer.secure),
		requestId: 2,
		jobName: options.jobName,
		userName: options.userName,
		copies: options.copies,
		documentFormat: options.documentFormat ?? "application/pdf",
		colorMode: options.colorMode,
		sides: options.sides,
		media: options.media,
		document
	});
	const msg = decodeIpp(await postIpp(printer, body, PRINT_TIMEOUT_MS, options.signal));
	if (msg.code >= 1024) fail({
		kind: "ipp-status",
		status: msg.code
	});
	if (msg.code > StatusCode.SuccessfulOkIgnoredOrSubstituted) fail({
		kind: "ipp-status",
		status: msg.code
	});
	return {
		status: msg.code,
		byteLength: body.byteLength,
		jobId: intValue(findAttr(msg, "job-id"))
	};
}
/** Get-Job-Attributes + 프린터 상태 이유. 프린터 상태를 못 읽어도 작업 상태만으로 계속한다. */
async function getJobSnapshot(printer, jobId, signal) {
	const msg = decodeIpp(await postIpp(printer, buildGetJobAttributes(printerUri(printer.host, printer.port, printer.resourcePath, printer.secure), jobId, 3), ATTRIBUTES_TIMEOUT_MS, signal));
	if (msg.code >= 1024) fail({
		kind: "ipp-status",
		status: msg.code
	});
	const printerReasons = await getPrinterAttributes(printer, signal).then((a) => a.reasons).catch(() => []);
	return {
		state: intValue(findAttr(msg, "job-state")),
		jobReasons: stringValues(findAttr(msg, "job-state-reasons")),
		printerReasons
	};
}
/**
* Optional PC helper (public/raw-print-helper.mjs). A browser cannot open raw TCP,
* so the helper does it on 127.0.0.1. Every call fails quietly when it is not running
* or when the 6-digit code has not been entered.
*/
var HELPER_BASE = "http://127.0.0.1:47631";
var CODE_KEY = "nuguna.helperCode";
var alive = null;
function getHelperCode() {
	try {
		return globalThis.localStorage?.getItem(CODE_KEY) ?? "";
	} catch {
		return "";
	}
}
function setHelperCode(code) {
	try {
		globalThis.localStorage?.setItem(CODE_KEY, code.trim());
	} catch {}
}
async function call(path, init, ms, signal) {
	const ac = new AbortController();
	const timer = setTimeout(() => ac.abort(), ms);
	const onOuter = () => ac.abort();
	signal?.addEventListener("abort", onOuter);
	const code = getHelperCode();
	try {
		return await fetch(`${HELPER_BASE}${path}`, {
			...init,
			headers: {
				...init?.headers,
				...code ? { "X-Helper-Code": code } : {}
			},
			cache: "no-store",
			signal: ac.signal
		});
	} catch {
		return null;
	} finally {
		clearTimeout(timer);
		signal?.removeEventListener("abort", onOuter);
	}
}
/** 도우미가 켜져 있고(응답함) 연결 코드도 맞아야 true. */
function helperAlive(force = false) {
	if (!force && alive && Date.now() - alive.at < 5e3) return alive.promise;
	const promise = call("/check", void 0, 500).then((r) => Boolean(r?.ok));
	alive = {
		at: Date.now(),
		promise
	};
	return promise;
}
async function helperState() {
	if (!(await call("/ping", void 0, 500))?.ok) return "off";
	return (await call("/check", void 0, 500))?.ok ? "ready" : "needs-code";
}
function target(host, port) {
	return `host=${encodeURIComponent(host)}&port=${port}`;
}
async function helperProbe(host, port = 9100, signal) {
	if (!await helperAlive()) return false;
	const r = await call(`/probe?${target(host, port)}`, void 0, 900, signal);
	if (!r?.ok) return false;
	return Boolean((await r.json().catch(() => null))?.open);
}
async function helperWake(host, port = 9100, signal) {
	if (!await helperAlive()) return;
	await call(`/wake?${target(host, port)}`, { method: "POST" }, 2e3, signal);
}
async function helperSend(host, port, bytes, signal) {
	if (!await helperAlive(true)) return false;
	const r = await call(`/print?${target(host, port)}`, {
		method: "POST",
		headers: { "Content-Type": "application/octet-stream" },
		body: bytes.slice()
	}, 6e4, signal);
	return Boolean(r?.ok);
}
var PRIVATE = /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[0-1])\.)/;
var LAST_OCTETS = [
	2,
	3,
	4,
	10,
	11,
	12,
	15,
	16,
	20,
	21,
	22,
	25,
	30,
	40,
	50,
	51,
	60,
	80,
	100,
	101,
	110,
	150,
	200,
	254
];
function isPrivateIPv4(ip) {
	return PRIVATE.test(ip) && !ip.startsWith("127.") && ip !== "0.0.0.0";
}
function subnetOf(ip) {
	const p = ip.split(".");
	if (p.length !== 4) return null;
	return `${p[0]}.${p[1]}.${p[2]}`;
}
function candidateIPs(subnet, extra = []) {
	const set = new Set(extra.filter((h) => h.startsWith(`${subnet}.`)));
	for (const n of LAST_OCTETS) set.add(`${subnet}.${n}`);
	return [...set];
}
async function guessLocalIPv4s(timeoutMs = 450) {
	if (typeof RTCPeerConnection === "undefined") return [];
	const ips = /* @__PURE__ */ new Set();
	const pc = new RTCPeerConnection({ iceServers: [] });
	try {
		pc.createDataChannel("p");
		pc.onicecandidate = (ev) => {
			const m = (ev.candidate?.candidate ?? "").match(/(\d{1,3}(?:\.\d{1,3}){3})/);
			if (m && isPrivateIPv4(m[1])) ips.add(m[1]);
		};
		const offer = await pc.createOffer();
		await pc.setLocalDescription(offer);
		await wait$1(timeoutMs);
	} catch {} finally {
		try {
			pc.close();
		} catch {}
	}
	return [...ips];
}
function wait$1(ms, signal) {
	return new Promise((resolve, reject) => {
		if (signal?.aborted) {
			reject(new DOMException("aborted", "AbortError"));
			return;
		}
		const t = setTimeout(resolve, ms);
		signal?.addEventListener("abort", () => {
			clearTimeout(t);
			reject(new DOMException("aborted", "AbortError"));
		}, { once: true });
	});
}
async function probeUrl(url, ms = 280, signal) {
	const ac = new AbortController();
	const timer = setTimeout(() => ac.abort(), ms);
	const onOuter = () => ac.abort();
	signal?.addEventListener("abort", onOuter);
	try {
		await fetch(url, {
			method: "GET",
			mode: "no-cors",
			cache: "no-store",
			signal: ac.signal
		});
		return true;
	} catch {
		return false;
	} finally {
		clearTimeout(timer);
		signal?.removeEventListener("abort", onOuter);
	}
}
async function probeHost(host, signal) {
	const [ipp, http, raw] = await Promise.all([
		probeUrl(`http://${host}:631/ipp/print`, 260, signal),
		probeUrl(`http://${host}/`, 220, signal),
		helperProbe(host, 9100, signal)
	]);
	if (ipp) return {
		host,
		port: 631,
		via: "ipp"
	};
	if (raw) return {
		host,
		port: 9100,
		via: "raw"
	};
	if (http) return {
		host,
		port: 631,
		via: "http"
	};
	return null;
}
async function mapPool(items, limit, fn) {
	const out = [];
	let i = 0;
	async function worker() {
		while (i < items.length) {
			const hit = await fn(items[i++]);
			if (hit) out.push(hit);
		}
	}
	await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
	return out;
}
var LOCAL_NAMES = [
	"printer.local",
	"hp.local",
	"hpprinter.local",
	"canon.local",
	"epson.local",
	"brother.local",
	"xerox.local",
	"ricoh.local",
	"laserjet.local"
];
async function scanSubnet(subnet, remembered, signal) {
	return mapPool(candidateIPs(subnet, remembered), 8, (host) => probeHost(host, signal));
}
async function scanHostnames(signal) {
	return mapPool(LOCAL_NAMES, 6, (host) => probeHost(host, signal));
}
async function discoverLan(opts) {
	const localIps = await guessLocalIPv4s(420);
	const remembered = opts.remembered ?? [];
	const subnet = localIps.map(subnetOf).find((s) => Boolean(s)) ?? subnetOf(remembered[0] ?? "") ?? "192.168.0";
	const [hits, names] = await Promise.all([scanSubnet(subnet, remembered, opts.signal), scanHostnames(opts.signal)]);
	const seen = /* @__PURE__ */ new Set();
	const merged = [];
	for (const h of [...hits, ...names]) {
		const k = `${h.host}:${h.port}`;
		if (seen.has(k)) continue;
		seen.add(k);
		merged.push(h);
	}
	return {
		localIps,
		subnet,
		hits: merged
	};
}
var WAKE_GAP_MS = 12e3;
var lastWake = /* @__PURE__ */ new Map();
function wait(ms, signal) {
	return new Promise((resolve, reject) => {
		if (signal?.aborted) {
			reject(new DOMException("aborted", "AbortError"));
			return;
		}
		const t = setTimeout(resolve, ms);
		signal?.addEventListener("abort", () => {
			clearTimeout(t);
			reject(new DOMException("aborted", "AbortError"));
		}, { once: true });
	});
}
async function poke(url, method, body, signal) {
	const ac = new AbortController();
	const timer = setTimeout(() => ac.abort(), 320);
	const onOuter = () => ac.abort();
	signal?.addEventListener("abort", onOuter);
	try {
		await fetch(url, {
			method,
			mode: "no-cors",
			cache: "no-store",
			body: body ? body.slice() : void 0,
			signal: ac.signal
		});
	} catch {} finally {
		clearTimeout(timer);
		signal?.removeEventListener("abort", onOuter);
	}
}
/**
* Office printers leave sleep on a 631/80 poke. 9100은 HTTP를 글자로 인쇄하므로 건드리지 않는다.
* Magic-packet WOL needs UDP; this TCP/HTTP nudge is the best a browser can do.
*/
async function wakePrinter(printer, opts) {
	if (printer.source === "LOCAL") return {
		woke: false,
		skipped: true
	};
	const key = `${printer.host}:${printer.port}`;
	const prev = lastWake.get(key) ?? 0;
	if (!opts?.force && Date.now() - prev < WAKE_GAP_MS) return {
		woke: true,
		skipped: true
	};
	if (printer.source === "DEMO") {
		await wait(70, opts?.signal);
		lastWake.set(key, Date.now());
		return {
			woke: true,
			skipped: false
		};
	}
	const host = printer.host;
	let ipp;
	try {
		ipp = buildGetPrinterAttributes(printerUri(host, printer.port || 631, printer.resourcePath || "/ipp/print", printer.secure), 1);
	} catch {
		ipp = void 0;
	}
	await Promise.all([
		poke(`http://${host}:631/ipp/print`, "POST", ipp, opts?.signal),
		poke(`http://${host}/`, "GET", void 0, opts?.signal),
		probeUrl(`http://${host}:80/`, 280, opts?.signal),
		helperWake(host, 9100, opts?.signal)
	]);
	await wait(160, opts?.signal);
	lastWake.set(key, Date.now());
	return {
		woke: true,
		skipped: false
	};
}
function localPrinter() {
	return {
		id: LOCAL_PRINTER_ID,
		displayName: "이 컴퓨터로 인쇄",
		host: "localhost",
		port: 0,
		resourcePath: "/",
		secure: false,
		protocol: "IPP",
		supportsPdf: true,
		supportsDuplex: true,
		supportsColor: true,
		lastSuccessAt: null,
		source: "LOCAL",
		makeAndModel: "Browser Print Dialog"
	};
}
function demoIppPrinter(host = "192.168.0.20") {
	return {
		id: DEMO_IPP_ID,
		displayName: "누구나프린트 데모 (IPP Everywhere)",
		host,
		port: 631,
		resourcePath: "/ipp/print",
		secure: false,
		protocol: "IPP",
		supportsPdf: true,
		supportsDuplex: true,
		supportsColor: true,
		lastSuccessAt: null,
		source: "DEMO",
		makeAndModel: "PublicPrint Virtual IPP",
		pdl: ["application/pdf", "image/pwg-raster"],
		mediaSupported: [
			"iso_a4_210x297mm",
			"na_letter_8.5x11in",
			"na_index-4x6_4x6in"
		],
		sidesSupported: [
			"one-sided",
			"two-sided-long-edge",
			"two-sided-short-edge"
		]
	};
}
function demoLegacyPrinter(host = "192.168.0.50") {
	return {
		id: DEMO_LEGACY_ID,
		displayName: "구형 사무실 프린터",
		host,
		port: 9100,
		resourcePath: "/",
		secure: false,
		protocol: "RAW9100",
		supportsPdf: false,
		supportsDuplex: true,
		supportsColor: true,
		lastSuccessAt: null,
		source: "DEMO",
		makeAndModel: "Generic PCL",
		pdl: [
			"application/vnd.hp-PCL",
			"application/PCLm",
			"image/pwg-raster"
		],
		mediaSupported: [
			"iso_a4_210x297mm",
			"na_letter_8.5x11in",
			"na_index-4x6_4x6in"
		],
		sidesSupported: [
			"one-sided",
			"two-sided-long-edge",
			"two-sided-short-edge"
		],
		experimental: false
	};
}
function fromHit(hit) {
	const raw = hit.via === "raw" || hit.port === 9100;
	return {
		id: `scan-${hit.host}`,
		displayName: raw ? `구형 프린터 ${hit.host}` : `IPP 프린터 ${hit.host}`,
		host: hit.host,
		port: raw ? 9100 : 631,
		resourcePath: raw ? "/" : "/ipp/print",
		secure: false,
		protocol: raw ? "RAW9100" : "IPP",
		supportsPdf: raw ? false : null,
		supportsDuplex: true,
		supportsColor: true,
		lastSuccessAt: null,
		source: "MDNS",
		pdl: raw ? ["application/vnd.hp-PCL", "image/pwg-raster"] : void 0
	};
}
async function discoverPrinters(onFound, signal, opts = {}) {
	if (typeof navigator !== "undefined" && navigator.onLine === false) throw new JobError("NO_NETWORK", "NO_NETWORK");
	opts.onStatus?.("이 기기 주소를 읽는 중…");
	onFound(localPrinter());
	let subnet = "192.168.0";
	let localIp = null;
	let hits = [];
	try {
		opts.onStatus?.("같은 네트워크 IP를 정밀 검색하는 중…");
		const lan = await discoverLan({
			remembered: opts.remembered,
			signal
		});
		subnet = lan.subnet ?? subnet;
		localIp = lan.localIps[0] ?? null;
		hits = lan.hits;
		opts.onLan?.({
			localIp,
			subnet
		});
	} catch {
		opts.onLan?.({
			localIp: null,
			subnet
		});
	}
	onFound(demoIppPrinter(`${subnet}.20`));
	onFound(demoLegacyPrinter(`${subnet}.50`));
	opts.onStatus?.("절전 프린터에 깨우기 신호…");
	const skip = /* @__PURE__ */ new Set([
		`${subnet}.20`,
		`${subnet}.50`,
		"127.0.0.1",
		"localhost"
	]);
	for (const hit of hits) {
		if (skip.has(hit.host)) continue;
		onFound(fromHit(hit));
	}
	return {
		found: 3 + hits.length,
		online: true,
		subnet,
		localIp
	};
}
async function wakeKnown(printers, signal) {
	await Promise.all(printers.filter((p) => p.source !== "LOCAL").map((p) => wakePrinter(p, { signal }).catch(() => void 0)));
}
var IPV4 = /^(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;
function isValidIPv4(value) {
	return IPV4.test(value.trim());
}
function isValidPort(value) {
	return Number.isInteger(value) && value >= 1 && value <= 65535;
}
function methodFromResult(r) {
	if (r.directRaw) return "RAW_HELPER";
	if (r.usedHelper || r.usedLocalDialog) return "OS_DRIVER";
	if (r.convertedFormat === "PWG Raster") return "IPP_PWG";
	if (r.convertedFormat === "PCL") return "IPP_PCL";
	if (r.convertedFormat === "PostScript") return "IPP_PS";
	return "IPP_PDF";
}
function methodLabel(method) {
	switch (method) {
		case "IPP_PDF": return "PDF 직접 전송";
		case "IPP_PCL": return "PCL 변환 전송";
		case "IPP_PWG": return "PWG Raster 변환 전송";
		case "IPP_PS": return "PostScript 변환 전송";
		case "RAW_HELPER": return "PC 도우미 직접 전송";
		case "OS_DRIVER": return "이 컴퓨터 드라이버";
		default: return null;
	}
}
function rememberSettings(s) {
	return {
		color: s.color,
		paper: s.paper,
		orientation: s.orientation,
		duplex: s.duplex,
		quality: s.quality
	};
}
/** 새 문서를 열 때 그 프린터의 지난 설정을 불러온다. 매수는 항상 지금 값을 쓴다. */
function applyRemembered(base, printer) {
	if (!printer?.lastSettings) return base;
	return {
		...base,
		...printer.lastSettings,
		copies: base.copies
	};
}
var emptySession = () => ({
	kind: "image",
	name: "",
	images: [],
	pdfBytes: null,
	previewUrl: null,
	pageCount: 1,
	settings: { ...DEFAULT_SETTINGS }
});
var useAppStore = create()(persist((set, get) => ({
	hydrated: true,
	onboardingDone: true,
	screen: "home",
	printers: [localPrinter()],
	selectedPrinterId: LOCAL_PRINTER_ID,
	jobs: [],
	session: null,
	result: null,
	searching: false,
	lan: {
		localIp: null,
		subnet: null
	},
	setHydrated: () => set({ hydrated: true }),
	completeOnboarding: () => set({
		onboardingDone: true,
		screen: "home"
	}),
	go: (screen) => set({ screen }),
	upsertPrinter: (printer) => set((s) => {
		const idx = s.printers.findIndex((p) => p.id === printer.id);
		return {
			printers: idx >= 0 ? s.printers.map((p, i) => i === idx ? {
				...p,
				...printer,
				id: p.id
			} : p) : [...s.printers, printer],
			selectedPrinterId: s.selectedPrinterId ?? printer.id
		};
	}),
	removePrinter: (id) => set((s) => ({
		printers: s.printers.filter((p) => p.id !== id),
		selectedPrinterId: s.selectedPrinterId === id ? s.printers.find((p) => p.id !== id)?.id ?? null : s.selectedPrinterId
	})),
	selectPrinter: (id) => set({ selectedPrinterId: id }),
	markSuccess: (id, info) => set((s) => ({ printers: s.printers.map((p) => p.id === id ? {
		...p,
		lastSuccessAt: Date.now(),
		...info?.method ? { lastMethod: info.method } : {},
		...info?.settings ? { lastSettings: info.settings } : {}
	} : p) })),
	setSearching: (searching) => set({ searching }),
	setLan: (lan) => set({ lan }),
	setSession: (session) => set((s) => {
		if (s.session?.previewUrl) URL.revokeObjectURL(s.session.previewUrl);
		for (const img of s.session?.images ?? []) try {
			URL.revokeObjectURL(img.url);
		} catch {}
		if (!session) return { session: null };
		const merged = {
			...emptySession(),
			...session
		};
		if (merged.kind !== "test") {
			const printer = s.printers.find((p) => p.id === s.selectedPrinterId);
			merged.settings = applyRemembered(merged.settings, printer);
		}
		return { session: merged };
	}),
	updateSettings: (patch) => set((s) => s.session ? { session: {
		...s.session,
		settings: {
			...s.session.settings,
			...patch
		}
	} } : s),
	setPdfBytes: (bytes, pageCount) => set((s) => s.session ? { session: {
		...s.session,
		pdfBytes: bytes,
		pageCount
	} } : s),
	setResult: (result) => set({ result }),
	addJob: (job) => set((s) => ({ jobs: [job, ...s.jobs].slice(0, 30) })),
	clearJobs: () => set({ jobs: [] }),
	selectedPrinter: () => {
		const s = get();
		return s.printers.find((p) => p.id === s.selectedPrinterId);
	}
}), {
	name: "publicprint.v2",
	skipHydration: true,
	partialize: (s) => ({
		onboardingDone: s.onboardingDone,
		printers: s.printers,
		selectedPrinterId: s.selectedPrinterId,
		jobs: s.jobs,
		lan: s.lan
	})
}));
function sortedPrinters(printers) {
	return [...printers].sort((a, b) => {
		if (a.source === "LOCAL" && b.source !== "LOCAL") return -1;
		if (b.source === "LOCAL" && a.source !== "LOCAL") return 1;
		const as = a.lastSuccessAt ?? 0;
		const bs = b.lastSuccessAt ?? 0;
		if (as !== bs) return bs - as;
		return a.displayName.localeCompare(b.displayName, "ko");
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-md font-medium disabled:pointer-events-none disabled:opacity-45", {
	variants: {
		variant: {
			default: "bg-accent text-on-accent hover:bg-accent/90",
			secondary: "border border-border bg-surface text-fg hover:bg-surface-2",
			ghost: "bg-transparent text-fg hover:bg-surface-2"
		},
		size: {
			default: "h-12 px-4 text-base",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function PhoneFrame({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-dvh flex-1 flex-col",
		children
	});
}
function TopBar({ title, onBack, trailing }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-10 flex h-14 items-center gap-1 border-b border-border bg-bg/90 px-2 backdrop-blur-md",
		children: [
			onBack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				"aria-label": "뒤로",
				onClick: onBack,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-11 shrink-0" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "min-w-0 flex-1 truncate text-center text-base font-medium tracking-tight",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-11 shrink-0 items-center justify-center",
				children: trailing
			})
		]
	});
}
function ScreenBody({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("screen-in flex flex-1 flex-col px-5 pt-6 pb-8", className),
		style: { paddingBottom: "max(2rem, env(safe-area-inset-bottom))" },
		children
	});
}
var PROTOCOLS = [
	{
		id: "IPP",
		label: "IPP",
		port: 631,
		note: "가장 흔함 · 포트 631"
	},
	{
		id: "IPPS",
		label: "IPPS",
		port: 631,
		note: "암호화. 사설 인증서는 실패할 수 있음"
	},
	{
		id: "RAW9100",
		label: "Raw 9100",
		port: 9100,
		note: "구형 사무기 · 이 컴퓨터 드라이버로 인쇄"
	}
];
function AddPrinterScreen() {
	const go = useAppStore((s) => s.go);
	const upsertPrinter = useAppStore((s) => s.upsertPrinter);
	const selectPrinter = useAppStore((s) => s.selectPrinter);
	const lan = useAppStore((s) => s.lan);
	const [name, setName] = (0, import_react.useState)("");
	const [host, setHost] = (0, import_react.useState)("");
	const [port, setPort] = (0, import_react.useState)("631");
	const [protocol, setProtocol] = (0, import_react.useState)("IPP");
	const [path, setPath] = (0, import_react.useState)("/ipp/print");
	const [language, setLanguage] = (0, import_react.useState)("auto");
	const [error, setError] = (0, import_react.useState)(null);
	function applyProtocol(p) {
		setProtocol(p);
		const def = PROTOCOLS.find((x) => x.id === p);
		if (def) setPort(String(def.port));
	}
	function submit() {
		setError(null);
		const p = Number(port);
		const hostTrim = host.trim();
		if (!(isValidIPv4(hostTrim) || hostTrim === "localhost" || /^[a-z0-9.-]+$/i.test(hostTrim)) || !isValidPort(p)) {
			setError("IP 또는 포트가 올바르지 않습니다.");
			return;
		}
		const id = crypto.randomUUID();
		upsertPrinter({
			id,
			displayName: name.trim() || hostTrim,
			host: hostTrim,
			port: p,
			resourcePath: path.trim() || "/ipp/print",
			secure: protocol === "IPPS",
			protocol,
			supportsPdf: protocol === "RAW9100" ? false : null,
			supportsDuplex: true,
			supportsColor: true,
			lastSuccessAt: null,
			source: "MANUAL",
			pdl: protocol === "RAW9100" ? ["application/vnd.hp-PCL", "image/pwg-raster"] : void 0,
			experimental: false,
			language: protocol === "RAW9100" ? language : void 0
		});
		selectPrinter(id);
		go("printers");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PhoneFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "프린터 추가",
		onBack: () => go("printers")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, {
		className: "gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "별칭",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: name,
					onChange: (e) => setName(e.target.value),
					placeholder: "거실 프린터",
					className: "field"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "IP 주소",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: host,
					onChange: (e) => setHost(e.target.value),
					placeholder: lan.subnet ? `${lan.subnet}.20` : "192.168.0.20",
					inputMode: "decimal",
					autoCapitalize: "off",
					className: "field"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: lan.subnet ? `이 기기 대역은 ${lan.subnet}.0/24${lan.localIp ? ` (지금 ${lan.localIp})` : ""}입니다.` : "같은 Wi-Fi의 IPv4를 입력하세요."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				label: "프로토콜",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: PROTOCOLS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => applyProtocol(item.id),
						className: cn("rounded-md border px-2 py-3 text-center text-sm", protocol === item.id ? "border-accent bg-accent-soft text-fg" : "border-border bg-surface text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium text-fg",
							children: item.label
						}), item.experimental ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-warn",
							children: "실험"
						}) : null]
					}, item.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: PROTOCOLS.find((item) => item.id === protocol)?.note
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "포트",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: port,
					onChange: (e) => setPort(e.target.value),
					inputMode: "numeric",
					className: "field"
				})
			}),
			protocol !== "RAW9100" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "경로",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: path,
					onChange: (e) => setPath(e.target.value),
					className: "field"
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "border-y border-border py-3 text-xs leading-relaxed text-muted",
				children: "구형 사무기는 PDF 대신 앱 안 변환 엔진이 바꿔 보냅니다. 기본은 PCL이고, 영어 글자만 나오면 PostScript로 바꿔 보세요."
			}),
			protocol === "RAW9100" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "인쇄 언어",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-4 gap-2",
					children: [
						["auto", "자동"],
						["pcl", "PCL"],
						["ps", "PostScript"],
						["pwg", "PWG"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setLanguage(id),
						className: cn("h-11 rounded-md border text-sm", language === id ? "border-accent bg-accent-soft text-accent" : "border-border bg-surface text-muted"),
						children: label
					}, id))
				})
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-auto w-full",
				onClick: submit,
				children: "저장"
			})
		]
	})] });
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-2 block text-sm font-medium",
			children: label
		}), children]
	});
}
var MAX_IMAGES = 20;
var MAX_PDF_BYTES = 41943040;
function HomeScreen() {
	const go = useAppStore((s) => s.go);
	const printers = useAppStore((s) => s.printers);
	const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
	const session = useAppStore((s) => s.session);
	const jobs = useAppStore((s) => s.jobs);
	const setSession = useAppStore((s) => s.setSession);
	const photoRef = (0, import_react.useRef)(null);
	const pdfRef = (0, import_react.useRef)(null);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const printer = printers.find((p) => p.id === selectedPrinterId) ?? printers[0];
	async function openImages(list) {
		const files = [...list ?? []].filter((f) => f.type.startsWith("image/")).slice(0, MAX_IMAGES);
		if (files.length === 0) return;
		setError(null);
		const images = files.map((file) => ({
			name: file.name,
			url: URL.createObjectURL(file),
			blob: file
		}));
		setSession({
			kind: "image",
			name: files.length === 1 ? files[0].name : `사진 ${files.length}장`,
			images,
			pdfBytes: null,
			previewUrl: images[0].url,
			pageCount: images.length,
			settings: { ...DEFAULT_SETTINGS }
		});
		go("preview");
	}
	async function openPdf(list) {
		const file = list?.[0];
		if (!file) return;
		if (file.size > MAX_PDF_BYTES) {
			setError("PDF가 40MB보다 큽니다. 더 작은 파일로 나눠 주세요.");
			return;
		}
		setError(null);
		setBusy("PDF 미리보기 만드는 중…");
		try {
			const pdfBytes = new Uint8Array(await file.arrayBuffer());
			const { pdfPreview } = await import("./pdf-preview-CruXjyu-.mjs");
			const preview = await pdfPreview(pdfBytes);
			setSession({
				kind: "pdf",
				name: file.name,
				images: [],
				pdfBytes,
				previewUrl: preview.url,
				pageCount: preview.pageCount,
				settings: { ...DEFAULT_SETTINGS }
			});
			go("preview");
		} catch {
			setError("이 PDF는 열 수 없습니다. 다른 파일로 시도해 보세요.");
		} finally {
			setBusy(null);
		}
	}
	async function openTest() {
		setError(null);
		setBusy("테스트 페이지 그리는 중…");
		try {
			const target = printer ?? localPrinter();
			const device = `${navigator.language}`;
			const { renderTestPageJpeg } = await import("./test-page-Dnk1WEz9.mjs");
			const jpeg = await renderTestPageJpeg(target, device, /* @__PURE__ */ new Date(), {
				scale: 1.05,
				quality: .82
			});
			const copy = new Uint8Array(jpeg.byteLength);
			copy.set(jpeg);
			const url = URL.createObjectURL(new Blob([copy], { type: "image/jpeg" }));
			setSession({
				kind: "test",
				name: "테스트 페이지",
				images: [],
				pdfBytes: null,
				previewUrl: url,
				pageCount: 1,
				settings: {
					...DEFAULT_SETTINGS,
					copies: 1,
					duplex: "NONE",
					paper: "A4"
				}
			});
			go("preview");
		} catch {
			setError("테스트 페이지를 만들지 못했습니다.");
		} finally {
			setBusy(null);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PhoneFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "누구나프린트",
		trailing: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "icon",
			"aria-label": "설정",
			onClick: () => go("settings"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-5" })
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, {
		className: "gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-3xl font-medium tracking-tight",
				children: "무엇을 보낼까요"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-prose text-sm leading-relaxed text-muted",
				children: "사진이나 PDF를 고른 뒤 매수와 용지를 정합니다. 같은 Wi-Fi가 아니면 IP로 프린터를 넣으세요."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => go("printers"),
				className: "flex items-center gap-3 border-y border-border py-4 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block text-xs text-subtle",
						children: "프린터"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block truncate text-base font-medium",
						children: printer?.displayName ?? "프린터를 고르세요"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1 text-sm text-accent",
					children: ["변경", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Image, { className: "size-5" }),
						title: "사진",
						hint: "여러 장",
						onClick: () => photoRef.current?.click()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "size-5" }),
						title: "PDF",
						hint: "첫 장 미리보기",
						onClick: () => pdfRef.current?.click()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionRow, {
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, { className: "size-5" }),
						title: busy ?? "테스트 페이지",
						hint: "연결 확인 1장",
						onClick: () => void openTest(),
						disabled: Boolean(busy)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: photoRef,
				type: "file",
				accept: "image/*",
				multiple: true,
				className: "hidden",
				onChange: (e) => {
					openImages(e.target.files);
					e.target.value = "";
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: pdfRef,
				type: "file",
				accept: "application/pdf,.pdf",
				className: "hidden",
				onChange: (e) => {
					openPdf(e.target.files);
					e.target.value = "";
				}
			}),
			session ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "w-full",
				onClick: () => go("preview"),
				children: ["이어서 인쇄 · ", session.name]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}) : null,
			printer?.id === "local-device" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-subtle",
				children: "기본은 이 기기의 인쇄 창입니다. 매수는 그 창에 같은 문서를 반복해서 넣습니다. 검색하면 데모 프린터도 나옵니다."
			}) : null,
			jobs.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-subtle",
				children: "최근"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2",
				children: jobs.slice(0, 4).map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 border-b border-border py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 truncate",
						children: job.printerName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: job.status === "SUCCESS" ? "shrink-0 text-accent" : "shrink-0 text-danger",
						children: [job.status === "SUCCESS" ? "보냄" : job.status === "PARTIAL" ? "일부" : "실패", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 font-mono text-subtle",
							children: job.copies
						})]
					})]
				}, job.id))
			})] }) : null
		]
	})] });
}
function ActionRow({ icon, title, hint, onClick, disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled,
		onClick,
		className: "flex h-16 items-center gap-4 border-b border-border text-left disabled:opacity-45",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-fg",
				children: icon
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block font-medium",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block text-xs text-muted",
					children: hint
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-subtle" })
		]
	});
}
var COLORS = [
	{
		id: "AUTO",
		label: "자동"
	},
	{
		id: "COLOR",
		label: "컬러"
	},
	{
		id: "MONO",
		label: "흑백"
	}
];
var ORIENTATIONS = [{
	id: "PORTRAIT",
	label: "세로"
}, {
	id: "LANDSCAPE",
	label: "가로"
}];
var DUPLEXES = [
	{
		id: "NONE",
		label: "단면"
	},
	{
		id: "LONG_EDGE",
		label: "긴 변"
	},
	{
		id: "SHORT_EDGE",
		label: "짧은 변"
	}
];
var QUALITIES = [
	{
		id: "FAST",
		label: "빠르게"
	},
	{
		id: "NORMAL",
		label: "보통"
	},
	{
		id: "SHARP",
		label: "선명"
	}
];
function PreviewScreen() {
	const go = useAppStore((s) => s.go);
	const session = useAppStore((s) => s.session);
	const printers = useAppStore((s) => s.printers);
	const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
	const updateSettings = useAppStore((s) => s.updateSettings);
	const printer = printers.find((p) => p.id === selectedPrinterId);
	const settings = session?.settings;
	if (!session || !settings) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PhoneFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "미리보기",
		onBack: () => go("home")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, {
		className: "items-center justify-center gap-4 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "인쇄할 파일이 없습니다."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => go("home"),
			children: "홈으로"
		})]
	})] });
	const copies = settings.copies;
	const colorOk = canUseColor(printer);
	const duplexOk = canUseDuplex(printer);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PhoneFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: session.name,
		onBack: () => go("home")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, {
		className: "gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => go("printers"),
				className: "flex items-center justify-between border-y border-border py-3 text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 truncate",
					children: printer?.displayName ?? "프린터 없음"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "shrink-0 text-accent",
					children: "변경"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-surface shadow-soft",
				children: [session.previewUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: session.previewUrl,
					alt: "",
					className: "mx-auto max-h-80 w-full bg-surface object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-48 items-center justify-center text-sm text-muted",
					children: "미리보기 없음"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "border-t border-border px-4 py-2 font-mono text-xs text-muted",
					children: [
						session.pageCount,
						"쪽",
						session.kind === "image" && session.images.length > 1 ? ` · 사진 ${session.images.length}장` : ""
					]
				})]
			}),
			session.kind === "image" && session.images.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto pb-1",
				children: session.images.map((img) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: img.url,
					alt: "",
					className: "h-16 w-16 shrink-0 rounded-lg border border-border object-cover"
				}, img.url))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row$1, {
				label: "매수",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							size: "icon",
							"aria-label": "매수 줄이기",
							disabled: copies <= 1,
							onClick: () => updateSettings({ copies: Math.max(1, copies - 1) }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "w-8 text-center font-mono text-xl tabular-nums",
							children: copies
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							size: "icon",
							"aria-label": "매수 늘리기",
							disabled: copies >= 99,
							onClick: () => updateSettings({ copies: Math.min(99, copies + 1) }),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" })
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "색",
				value: colorOk ? settings.color : "MONO",
				options: COLORS,
				disabled: !colorOk,
				onChange: (color) => updateSettings({ color })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "방향",
				value: settings.orientation,
				options: ORIENTATIONS,
				onChange: (orientation) => updateSettings({ orientation })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-sm font-medium",
				children: "용지"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: PAPER_OPTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: settings.paper === item.id,
					onClick: () => updateSettings({ paper: item.id }),
					children: item.label
				}, item.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "양면",
				value: settings.duplex,
				options: DUPLEXES,
				disabled: !duplexOk,
				onChange: (duplex) => updateSettings({ duplex })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
				label: "품질",
				value: settings.quality,
				options: QUALITIES,
				onChange: (quality) => updateSettings({ quality })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "sticky bottom-0 mt-auto bg-bg pt-3",
				children: printer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					onClick: () => go("progress"),
					children: "인쇄"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "w-full",
					onClick: () => go("printers"),
					children: "프린터 선택"
				})
			})
		]
	})] });
}
function Row$1({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-medium",
			children: label
		}), children]
	});
}
function Choice({ label, value, options, disabled, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mb-2 text-sm font-medium",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-2",
		style: { gridTemplateColumns: `repeat(${options.length}, minmax(0, 1fr))` },
		children: options.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
			active: value === item.id,
			disabled,
			onClick: () => onChange(item.id),
			children: item.label
		}, item.id))
	})] });
}
function Chip({ active, disabled, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		disabled,
		onClick,
		className: cn("h-11 rounded-md border px-3 text-sm", active ? "border-accent bg-accent-soft text-accent" : "border-border bg-surface text-muted", disabled && "opacity-45"),
		children
	});
}
function sourceLabel(p) {
	if (p.source === "LOCAL") return "이 기기";
	if (p.source === "MANUAL") return "수동";
	if (p.source === "DEMO") return "검색";
	return "검색";
}
function PrinterCard({ printer, selected, onSelect, onRemove, onLanguage }) {
	const pdfOk = isPdfDirectSupported(printer);
	const engine = usesInAppEngine(printer);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("border-b border-border py-4", selected && "border-accent"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onSelect,
				className: "w-full text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-lg font-medium tracking-tight",
									children: printer.displayName
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 truncate text-sm text-muted",
									children: [printer.source === "LOCAL" ? "브라우저 인쇄" : `${printer.host}:${printer.port}`, printer.secure ? " · IPPS" : printer.protocol === "RAW9100" ? " · Raw 9100" : " · IPP"]
								}),
								methodLabel(printer.lastMethod) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-0.5 truncate text-xs text-subtle",
									children: ["지난번 성공 · ", methodLabel(printer.lastMethod)]
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 text-xs text-subtle",
							children: sourceLabel(printer)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-subtle",
						children: [
							pdfOk ? "PDF" : "앱 변환",
							engine && !pdfOk ? "PCL · PS · PWG" : null,
							canUseDuplex(printer) ? "양면" : null,
							printer.secure ? "IPPS" : null
						].filter(Boolean).join("  ·  ")
					}),
					engine && !pdfOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-relaxed text-muted",
						children: "PDF를 직접 받지 않습니다. 앱에 들어 있는 변환 엔진이 그림(PCL/PWG)으로 바꿔 보냅니다."
					}) : null
				]
			}),
			engine && onLanguage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "인쇄 언어 (영어 글자나 깨진 그림이 나오면 바꿔 보세요)"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1.5 flex flex-wrap gap-1.5",
					children: [
						["auto", "자동"],
						["pcl", "PCL"],
						["ps", "PostScript"],
						["pwg", "PWG"]
					].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onLanguage(id),
						className: cn("h-9 rounded-md border px-3 text-xs", (printer.language ?? "auto") === id ? "border-accent bg-accent-soft text-accent" : "border-border text-muted"),
						children: label
					}, id))
				})]
			}) : null,
			printer.source === "MANUAL" && onRemove ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: onRemove,
				className: "mt-3 flex items-center gap-1 text-xs text-muted",
				"aria-label": "프린터 삭제",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }), "삭제"]
			}) : null
		]
	});
}
function PrintersScreen() {
	const go = useAppStore((s) => s.go);
	const printers = useAppStore((s) => s.printers);
	const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
	const upsertPrinter = useAppStore((s) => s.upsertPrinter);
	const removePrinter = useAppStore((s) => s.removePrinter);
	const selectPrinter = useAppStore((s) => s.selectPrinter);
	const searching = useAppStore((s) => s.searching);
	const setSearching = useAppStore((s) => s.setSearching);
	const setLan = useAppStore((s) => s.setLan);
	const lan = useAppStore((s) => s.lan);
	const [error, setError] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)(null);
	const ran = (0, import_react.useRef)(false);
	async function search() {
		setError(null);
		setSearching(true);
		setStatus("이 기기 주소를 읽는 중…");
		const ac = new AbortController();
		try {
			upsertPrinter(localPrinter());
			const remembered = printers.filter((p) => p.source !== "LOCAL").map((p) => p.host);
			wakeKnown(printers.filter((p) => p.source !== "LOCAL"), ac.signal);
			await discoverPrinters((p) => upsertPrinter(p), ac.signal, {
				remembered,
				onStatus: setStatus,
				onLan: setLan
			});
		} catch (err) {
			if (err instanceof JobError) setError(JOB_ERROR_MESSAGE[err.code]);
			else if (err?.name !== "AbortError") setError(JOB_ERROR_MESSAGE.NOT_FOUND);
		} finally {
			setSearching(false);
			setStatus(null);
		}
	}
	(0, import_react.useEffect)(() => {
		if (ran.current) return;
		ran.current = true;
		search();
	}, []);
	const list = sortedPrinters(printers);
	const emptyNet = !searching && list.filter((p) => p.source !== "LOCAL").length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PhoneFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "프린터",
		onBack: () => go("home"),
		trailing: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "icon",
			"aria-label": "다시 검색",
			onClick: () => void search(),
			disabled: searching,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: cn("size-5", searching && "animate-spin") })
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, {
		className: "gap-4",
		children: [
			searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 border-b border-border py-3 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-5 animate-spin text-accent" }), status ?? "근처 프린터를 찾는 중…"]
			}) : lan.subnet ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-subtle",
				children: [
					"검색 대역 ",
					lan.subnet,
					".0/24",
					lan.localIp ? ` · 이 기기 ${lan.localIp}` : ""
				]
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-3 border-b border-border py-3 text-sm text-danger",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WifiOff, { className: "mt-0.5 size-5 shrink-0" }), error]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col gap-3",
				children: list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrinterCard, {
					printer: p,
					selected: p.id === selectedPrinterId,
					onSelect: () => {
						selectPrinter(p.id);
						go("home");
					},
					onRemove: p.source === "MANUAL" ? () => removePrinter(p.id) : void 0,
					onLanguage: p.source === "LOCAL" ? void 0 : (language) => upsertPrinter({
						...p,
						language
					})
				}, p.id))
			}),
			emptyNet || list.length <= 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "다음 행동"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpCard, {
						title: "절전이어도 됩니다",
						body: "검색과 인쇄 때 IPP·웹으로 깨우기 신호를 보냅니다. PrinterShare처럼 잠든 사무기를 직접 깨웁니다."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpCard, {
						title: "IP가 있으면 수동 추가",
						body: "같은 대역을 정밀 검색합니다. 그래도 없으면 프린터 네트워크 페이지의 IP를 입력하세요."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpCard, {
						title: "AirPrint/Mopria 없는 구형기",
						body: "PDF를 못 받아도 됩니다. 앱 안 변환 엔진이 PCL/PWG로 바꿔 보내고, 필요하면 이 컴퓨터 드라이버로 넘깁니다. 따로 설치할 프로그램은 없습니다."
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-auto w-full",
				onClick: () => go("add-printer"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" }), "IP로 수동 추가"]
			})
		]
	})] });
}
function HelpCard({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-b border-border py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm leading-relaxed text-muted",
			children: body
		})]
	});
}
function strip(reason) {
	return reason.replace(/-(error|warning|report)$/, "");
}
/** 프린터가 알려준 이유 키워드를 사람이 고칠 수 있는 문제로 바꾼다. 경고(-warning)는 옵션으로만 포함. */
function classifyReasons(reasons, includeWarnings) {
	for (const raw of reasons) {
		if (!includeWarnings && raw.endsWith("-warning")) continue;
		switch (strip(raw)) {
			case "media-jam": return "PAPER_JAM";
			case "media-empty":
			case "media-needed":
			case "input-tray-missing": return "PAPER_OUT";
			case "toner-empty":
			case "marker-supply-empty":
			case "ink-empty": return "TONER_EMPTY";
			case "cover-open":
			case "door-open":
			case "interlock-open": return "COVER_OPEN";
		}
	}
	return null;
}
function interpretJob(s) {
	const all = [...s.jobReasons, ...s.printerReasons].filter((r) => r !== "none");
	switch (s.state) {
		case 9: return { kind: "done" };
		case 7:
		case 8:
		case 6: return {
			kind: "failed",
			code: classifyReasons(all, true) ?? "JOB_FAILED",
			reasons: all
		};
		case 3:
		case 4:
		case 5: {
			const code = classifyReasons(all, false);
			return code ? {
				kind: "failed",
				code,
				reasons: all
			} : { kind: "working" };
		}
		default: return { kind: "unknown" };
	}
}
function sleep(ms, signal) {
	return new Promise((resolve) => {
		const t = setTimeout(resolve, ms);
		signal?.addEventListener("abort", () => {
			clearTimeout(t);
			resolve();
		}, { once: true });
	});
}
/**
* 작업이 끝나거나 멈출 때까지 상태를 묻는다. 확실한 실패만 failed로 알리고,
* 상태를 못 읽거나 시간이 다 되면 working/unknown으로 돌려 성공 처리를 막지 않는다.
*/
async function watchJob(poll, opts = {}) {
	const deadline = Date.now() + (opts.timeoutMs ?? 2e4);
	const interval = opts.intervalMs ?? 1500;
	let last = { kind: "working" };
	while (Date.now() < deadline) {
		if (opts.signal?.aborted) return { kind: "unknown" };
		try {
			last = interpretJob(await poll());
		} catch {
			return { kind: "unknown" };
		}
		opts.onTick?.(last);
		if (last.kind !== "working") return last;
		await sleep(interval, opts.signal);
	}
	return last;
}
var ESC = 27;
var encoder = new TextEncoder();
function paperCode(paper) {
	switch (resolvePaper(paper)) {
		case "LETTER": return 2;
		case "LEGAL": return 3;
		case "A5": return 25;
		case "B5": return 45;
		case "PHOTO_4X6": return 71;
		default: return 26;
	}
}
function duplexCode(duplex) {
	if (duplex === "LONG_EDGE") return 1;
	if (duplex === "SHORT_EDGE") return 2;
	return 0;
}
var Out = class {
	buf;
	o = 0;
	constructor(cap) {
		this.buf = new Uint8Array(Math.max(256, cap));
	}
	grow(need) {
		if (this.o + need <= this.buf.length) return;
		let n = this.buf.length;
		while (n < this.o + need) n *= 2;
		const next = new Uint8Array(n);
		next.set(this.buf.subarray(0, this.o));
		this.buf = next;
	}
	bytes(b) {
		this.grow(b.length);
		this.buf.set(b, this.o);
		this.o += b.length;
	}
	str(s) {
		this.bytes(encoder.encode(s));
	}
	u8(...n) {
		this.grow(n.length);
		this.buf.set(n, this.o);
		this.o += n.length;
	}
	result() {
		return this.buf.subarray(0, this.o);
	}
};
function packMonoPage(page) {
	const bpl = page.width + 7 >> 3;
	const out = new Uint8Array(bpl * page.height);
	const src = page.data;
	const w = page.width;
	const h = page.height;
	for (let y = 0; y < h; y++) {
		const row = y * bpl;
		const srcRow = y * w * 4;
		for (let x = 0; x < w; x++) {
			const i = srcRow + (x << 2);
			if (src[i] + src[i + 1] + src[i + 2] < 400) out[row + (x >> 3)] |= 128 >> (x & 7);
		}
	}
	return out;
}
function packRgbPage(page) {
	const w = page.width;
	const h = page.height;
	const out = new Uint8Array(w * h * 3);
	const src = page.data;
	let d = 0;
	for (let i = 0; i < src.length; i += 4) {
		out[d++] = src[i];
		out[d++] = src[i + 1];
		out[d++] = src[i + 2];
	}
	return out;
}
function pclJobStart(settings, dpi) {
	const out = new Out(256);
	out.u8(ESC, 69);
	out.str(`\x1B&l${paperCode(settings.paper)}A`);
	out.str(`\x1B&l${settings.orientation === "LANDSCAPE" ? 1 : 0}O`);
	out.str(`\x1B&l${duplexCode(settings.duplex)}S`);
	if (settings.duplex === "SHORT_EDGE") out.str(`\x1B&l1G`);
	out.str(`\x1B&l${Math.max(1, Math.min(99, settings.copies))}X`);
	out.str(`\x1B&l0E`);
	out.str(`\x1B*t${dpi}R`);
	return out.result();
}
function pclPage(page, opts) {
	const bpl = opts.mono ? page.width + 7 >> 3 : page.width * 3;
	const out = new Out(page.height * (bpl + 8) + 128);
	out.str(`\x1B*p0x0Y`);
	out.str(`\x1B*r${page.width}S`);
	out.str(`\x1B*r${page.height}T`);
	if (opts.mono) {
		out.str(`\x1B*b0M`);
		out.str(`\x1B*r1A`);
		const packed = packMonoPage(page);
		const prefix = encoder.encode(`\x1B*b${bpl}W`);
		for (let y = 0; y < page.height; y++) {
			out.bytes(prefix);
			out.bytes(packed.subarray(y * bpl, y * bpl + bpl));
		}
	} else {
		out.u8(ESC, 42, 118, 54, 87, 0, 1, 0, 8, 8, 8);
		out.str(`\x1B*b0M`);
		out.str(`\x1B*r1A`);
		const packed = packRgbPage(page);
		const prefix = encoder.encode(`\x1B*b${bpl}W`);
		for (let y = 0; y < page.height; y++) {
			out.bytes(prefix);
			out.bytes(packed.subarray(y * bpl, y * bpl + bpl));
		}
	}
	out.str(`\x1B*rC`);
	out.str(`\x1B&l0H`);
	return out.result();
}
function pclJobEnd() {
	return Uint8Array.of(ESC, 69);
}
function concatBytes(chunks) {
	let total = 0;
	for (const c of chunks) total += c.length;
	const out = new Uint8Array(total);
	let o = 0;
	for (const c of chunks) {
		out.set(c, o);
		o += c.length;
	}
	return out;
}
/** HP PCL 5 raster — duplex &l#S (0 simplex, 1 long-edge, 2 short-edge). */
function encodePclJob(pages, settings, opts) {
	return concatBytes([
		pclJobStart(settings, opts.dpi ?? 75),
		...pages.map((p) => pclPage(p, { mono: opts.mono })),
		pclJobEnd()
	]);
}
var PCL_MIME = "application/vnd.hp-PCL";
var HEADER_SIZE = 1796;
function u32(buf, offset, value) {
	buf.setUint32(offset, value >>> 0, false);
}
function f32(buf, offset, value) {
	buf.setFloat32(offset, value, false);
}
function cstr(bytes, offset, value, max) {
	const enc = new TextEncoder().encode(value.slice(0, max - 1));
	bytes.set(enc, offset);
}
function writeHeader(page, settings, opts) {
	const bytes = new Uint8Array(HEADER_SIZE);
	const view = new DataView(bytes.buffer);
	const pts = pageSizePoints(settings.paper, settings.orientation);
	const dpi = opts.dpi;
	const bpp = opts.mono ? 8 : 24;
	const bpl = opts.mono ? page.width : page.width * 3;
	cstr(bytes, 0, "PwgRaster", 64);
	cstr(bytes, 192, "Auto", 64);
	u32(view, 272, settings.duplex === "NONE" ? 0 : 1);
	u32(view, 276, dpi);
	u32(view, 280, dpi);
	u32(view, 340, Math.max(1, settings.copies));
	u32(view, 352, Math.round(pts.width));
	u32(view, 356, Math.round(pts.height));
	u32(view, 368, settings.duplex === "SHORT_EDGE" ? 1 : 0);
	u32(view, 372, page.width);
	u32(view, 376, page.height);
	u32(view, 384, 8);
	u32(view, 388, bpp);
	u32(view, 392, bpl);
	u32(view, 396, 0);
	u32(view, 400, opts.mono ? 18 : 19);
	u32(view, 404, 0);
	u32(view, 420, opts.mono ? 1 : 3);
	f32(view, 428, pts.width);
	f32(view, 432, pts.height);
	cstr(bytes, 1668, "relative", 64);
	cstr(bytes, 1732, pts.mediaKeyword, 64);
	return bytes;
}
function pagePixels$1(page, mono) {
	const { width: w, height: h, data } = page;
	if (mono) {
		const out = new Uint8Array(w * h);
		for (let i = 0; i < w * h; i++) {
			const o = i * 4;
			out[i] = Math.round(data[o] * .299 + data[o + 1] * .587 + data[o + 2] * .114);
		}
		return out;
	}
	const out = new Uint8Array(w * h * 3);
	for (let i = 0; i < w * h; i++) {
		const s = i * 4;
		const d = i * 3;
		out[d] = data[s];
		out[d + 1] = data[s + 1];
		out[d + 2] = data[s + 2];
	}
	return out;
}
var Bytes = class {
	buf = /* @__PURE__ */ new Uint8Array(4096);
	n = 0;
	push(...v) {
		this.ensure(v.length);
		for (const x of v) this.buf[this.n++] = x;
	}
	pushArr(a) {
		this.ensure(a.length);
		this.buf.set(a, this.n);
		this.n += a.length;
	}
	ensure(extra) {
		if (this.n + extra <= this.buf.length) return;
		let size = this.buf.length;
		while (size < this.n + extra) size *= 2;
		const next = new Uint8Array(size);
		next.set(this.buf.subarray(0, this.n));
		this.buf = next;
	}
	result() {
		return this.buf.subarray(0, this.n);
	}
};
function samePixel(line, a, b, bpp) {
	for (let k = 0; k < bpp; k++) if (line[a * bpp + k] !== line[b * bpp + k]) return false;
	return true;
}
/** PWG Raster 한 줄: 같은 픽셀 반복(0..127 = n+1번) 또는 직접 나열(−1..−127 = 1−c개). */
function packPwgLine(line, bpp, out) {
	const px = line.length / bpp;
	let i = 0;
	while (i < px) {
		let run = 1;
		while (i + run < px && run < 128 && samePixel(line, i, i + run, bpp)) run++;
		if (run >= 2) {
			out.push(run - 1);
			out.pushArr(line.subarray(i * bpp, i * bpp + bpp));
			i += run;
			continue;
		}
		let lit = 1;
		while (i + lit < px && lit < 128 && !(i + lit + 1 < px && samePixel(line, i + lit, i + lit + 1, bpp))) lit++;
		if (lit === 1) out.push(0);
		else out.push(1 - lit & 255);
		out.pushArr(line.subarray(i * bpp, (i + lit) * bpp));
		i += lit;
	}
}
/** 한 페이지: 같은 줄이 이어지면 반복 횟수(최대 256)를 앞에 붙이고 한 번만 쓴다. */
function compressPwgPage(pixels, width, height, bpp) {
	const out = new Bytes();
	const bpl = width * bpp;
	let y = 0;
	while (y < height) {
		const line = pixels.subarray(y * bpl, y * bpl + bpl);
		let repeat = 1;
		while (y + repeat < height && repeat < 256) {
			const next = pixels.subarray((y + repeat) * bpl, (y + repeat) * bpl + bpl);
			let same = true;
			for (let k = 0; k < bpl; k++) if (line[k] !== next[k]) {
				same = false;
				break;
			}
			if (!same) break;
			repeat++;
		}
		out.push(repeat - 1);
		packPwgLine(line, bpp, out);
		y += repeat;
	}
	return out.result();
}
function pwgPage(page, settings, opts) {
	const header = writeHeader(page, settings, opts);
	const body = compressPwgPage(pagePixels$1(page, opts.mono), page.width, page.height, opts.mono ? 1 : 3);
	const out = new Uint8Array(header.length + body.length);
	out.set(header, 0);
	out.set(body, header.length);
	return out;
}
/** PWG Raster 5102.4: "RaS2" 동기 단어 + (페이지 헤더 + 압축된 줄)들. */
function encodePwgRaster(pages, settings, opts) {
	const dpi = opts.dpi ?? 100;
	const chunks = [new TextEncoder().encode("RaS2")];
	for (const page of pages) chunks.push(pwgPage(page, settings, {
		mono: opts.mono,
		dpi
	}));
	let total = 0;
	for (const c of chunks) total += c.length;
	const out = new Uint8Array(total);
	let o = 0;
	for (const c of chunks) {
		out.set(c, o);
		o += c.length;
	}
	return out;
}
var PWG_MIME = "image/pwg-raster";
var PS_MIME = "application/postscript";
/** Adobe ASCII85 (z 단축 없이). 모든 PostScript 프린터가 읽는다. */
function ascii85(bytes) {
	const lines = [];
	let line = "";
	const flush = (s) => {
		line += s;
		while (line.length >= 72) {
			lines.push(line.slice(0, 72));
			line = line.slice(72);
		}
	};
	for (let i = 0; i < bytes.length; i += 4) {
		const n = Math.min(4, bytes.length - i);
		let v = 0;
		for (let k = 0; k < 4; k++) v = v * 256 + (k < n ? bytes[i + k] : 0);
		const chars = [];
		for (let k = 4; k >= 0; k--) {
			chars[k] = String.fromCharCode(33 + v % 85);
			v = Math.floor(v / 85);
		}
		flush(chars.slice(0, n + 1).join(""));
	}
	if (line) lines.push(line);
	return `${lines.join("\n")}~>\n`;
}
function pixelData(page, mono) {
	const { width: w, height: h, data } = page;
	if (mono) {
		const out = new Uint8Array(w * h);
		for (let i = 0; i < w * h; i++) {
			const o = i * 4;
			out[i] = Math.round(data[o] * .299 + data[o + 1] * .587 + data[o + 2] * .114);
		}
		return out;
	}
	const out = new Uint8Array(w * h * 3);
	for (let i = 0; i < w * h; i++) {
		out[i * 3] = data[i * 4];
		out[i * 3 + 1] = data[i * 4 + 1];
		out[i * 3 + 2] = data[i * 4 + 2];
	}
	return out;
}
/** PostScript Level 2: 페이지마다 setpagedevice로 용지·양면·매수를 정하고 래스터를 그린다. */
function encodePostScript(pages, settings, opts) {
	const pts = pageSizePoints(settings.paper, settings.orientation);
	const pw = pts.width.toFixed(2);
	const ph = pts.height.toFixed(2);
	const duplex = settings.duplex !== "NONE";
	const tumble = settings.duplex === "SHORT_EDGE";
	const copies = Math.max(1, Math.min(99, settings.copies));
	const parts = [`%!PS-Adobe-3.0\n%%Pages: ${pages.length}\n%%EndComments\n`];
	pages.forEach((page, i) => {
		const space = opts.mono ? "/DeviceGray" : "/DeviceRGB";
		const decode = opts.mono ? "[0 1]" : "[0 1 0 1 0 1]";
		parts.push(`%%Page: ${i + 1} ${i + 1}\n<< /PageSize [${pw} ${ph}] /NumCopies ${copies} /Duplex ${duplex} /Tumble ${tumble} >> setpagedevice\ngsave\n${pw} ${ph} scale\n${space} setcolorspace\n<< /ImageType 1 /Width ${page.width} /Height ${page.height} /BitsPerComponent 8 /Decode ${decode}\n/ImageMatrix [${page.width} 0 0 -${page.height} 0 ${page.height}]\n/DataSource currentfile /ASCII85Decode filter >> image\n`, ascii85(pixelData(page, opts.mono)), "grestore\nshowpage\n");
	});
	parts.push("%%EOF\n");
	return new TextEncoder().encode(parts.join(""));
}
function pagePixels(paper, orientation, dpi) {
	const pts = pageSizePoints(paper, orientation);
	return {
		width: Math.max(32, Math.round(pts.width / 72 * dpi)),
		height: Math.max(32, Math.round(pts.height / 72 * dpi))
	};
}
function canvasContext(w, h) {
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d", {
		alpha: false,
		willReadFrequently: true
	});
	if (!ctx) throw new Error("canvas");
	ctx.fillStyle = "#ffffff";
	ctx.fillRect(0, 0, w, h);
	return {
		canvas,
		ctx
	};
}
function toPage(ctx, w, h) {
	return {
		width: w,
		height: h,
		data: ctx.getImageData(0, 0, w, h).data
	};
}
async function bitmapFromBlob(blob) {
	try {
		return await createImageBitmap(blob, { imageOrientation: "from-image" });
	} catch {
		return createImageBitmap(blob);
	}
}
/** 페이지를 한 장씩 만들어 넘긴다. 호출한 쪽이 변환 뒤 바로 버리면 메모리를 아낄 수 있다. */
async function* rasterPages(source, settings, dpi = dpiForQuality(settings.quality), signal) {
	const abortIfNeeded = () => {
		if (signal?.aborted) throw new DOMException("aborted", "AbortError");
	};
	if (source.images && source.images.length > 0) {
		const target = pagePixels(settings.paper, settings.orientation, dpi);
		const total = source.images.length;
		for (let i = 0; i < total; i++) {
			abortIfNeeded();
			const bmp = await bitmapFromBlob(source.images[i].blob);
			const width = Math.min(bmp.width, target.width);
			const height = Math.min(bmp.height, target.height);
			const { ctx } = canvasContext(width, height);
			ctx.drawImage(bmp, 0, 0, width, height);
			bmp.close();
			yield {
				page: toPage(ctx, width, height),
				progress: {
					done: i + 1,
					total
				}
			};
		}
		return;
	}
	const { loadPdf } = await import("./pdf-preview-CruXjyu-.mjs");
	const pdf = await loadPdf(source.pdf ?? /* @__PURE__ */ new Uint8Array());
	const { width, height } = pagePixels(settings.paper, settings.orientation, dpi);
	for (let n = 1; n <= pdf.numPages; n++) {
		abortIfNeeded();
		const page = await pdf.getPage(n);
		const unscaled = page.getViewport({ scale: 1 });
		const scale = Math.min(width / unscaled.width, height / unscaled.height);
		const viewport = page.getViewport({ scale });
		const { canvas, ctx } = canvasContext(width, height);
		ctx.translate((width - viewport.width) / 2, (height - viewport.height) / 2);
		await page.render({
			canvas,
			canvasContext: ctx,
			viewport
		}).promise;
		yield {
			page: toPage(ctx, width, height),
			progress: {
				done: n,
				total: pdf.numPages
			}
		};
	}
}
function shouldForceMono(settings, _printer) {
	return settings.color === "MONO";
}
function pickEngineFormat(printer) {
	if (!usesInAppEngine(printer)) return "pdf";
	if (printer.language === "pcl" || printer.language === "ps" || printer.language === "pwg") return printer.language;
	if (printer.protocol === "RAW9100") return "pcl";
	if (printer.lastMethod === "IPP_PWG") return "pwg";
	if (printer.lastMethod === "IPP_PCL") return "pcl";
	if (printer.lastMethod === "IPP_PS") return "ps";
	const pdl = (printer.pdl ?? []).map((p) => p.toLowerCase());
	if (pdl.some((p) => p.includes("pwg-raster"))) return "pwg";
	if (pdl.some((p) => p.includes("pcl") && !p.includes("pclm"))) return "pcl";
	if (pdl.some((p) => p.includes("postscript"))) return "ps";
	if (pdl.some((p) => p.includes("pwg"))) return "pwg";
	return "pcl";
}
function formatLabel(format) {
	if (format === "pwg") return "PWG Raster";
	if (format === "pcl") return "PCL";
	if (format === "ps") return "PostScript";
	return "PDF";
}
function formatMime(format) {
	if (format === "pwg") return PWG_MIME;
	if (format === "ps") return PS_MIME;
	if (format === "pcl") return PCL_MIME;
	return "application/pdf";
}
function formatExtension(format) {
	if (format === "pwg") return "pwg";
	if (format === "ps") return "ps";
	return "prn";
}
/**
* 한 번에 변환하는 페이지 수. 양면이 쌍으로 맞도록 항상 짝수.
* 매수가 2장 이상이면 순서(1·2·3 · 1·2·3)가 섞이지 않게 쪼개지 않는다.
*/
function batchPageLimit(settings, mono, dpi) {
	if (settings.copies > 1) return Number.POSITIVE_INFINITY;
	if (mono) return 16;
	return dpi >= 150 ? 4 : 8;
}
function encodeBatch(format, pages, settings, mono, dpi) {
	if (format === "pwg") return encodePwgRaster(pages, settings, {
		mono,
		dpi
	});
	if (format === "ps") return encodePostScript(pages, settings, {
		mono,
		dpi
	});
	return encodePclJob(pages, settings, {
		mono,
		dpi
	});
}
/** 페이지를 한 장씩 만들고, 묶음이 차면 변환해서 내보낸다. 큰 문서도 메모리를 한꺼번에 쓰지 않는다. */
async function* convertBatches(source, printer, settings, opts = {}) {
	const format = pickEngineFormat(printer);
	if (format === "pdf") throw new Error("pdf");
	const dpi = dpiForQuality(settings.quality);
	const mono = shouldForceMono(settings, printer);
	const limit = batchPageLimit(settings, mono, dpi);
	const encodeSettings = opts.embedCopies === false ? {
		...settings,
		copies: 1
	} : settings;
	let batch = [];
	let index = 0;
	let done = 0;
	let total = 0;
	const make = (pages) => ({
		bytes: encodeBatch(format, pages, encodeSettings, mono, dpi),
		mime: formatMime(format),
		label: formatLabel(format),
		format,
		pages: opts.keepPages ? pages : [],
		pagesDone: done,
		pagesTotal: total,
		batchIndex: index++
	});
	for await (const { page, progress } of rasterPages(source, settings, dpi, opts.signal)) {
		done = progress.done;
		total = progress.total;
		opts.onPage?.(done, total);
		batch.push(page);
		if (batch.length >= limit) {
			yield make(batch);
			batch = [];
		}
	}
	if (batch.length > 0) yield make(batch);
}
function pageToJpegUrl(page, quality = .84) {
	const canvas = document.createElement("canvas");
	canvas.width = page.width;
	canvas.height = page.height;
	const ctx = canvas.getContext("2d", { alpha: false });
	if (!ctx) throw new Error("canvas");
	const image = ctx.createImageData(page.width, page.height);
	image.data.set(page.data);
	ctx.putImageData(image, 0, 0);
	return new Promise((resolve, reject) => {
		canvas.toBlob((blob) => {
			if (!blob) {
				reject(/* @__PURE__ */ new Error("jpeg"));
				return;
			}
			resolve(URL.createObjectURL(blob));
		}, "image/jpeg", quality);
	});
}
function mountPrintFrame(url) {
	const iframe = document.createElement("iframe");
	iframe.setAttribute("aria-hidden", "true");
	iframe.style.position = "fixed";
	iframe.style.inset = "0";
	iframe.style.width = "100%";
	iframe.style.height = "100%";
	iframe.style.border = "0";
	iframe.style.opacity = "0";
	iframe.style.pointerEvents = "none";
	iframe.src = url;
	document.body.appendChild(iframe);
	return iframe;
}
function printFrame(iframe, url) {
	try {
		iframe.contentWindow?.focus();
		iframe.contentWindow?.addEventListener("afterprint", () => iframe.remove());
		iframe.contentWindow?.print();
	} catch {
		window.open(url, "_blank");
	}
}
/** 결과 화면에서 사용자가 다시 누를 때. 클릭과 같은 턴에 창을 연다. */
function openPrintUrl(url) {
	const win = window.open(url, "_blank");
	if (!win) return false;
	win.addEventListener("load", () => {
		try {
			win.focus();
			win.print();
		} catch {}
	});
	return true;
}
/**
* In-app PC helper: hand raster pages to the OS print dialog, where old
* USB/driver printers already live. No extra install.
* 브라우저 인쇄 창은 매수를 모르므로 페이지 묶음을 매수만큼 반복한다.
*/
async function printRasterViaOs(pages, settings) {
	const urls = await Promise.all(pages.map((p) => pageToJpegUrl(p)));
	const pts = pageSizePoints(settings.paper, settings.orientation);
	const copies = Math.max(1, Math.min(99, settings.copies));
	const imgs = Array.from({ length: copies }, () => urls).flat().map((u) => `<img src="${u}" alt="" />`).join("");
	const html = `<!doctype html><html><head><meta charset="utf-8"><title>인쇄</title>
<style>
  @page { size: ${pts.width}pt ${pts.height}pt; margin: 0; }
  html, body { margin: 0; background: #fff; }
  img { display: block; width: 100%; page-break-after: always; break-after: page; }
  img:last-child { page-break-after: auto; break-after: auto; }
</style></head><body>${imgs}</body></html>`;
	const blob = new Blob([html], { type: "text/html" });
	const url = URL.createObjectURL(blob);
	const iframe = mountPrintFrame(url);
	iframe.addEventListener("load", () => {
		const frames = Array.from(iframe.contentDocument?.images ?? []);
		Promise.all(frames.map((img) => img.decode().catch(() => void 0))).then(() => printFrame(iframe, url));
	});
	return {
		url,
		revoke: () => {
			for (const u of urls) URL.revokeObjectURL(u);
		}
	};
}
function blobDownloadUrl(bytes, mime) {
	const copy = new Uint8Array(bytes.byteLength);
	copy.set(bytes);
	return URL.createObjectURL(new Blob([copy.buffer], { type: mime }));
}
function colorKeyword(color, printer) {
	if (color === "MONO") return "monochrome";
	if (color === "COLOR") return "color";
	if (printer.supportsColor === false) return "monochrome";
	return "auto";
}
function sidesKeyword(duplex) {
	if (duplex === "LONG_EDGE") return "two-sided-long-edge";
	if (duplex === "SHORT_EDGE") return "two-sided-short-edge";
	return "one-sided";
}
function mediaKeyword(paper, printer) {
	const want = pageSizePoints(resolvePaper(paper), "PORTRAIT").mediaKeyword;
	const supported = printer.mediaSupported;
	if (!supported || supported.length === 0) return want;
	return supported.includes(want) ? want : void 0;
}
function userName() {
	if (typeof navigator === "undefined") return "web";
	return (navigator.platform || "web").slice(0, 40);
}
async function printViaBrowser(pdf, copies = 1) {
	let bytes = pdf;
	if (copies > 1) {
		const { repeatPdfCopies } = await import("./image-to-pdf-CpJIrZTg.mjs");
		bytes = await repeatPdfCopies(pdf, copies);
	}
	const copy = new Uint8Array(bytes.byteLength);
	copy.set(bytes);
	const blob = new Blob([copy.buffer], { type: "application/pdf" });
	const url = URL.createObjectURL(blob);
	const iframe = document.createElement("iframe");
	iframe.setAttribute("aria-hidden", "true");
	iframe.style.position = "fixed";
	iframe.style.inset = "0";
	iframe.style.width = "100%";
	iframe.style.height = "100%";
	iframe.style.border = "0";
	iframe.style.opacity = "0";
	iframe.style.pointerEvents = "none";
	iframe.src = url;
	document.body.appendChild(iframe);
	iframe.addEventListener("load", () => {
		try {
			iframe.contentWindow?.focus();
			iframe.contentWindow?.print();
		} catch {
			window.open(url, "_blank");
		}
	});
	return { url };
}
async function simulateSend(printer, document, mime, settings, jobName, onProgress, signal) {
	onProgress({
		percent: 70,
		label: "변환된 작업을 전송 중…"
	});
	const packet = buildPrintJob({
		printerUri: printerUri(printer.host, printer.port, printer.resourcePath, printer.secure),
		requestId: 2,
		jobName,
		userName: userName(),
		copies: settings.copies,
		documentFormat: mime,
		colorMode: colorKeyword(settings.color, printer),
		sides: settings.duplex === "NONE" ? void 0 : sidesKeyword(settings.duplex),
		media: mediaKeyword(settings.paper, printer),
		document
	});
	onProgress({
		percent: 92,
		label: "응답 확인 중…"
	});
	return {
		status: "SUCCESS",
		packetBytes: packet.byteLength,
		printer
	};
}
async function collectRasterPages(source, settings, signal) {
	const pages = [];
	for await (const { page } of rasterPages(source, settings, dpiForQuality(settings.quality), signal)) pages.push(page);
	return pages;
}
async function sendIpp(printer, bytes, mime, settings, jobName, signal) {
	const options = {
		copies: settings.copies,
		jobName,
		userName: userName(),
		documentFormat: mime,
		colorMode: colorKeyword(settings.color, printer),
		sides: settings.duplex === "NONE" ? void 0 : sidesKeyword(settings.duplex),
		media: mediaKeyword(settings.paper, printer),
		signal
	};
	try {
		return await printJob(printer, bytes, options);
	} catch (err) {
		if (err instanceof JobError && err.code === "TIMEOUT") {
			await wakePrinter(printer, {
				signal,
				force: true
			}).catch(() => void 0);
			try {
				return await printJob(printer, bytes, options);
			} catch {
				throw err;
			}
		}
		throw err;
	}
}
/** 보낸 작업이 끝났는지 잠시 지켜본다. 확실한 프린터 문제(용지·토너·덮개·걸림)만 오류로 올린다. */
async function watchSentJob(printer, jobId, onProgress, signal) {
	if (jobId === void 0) return "unknown";
	onProgress({
		percent: 94,
		label: "프린터 상태 확인 중…"
	});
	const watch = await watchJob(() => getJobSnapshot(printer, jobId, signal), {
		signal,
		timeoutMs: 2e4,
		onTick: (w) => {
			if (w.kind === "working") onProgress({
				percent: 96,
				label: "프린터가 인쇄하는 중…"
			});
		}
	});
	if (watch.kind === "failed") throw new JobError(watch.code, watch.code);
	if (watch.kind === "done") return "completed";
	return watch.kind === "working" ? "processing" : "unknown";
}
async function submitPrintJob(opts) {
	const { printer, pdf, images, settings, jobName, onProgress, signal } = opts;
	const source = {
		pdf,
		images
	};
	if (typeof navigator !== "undefined" && navigator.onLine === false && printer.source !== "LOCAL") throw new JobError("NO_NETWORK", "NO_NETWORK");
	onProgress({
		percent: 8,
		label: printer.source === "LOCAL" ? "문서 준비 중…" : "절전 깨우기 · 문서 준비"
	});
	const engine = usesInAppEngine(printer);
	const wakeP = printer.source === "LOCAL" ? Promise.resolve({
		woke: false,
		skipped: true
	}) : wakePrinter(printer, { signal }).catch(() => ({
		woke: false,
		skipped: false
	}));
	const onPage = (done, total) => onProgress({
		percent: 20 + Math.round(35 * done / Math.max(1, total)),
		label: `페이지 변환 중 (${done}/${total}쪽)`
	});
	const formatName = formatLabel(pickEngineFormat(printer));
	if (!engine && (!pdf || pdf.byteLength === 0)) throw new JobError("REJECTED", "REJECTED");
	if (printer.source === "LOCAL") {
		onProgress({
			percent: 72,
			label: engine ? "이 컴퓨터 드라이버로 넘기는 중…" : "이 컴퓨터 인쇄 대화상자 여는 중…"
		});
		if (engine) {
			const helper = await printRasterViaOs(await collectRasterPages(source, settings, signal), settings);
			onProgress({
				percent: 100,
				label: "인쇄 대화상자를 열었습니다."
			});
			return {
				status: "SUCCESS",
				printer,
				usedLocalDialog: true,
				usedHelper: true,
				convertedFormat: formatName,
				downloadUrl: helper.url,
				downloadName: "print.html"
			};
		}
		const { url } = await printViaBrowser(pdf, settings.copies);
		onProgress({
			percent: 100,
			label: "인쇄 대화상자를 열었습니다."
		});
		return {
			status: "SUCCESS",
			printer,
			usedLocalDialog: true,
			downloadUrl: url,
			downloadName: "print.pdf"
		};
	}
	if (!(await wakeP).skipped) onProgress({
		percent: 48,
		label: "절전에서 깨웠습니다"
	});
	if (printer.source === "DEMO") {
		if (!engine) return simulateSend(printer, pdf, "application/pdf", settings, jobName, onProgress, signal);
		const chunks = [];
		let packetBytes = 0;
		let mime = formatMime(pickEngineFormat(printer));
		for await (const batch of convertBatches(source, printer, settings, {
			signal,
			onPage,
			embedCopies: false
		})) {
			const sent = await simulateSend(printer, batch.bytes, batch.mime, settings, jobName, onProgress, signal);
			packetBytes += sent.packetBytes ?? 0;
			chunks.push(batch.bytes);
			mime = batch.mime;
		}
		const all = new Uint8Array(chunks.reduce((n, c) => n + c.length, 0));
		let o = 0;
		for (const c of chunks) {
			all.set(c, o);
			o += c.length;
		}
		return {
			status: "SUCCESS",
			printer,
			packetBytes,
			convertedFormat: formatName,
			downloadUrl: blobDownloadUrl(all, mime),
			downloadName: `print.${formatExtension(pickEngineFormat(printer))}`
		};
	}
	if (printer.protocol === "RAW9100") {
		let sentPages = 0;
		let totalPages = 0;
		let onlyBatch = null;
		let batches = 0;
		let stopped = false;
		for await (const batch of convertBatches(source, printer, settings, {
			signal,
			onPage
		})) {
			totalPages = batch.pagesTotal;
			onProgress({
				percent: 68,
				label: `PC 도우미로 구형 프린터에 전송 중 (${batch.pagesDone}/${totalPages}쪽)`
			});
			if (!await helperSend(printer.host, printer.port || 9100, batch.bytes, signal)) {
				stopped = true;
				break;
			}
			sentPages = batch.pagesDone;
			batches++;
			onlyBatch = batches === 1 ? batch : null;
		}
		if (!stopped && batches > 0) {
			onProgress({
				percent: 100,
				label: "전송했습니다"
			});
			return {
				status: "SUCCESS",
				printer,
				directRaw: true,
				convertedFormat: formatName,
				packetBytes: onlyBatch?.bytes.byteLength,
				downloadUrl: onlyBatch ? blobDownloadUrl(onlyBatch.bytes, onlyBatch.mime) : void 0,
				downloadName: onlyBatch ? `print.${formatExtension(onlyBatch.format)}` : void 0
			};
		}
		if (stopped && sentPages > 0) return {
			status: "PARTIAL",
			printer,
			directRaw: true,
			convertedFormat: formatName,
			sentPages,
			totalPages,
			error: "TIMEOUT"
		};
		onProgress({
			percent: 84,
			label: "앱 도우미 · 이 컴퓨터 드라이버"
		});
		await printRasterViaOs(await collectRasterPages(source, settings, signal), settings);
		onProgress({
			percent: 100,
			label: "드라이버로 넘겼습니다"
		});
		return {
			status: "SUCCESS",
			printer,
			usedHelper: true,
			convertedFormat: formatName
		};
	}
	onProgress({
		percent: 58,
		label: "프린터 속성 확인 중…"
	});
	let resolved = printer;
	try {
		resolved = applyAttributes(printer, await getPrinterAttributes(printer, signal));
	} catch (err) {
		if (err instanceof JobError && err.code === "NO_NETWORK") throw err;
		if (!engine) {
			if (err instanceof JobError) throw err;
			throw new JobError("TIMEOUT", "TIMEOUT");
		}
	}
	async function viaEngine(target) {
		const name = formatLabel(pickEngineFormat(target));
		let sentPages = 0;
		let totalPages = 0;
		let packetBytes = 0;
		let lastJobId;
		for await (const batch of convertBatches(source, target, settings, {
			signal,
			onPage,
			embedCopies: false
		})) {
			totalPages = batch.pagesTotal;
			onProgress({
				percent: 60 + Math.round(30 * batch.pagesDone / Math.max(1, totalPages)),
				label: `${name} 전송 중 (${batch.pagesDone}/${totalPages}쪽)`
			});
			try {
				const sent = await sendIpp(target, batch.bytes, batch.mime, settings, jobName, signal);
				packetBytes += sent.byteLength;
				lastJobId = sent.jobId;
				sentPages = batch.pagesDone;
			} catch (err) {
				if (err instanceof JobError && err.code === "UNSUPPORTED_FORMAT" && batch.batchIndex === 0) {
					onProgress({
						percent: 86,
						label: "앱 도우미 · 이 컴퓨터 드라이버"
					});
					await printRasterViaOs(await collectRasterPages(source, settings, signal), settings);
					return {
						status: "SUCCESS",
						printer: target,
						usedHelper: true,
						convertedFormat: name
					};
				}
				if (sentPages > 0 && err instanceof JobError) return {
					status: "PARTIAL",
					printer: target,
					convertedFormat: name,
					sentPages,
					totalPages,
					error: err.code
				};
				throw err;
			}
		}
		const jobState = await watchSentJob(target, lastJobId, onProgress, signal);
		onProgress({
			percent: 100,
			label: "전송 완료"
		});
		return {
			status: "SUCCESS",
			printer: target,
			convertedFormat: name,
			packetBytes,
			jobState
		};
	}
	if (usesInAppEngine(resolved)) return viaEngine(resolved);
	onProgress({
		percent: 78,
		label: "Print-Job 전송 중…"
	});
	try {
		const sent = await sendIpp(resolved, pdf, "application/pdf", settings, jobName, signal);
		const jobState = await watchSentJob(resolved, sent.jobId, onProgress, signal);
		onProgress({
			percent: 100,
			label: "전송 완료"
		});
		return {
			status: "SUCCESS",
			printer: resolved,
			packetBytes: sent.byteLength,
			jobState
		};
	} catch (err) {
		if (err instanceof JobError && err.code === "UNSUPPORTED_FORMAT") {
			onProgress({
				percent: 64,
				label: "PDF 미지원 · 앱 변환 엔진 작동"
			});
			return viaEngine({
				...resolved,
				supportsPdf: false
			});
		}
		if (err instanceof JobError) throw err;
		throw new JobError("TIMEOUT", "TIMEOUT");
	}
}
function ProgressScreen() {
	const go = useAppStore((s) => s.go);
	const session = useAppStore((s) => s.session);
	const printers = useAppStore((s) => s.printers);
	const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
	const setResult = useAppStore((s) => s.setResult);
	const addJob = useAppStore((s) => s.addJob);
	const markSuccess = useAppStore((s) => s.markSuccess);
	const setPdfBytes = useAppStore((s) => s.setPdfBytes);
	const printer = printers.find((p) => p.id === selectedPrinterId);
	const [percent, setPercent] = (0, import_react.useState)(0);
	const [label, setLabel] = (0, import_react.useState)("준비 중…");
	const abortRef = (0, import_react.useRef)(null);
	const userCancel = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (!session || !printer) {
			go("home");
			return;
		}
		const ac = new AbortController();
		abortRef.current = ac;
		(async () => {
			try {
				let pdf = session.pdfBytes;
				let images = session.images;
				if (usesInAppEngine(printer)) {
					if (session.kind === "test") {
						setLabel("앱 변환 엔진 · 테스트 페이지");
						if (session.previewUrl) {
							const blob = await fetch(session.previewUrl).then((r) => r.blob());
							images = [{
								name: "test.jpg",
								url: session.previewUrl,
								blob
							}];
						} else {
							const { renderTestPageJpeg } = await import("./test-page-Dnk1WEz9.mjs");
							const device = `${navigator.platform || "web"} · ${navigator.language}`;
							const jpeg = await renderTestPageJpeg(printer, device, /* @__PURE__ */ new Date(), {
								scale: 1.15,
								quality: .8
							});
							const copy = new Uint8Array(jpeg.byteLength);
							copy.set(jpeg);
							images = [{
								name: "test.jpg",
								url: "",
								blob: new Blob([copy.buffer], { type: "image/jpeg" })
							}];
						}
						pdf = null;
					} else if (session.kind === "image") {
						setLabel("앱 변환 엔진 · 사진");
						pdf = null;
					}
				} else {
					if (!pdf && session.kind === "image") {
						setLabel("사진으로 PDF 만드는 중…");
						const { imagesToPdf } = await import("./image-to-pdf-CpJIrZTg.mjs");
						pdf = await imagesToPdf(session.images, session.settings);
						setPdfBytes(pdf, session.images.length);
					}
					if (!pdf && session.kind === "test") {
						setLabel("테스트 페이지 만드는 중…");
						const { buildTestPagePdf } = await import("./test-page-Dnk1WEz9.mjs");
						pdf = await buildTestPagePdf(printer);
						setPdfBytes(pdf, 1);
					}
					if (!pdf) throw new JobError("REJECTED", "REJECTED");
				}
				const result = await submitPrintJob({
					printer,
					pdf,
					images,
					settings: session.settings,
					jobName: session.kind === "test" ? "연결-테스트" : "print-job",
					onProgress: (p) => {
						setPercent(p.percent);
						setLabel(p.label);
					},
					signal: ac.signal
				});
				if (ac.signal.aborted) return;
				addJob({
					id: crypto.randomUUID(),
					printerId: printer.id,
					printerName: printer.displayName,
					documentKind: session.kind,
					copies: session.settings.copies,
					status: result.status,
					error: result.error,
					at: Date.now()
				});
				if (result.status === "SUCCESS") markSuccess(printer.id, {
					method: methodFromResult(result),
					settings: session.kind === "test" ? void 0 : rememberSettings(session.settings)
				});
				setResult({
					status: result.status,
					printerName: printer.displayName,
					usedLocalDialog: result.usedLocalDialog,
					usedHelper: result.usedHelper,
					directRaw: result.directRaw,
					error: result.error,
					jobState: result.jobState,
					sentPages: result.sentPages,
					totalPages: result.totalPages,
					convertedFormat: result.convertedFormat,
					downloadUrl: result.downloadUrl,
					downloadName: result.downloadName,
					packetBytes: result.packetBytes
				});
				go("result");
			} catch (err) {
				if (err?.name === "AbortError") {
					if (userCancel.current) go("preview");
					return;
				}
				const code = err instanceof JobError ? err.code : "TIMEOUT";
				addJob({
					id: crypto.randomUUID(),
					printerId: printer.id,
					printerName: printer.displayName,
					documentKind: session.kind,
					copies: session.settings.copies,
					status: "FAILURE",
					error: code,
					at: Date.now()
				});
				setResult({
					status: "FAILURE",
					error: code,
					printerName: printer.displayName
				});
				go("result");
			}
		})();
		return () => {
			ac.abort();
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, {
		className: "items-center justify-center text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "보내는 중"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 font-mono text-6xl font-medium tabular-nums tracking-tight",
				children: [percent, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-2xl text-subtle",
					children: "%"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 h-px w-full max-w-xs bg-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-px bg-accent",
					style: { width: `${percent}%` }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-sm text-subtle",
				children: printer?.displayName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				className: "mt-10",
				onClick: () => {
					userCancel.current = true;
					abortRef.current?.abort();
					go("preview");
				},
				children: "취소"
			})
		]
	}) });
}
/**
* 복사.
* 미리보기 iframe은 Clipboard API를 막는 경우가 많다.
* writeText를 기다린 뒤에 execCommand를 부르면 클릭 제스처가 사라져 둘 다 실패하므로,
* 둘 다 클릭과 같은 턴에 시작한다.
*/
async function copyText(text) {
	const modern = startClipboardWrite(text);
	const legacy = copyWithCommand(text);
	return await modern || legacy;
}
function startClipboardWrite(text) {
	try {
		if (typeof navigator === "undefined" || !navigator.clipboard?.writeText || !window.isSecureContext) return Promise.resolve(false);
		return navigator.clipboard.writeText(text).then(() => true, () => false);
	} catch {
		return Promise.resolve(false);
	}
}
function copyWithCommand(text) {
	if (typeof document === "undefined") return false;
	let injected = false;
	const onCopy = (event) => {
		try {
			event.preventDefault();
			event.clipboardData?.setData("text/plain", text);
			injected = true;
		} catch {}
	};
	document.addEventListener("copy", onCopy, true);
	const area = document.createElement("textarea");
	area.value = text;
	area.setAttribute("readonly", "");
	area.setAttribute("aria-hidden", "true");
	area.tabIndex = -1;
	area.style.position = "fixed";
	area.style.top = "0";
	area.style.left = "0";
	area.style.width = "2em";
	area.style.height = "2em";
	area.style.padding = "0";
	area.style.border = "none";
	area.style.outline = "none";
	area.style.boxShadow = "none";
	area.style.background = "transparent";
	area.style.fontSize = "16px";
	document.body.appendChild(area);
	const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
	area.focus({ preventScroll: true });
	area.select();
	area.setSelectionRange(0, text.length);
	let ok = false;
	try {
		ok = document.execCommand("copy");
	} catch {
		ok = false;
	} finally {
		document.removeEventListener("copy", onCopy, true);
		area.remove();
		previous?.focus({ preventScroll: true });
	}
	return ok || injected;
}
/** 자동 복사가 막히면 글을 그대로 보여 주고 선택해 둔다. */
function CopyBlock({ text, label }) {
	const [state, setState] = (0, import_react.useState)("idle");
	const areaRef = (0, import_react.useRef)(null);
	async function onCopy() {
		const ok = await copyText(text);
		setState(ok ? "ok" : "manual");
		if (!ok) requestAnimationFrame(() => {
			const area = areaRef.current;
			if (!area) return;
			area.focus({ preventScroll: true });
			area.select();
		});
		else window.setTimeout(() => setState("idle"), 2e3);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "secondary",
			className: "w-full",
			onClick: () => void onCopy(),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), state === "ok" ? "복사했습니다" : label]
		}), state === "manual" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs leading-relaxed text-muted",
			children: "이 화면에서는 자동 복사가 막혀 있습니다. 아래 글이 선택되어 있으니 복사만 누르세요."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
			ref: areaRef,
			readOnly: true,
			value: text,
			onFocus: (e) => e.currentTarget.select(),
			className: "min-h-28 w-full resize-none rounded-md border border-border bg-surface p-3 font-mono text-xs leading-relaxed text-fg"
		})] }) : null]
	});
}
function ResultScreen() {
	const go = useAppStore((s) => s.go);
	const result = useAppStore((s) => s.result);
	const session = useAppStore((s) => s.session);
	const setSession = useAppStore((s) => s.setSession);
	const ok = result?.status === "SUCCESS";
	const code = result?.error;
	const partial = result?.status === "PARTIAL";
	const problem = Boolean(code && PRINTER_PROBLEM_CODES.includes(code));
	const duplex = session?.settings.duplex;
	const [printNote, setPrintNote] = (0, import_react.useState)(null);
	const detail = [
		"누구나프린트 인쇄 오류",
		`프린터: ${result?.printerName ?? "-"}`,
		`코드: ${code ?? "-"}`,
		code ? `내용: ${JOB_ERROR_MESSAGE[code]}` : "내용: 인쇄를 완료하지 못했습니다.",
		code ? `안내: ${JOB_ERROR_HINT[code]}` : "",
		`시각: ${(/* @__PURE__ */ new Date()).toLocaleString("ko-KR")}`
	].filter(Boolean).join("\n");
	function home() {
		setSession(null);
		go("home");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneFrame, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, {
		className: "items-stretch",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-1 flex-col items-center justify-center text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: ok ? "flex size-14 items-center justify-center rounded-full bg-accent-soft text-accent" : "flex size-14 items-center justify-center rounded-full bg-surface-2 text-danger",
						children: ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
							className: "size-7",
							strokeWidth: 1.7
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {
							className: "size-7",
							strokeWidth: 1.7
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 text-3xl font-medium tracking-tight",
						children: ok ? "보냈습니다" : partial ? "일부만 보냈습니다" : problem ? "프린터에 문제가 있습니다" : "보내지 못했습니다"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm text-base leading-relaxed text-muted",
						children: ok ? result?.directRaw ? `${result.printerName}에 ${result.convertedFormat ?? "PCL"} 데이터를 PC 도우미로 직접 보냈습니다.` : result?.usedHelper ? `${result.printerName} · 앱 변환 엔진이 ${result.convertedFormat ?? "PCL"}로 바꿔 이 컴퓨터 드라이버로 넘겼습니다.` : result?.convertedFormat ? `${result.printerName}에 ${result.convertedFormat} 변환 작업을 전달했습니다.` : result?.usedLocalDialog ? `${result.printerName}의 인쇄 창입니다. 안 열리면 아래 버튼으로 다시 여세요.` : `${result?.printerName}으로 작업을 전달했습니다.` : partial ? `${result?.sentPages ?? 0}/${result?.totalPages ?? 0}쪽까지 보냈고 나머지는 보내지 못했습니다.${code ? ` ${JOB_ERROR_MESSAGE[code]}` : ""}` : code ? JOB_ERROR_MESSAGE[code] : "인쇄를 완료하지 못했습니다."
					}),
					!ok && code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm text-sm leading-relaxed text-subtle",
						children: JOB_ERROR_HINT[code]
					}) : null,
					ok && result?.jobState === "completed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-subtle",
						children: "프린터가 인쇄를 마쳤다고 알려왔습니다."
					}) : null,
					ok && result?.jobState === "processing" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-subtle",
						children: "프린터가 작업을 받아 인쇄하는 중입니다."
					}) : null,
					ok && result?.convertedFormat ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs text-subtle",
						children: [
							"앱 변환 엔진 · ",
							result.convertedFormat,
							duplex && duplex !== "NONE" ? ` · 양면 ${duplex === "SHORT_EDGE" ? "짧은 변" : "긴 변"}` : ""
						]
					}) : null,
					ok && result?.packetBytes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 font-mono text-xs text-subtle",
						children: [
							result.convertedFormat ? result.convertedFormat : "IPP",
							" ",
							result.packetBytes.toLocaleString("ko-KR"),
							"바이트"
						]
					}) : null
				]
			}),
			!ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, {
						text: detail,
						label: "오류 내용 복사"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm font-medium",
						children: "다른 방법"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "w-full",
						onClick: () => go("printers"),
						children: "다시 검색"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "w-full",
						onClick: () => go("add-printer"),
						children: "IP 수동 추가"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "w-full",
						onClick: () => {
							useAppStore.getState().selectPrinter("local-device");
							go("preview");
						},
						children: "이 컴퓨터로 인쇄"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-1 text-xs leading-relaxed text-subtle",
						children: "구형기는 앱 안 변환 엔진이 처리합니다. 이 컴퓨터로 인쇄하면 깔려 있는 드라이버를 씁니다."
					})
				]
			}) : null,
			result?.usedLocalDialog && result.downloadUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mb-3 w-full",
				onClick: () => {
					const opened = openPrintUrl(result.downloadUrl);
					setPrintNote(opened ? null : "창이 막혔습니다. 아래 파일을 저장한 뒤 인쇄하세요.");
				},
				children: ["인쇄 창 열기", session && session.settings.copies > 1 ? ` · ${session.settings.copies}매` : ""]
			}) : null,
			printNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-3 text-sm text-danger",
				children: printNote
			}) : null,
			result?.downloadUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: result.downloadUrl,
				download: result.downloadName ?? "print.pdf",
				className: "mb-3 inline-flex h-12 items-center justify-center gap-2 rounded-md border border-border bg-surface text-sm font-medium",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), result.downloadName?.endsWith(".prn") || result.downloadName?.endsWith(".pwg") || result.downloadName?.endsWith(".ps") ? "변환 파일 저장" : "파일 저장"]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "w-full",
				onClick: home,
				variant: ok && result?.usedLocalDialog ? "secondary" : "default",
				children: ok ? "홈으로" : "닫기"
			})
		]
	}) });
}
function SettingsScreen() {
	const go = useAppStore((s) => s.go);
	const jobs = useAppStore((s) => s.jobs);
	const clearJobs = useAppStore((s) => s.clearJobs);
	const [helper, setHelper] = (0, import_react.useState)(null);
	const [code, setCode] = (0, import_react.useState)(getHelperCode());
	(0, import_react.useEffect)(() => {
		let live = true;
		helperState().then((s) => live && setHelper(s));
		return () => {
			live = false;
		};
	}, []);
	async function connect() {
		setHelperCode(code);
		setHelper(await helperState());
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PhoneFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "설정",
		onBack: () => go("home")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, {
		className: "gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-medium tracking-tight",
				children: "누구나프린트"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "이 기기에만 저장됩니다."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "변환 엔진"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-relaxed text-muted",
				children: "PCL · PWG Raster 변환기가 앱 안에 들어 있습니다. 구형 사무기를 위해 따로 프로그램을 받지 않습니다."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-medium",
					children: [
						"PC 도우미 (선택) ·",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: helper === "ready" ? "text-accent" : "text-subtle",
							children: helper === null ? "확인 중" : helper === "ready" ? "연결됨" : helper === "needs-code" ? "연결 코드 필요" : "꺼져 있음"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-relaxed text-muted",
					children: "9100번 구형 프린터에 변환한 데이터를 곧바로 보냅니다. 꺼져 있으면 이 컴퓨터 드라이버로 인쇄합니다. Node 18 이상이 깔린 PC에서 파일을 받아 실행하면 6자리 연결 코드가 나옵니다. 아래에 한 번만 입력하세요."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: code,
						onChange: (e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6)),
						inputMode: "numeric",
						placeholder: "연결 코드 6자리",
						className: "field min-w-0 flex-1 font-mono tracking-widest"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "secondary",
						className: "h-11",
						onClick: connect,
						disabled: code.length !== 6,
						children: "연결"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex flex-col gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/raw-print-helper.mjs",
						download: "raw-print-helper.mjs",
						className: "inline-flex h-11 items-center justify-center rounded-md border border-border bg-surface text-sm font-medium",
						children: "도우미 파일 받기"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, {
						text: "node raw-print-helper.mjs",
						label: "실행 명령 복사"
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "연결 층"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-2 space-y-2 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "1층 IPP"
					}), " — PDF를 받는 AirPrint/Mopria/IPP Everywhere. 그대로 보냅니다."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "2층 변환 엔진"
					}), " — 앱에 내장. PDF를 못 받는 구형기는 PCL 또는 PWG Raster로 바꿔 보냅니다. 따로 설치하지 않습니다."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "3층 이 컴퓨터 드라이버"
					}), " — 앱 도우미가 변환한 페이지를 이 기기에 깔린 프린터 드라이버로 넘깁니다."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "4층 PC 도우미(선택)"
					}), " — 9100번 구형기에 변환한 데이터를 직접 보냅니다. 꺼져 있으면 3층으로 넘어갑니다."] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-fg",
						children: "절전 깨우기"
					}), " — 인쇄 전에 IPP · 웹으로 신호를 보냅니다. 잠든 사무기도 알아서 일어납니다."] })
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "앱"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: "오픈소스 라이선스",
						onClick: () => go("licenses")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
						label: `최근 작업 삭제 (${jobs.length})`,
						onClick: clearJobs
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: "사진과 PDF, 매수, 용지, 양면, 테스트 페이지, 같은 망 검색, 구형기 PCL 변환까지 이 화면에서 처리합니다. 집 안 이름을 자동으로 듣거나 USB를 직접 여는 것은 브라우저가 막습니다."
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "secondary",
				className: "mt-auto w-full",
				onClick: () => go("home"),
				children: "닫기"
			})
		]
	})] });
}
function LicensesScreen() {
	const go = useAppStore((s) => s.go);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PhoneFrame, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopBar, {
		title: "라이선스",
		onBack: () => go("settings")
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScreenBody, {
		className: "gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: "누구나프린트"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Apache License 2.0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm leading-relaxed text-muted",
				children: "앱 본체는 Apache-2.0입니다. 변환 엔진(PCL/PWG Raster)은 앱 안에 포함되어 있으며 추가 설치가 없습니다."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium",
			children: "사용 라이브러리"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-2 space-y-1 text-sm text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "pdf-lib — MIT" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "pdfjs-dist — Apache-2.0" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "React / TanStack — MIT" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Lucide — ISC" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Zustand — MIT" })
			]
		})] })]
	})] });
}
function Card({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-b border-border py-4",
		children
	});
}
function Row({ label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "flex h-12 items-center justify-between border-b border-border text-left text-sm",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-subtle",
			children: "›"
		})]
	});
}
function NugunaApp() {
	const screen = useAppStore((s) => s.screen);
	const printers = useAppStore((s) => s.printers);
	const selectedPrinterId = useAppStore((s) => s.selectedPrinterId);
	const jobs = useAppStore((s) => s.jobs);
	const go = useAppStore((s) => s.go);
	const printer = printers.find((p) => p.id === selectedPrinterId);
	(0, import_react.useEffect)(() => {
		Promise.resolve(useAppStore.persist.rehydrate()).then(() => {
			const state = useAppStore.getState();
			if (!state.printers.some((p) => p.id === "local-device")) state.upsertPrinter(localPrinter());
			if (!state.selectedPrinterId) state.selectPrinter(LOCAL_PRINTER_ID);
		});
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-dvh bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid min-h-dvh w-full max-w-6xl lg:grid-cols-[16rem_minmax(0,1fr)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden flex-col border-r border-border px-6 py-10 lg:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-2xl font-medium tracking-tight",
						children: "누구나프린트"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted",
						children: "같은 망의 프린터, 또는 이 기기의 인쇄 창."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => go("printers"),
						className: "mt-10 flex items-center gap-3 border-y border-border py-4 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs text-subtle",
								children: "프린터"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-1 block truncate text-sm font-medium",
								children: printer?.displayName ?? "선택 안 함"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-auto pt-8 font-mono text-xs text-subtle",
						children: [
							"최근 ",
							jobs.length,
							"건 · 이 기기에만"
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto flex w-full max-w-xl flex-col",
				children: body(screen)
			})]
		})
	});
}
function body(screen) {
	switch (screen) {
		case "printers": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintersScreen, {});
		case "add-printer": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddPrinterScreen, {});
		case "preview": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewScreen, {});
		case "progress": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressScreen, {});
		case "result": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultScreen, {});
		case "settings": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsScreen, {});
		case "licenses": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LicensesScreen, {});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {});
	}
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NugunaApp, {});
}
//#endregion
export { pageSizePoints as n, routes_exports as t };
