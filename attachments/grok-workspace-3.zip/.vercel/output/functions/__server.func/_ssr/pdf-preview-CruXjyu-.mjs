import { n as getDocument, t as GlobalWorkerOptions } from "../_libs/pdfjs-dist.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pdf-preview-CruXjyu-.js
GlobalWorkerOptions.workerSrc = "/assets/pdf.worker.min-CIqJB0yW.mjs";
async function loadPdf(data) {
	const copy = data.slice();
	return getDocument({ data: copy }).promise;
}
async function pdfPreview(data, maxWidth = 900) {
	const pdf = await loadPdf(data);
	const page = await pdf.getPage(1);
	const base = page.getViewport({ scale: 1 });
	const viewport = page.getViewport({ scale: Math.min(2, maxWidth / base.width) });
	const canvas = document.createElement("canvas");
	canvas.width = Math.ceil(viewport.width);
	canvas.height = Math.ceil(viewport.height);
	const ctx = canvas.getContext("2d", { alpha: false });
	if (!ctx) throw new Error("canvas");
	ctx.fillStyle = "#ffffff";
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	await page.render({
		canvas,
		canvasContext: ctx,
		viewport
	}).promise;
	const blob = await new Promise((resolve, reject) => {
		canvas.toBlob((b) => b ? resolve(b) : reject(/* @__PURE__ */ new Error("preview")), "image/jpeg", .86);
	});
	return {
		url: URL.createObjectURL(blob),
		pageCount: pdf.numPages
	};
}
//#endregion
export { loadPdf, pdfPreview };
